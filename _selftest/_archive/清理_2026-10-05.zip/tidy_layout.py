# -*- coding: utf-8 -*-
r"""项目清理：删掉过程产物与一次性脚本，只留"产品 + 证据 + 说明"。

## 留什么（这是这个项目的最终形态）

    README.md / docs/          知识：格式规范、图片管线、记忆卡处理、坑清单
    src/ dist/                 上游归档（原样）
    tools/                     ★ 产品：格式核心 + CLI + 图像加工 + 记忆卡自检
    testdata/                  样品：合成样品 + 10 份真实存档
    out/evidence/  out/preview/ 有实机结论的卡 + 值得看的图
    _selftest/                 4 份报告 + 可复用脚本 + 4 个证据卡生成器

## 删什么（都可再生 / 已归档 / 结论已在报告里）

  * `out/_archive/`            过程卡 11 张 + 过程图 27 张（91 MB；每张卡都有生成脚本）
  * `_selftest/_archive/`      19 个一次性诊断脚本 + 原始输出
  * `_selftest/write_{nlr,sl,lr,fin}*.py` 其余 5 个实验卡生成器（对应卡已删）
  * `testdata/_work/`、`**/__pycache__/`、`testdata/**/*.backup`   纯临时物

⚠ 过程脚本**不是直接删掉**：先打包成 `_selftest/过程脚本存档_2026-10-04.zip`（约 40 KB），
   这样目录清爽、代码也没丢。要彻底删掉那个 zip 说一声即可。

## 用法

    python _selftest\tidy_layout.py            # 只看计划（默认，不改任何东西）
    python _selftest\tidy_layout.py --apply    # 执行
    python _selftest\tidy_layout.py --memcards --apply   # 顺带清记忆卡里的测试卡（需先退出 PCSX2）
"""
from __future__ import annotations

import argparse
import hashlib
import os
import shutil
import subprocess
import zipfile

PROJ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(PROJ, "out")
SELFTEST = os.path.join(PROJ, "_selftest")
MC_DIR = r"C:\Users\M\Documents\PCSX2\memcards"
ZIP_NAME = "过程脚本存档_2026-10-04.zip"

DELETE_TREES = [                                   # 整个目录删
    os.path.join(OUT, "_archive"),                 # 过程卡 + 过程图
    os.path.join(SELFTEST, "_archive"),            # 一次性诊断脚本（先打包再删）
    os.path.join(PROJ, "testdata", "_work"),       # selftest.py 的临时目录
]
ZIP_DIRS = [os.path.join(SELFTEST, "_archive")]    # 打包内容
RESCUE = ["check_links.py"]                        # 从归档里捞回来、留在 _selftest/ 当工具用的
ZIP_FILES = [                                      # 其余一次性脚本（一并打包后删）
    "write_nlr_test.py", "write_sl_full.py", "write_lrtest.py",
    "write_final2_test.py", "write_final3_test.py",
]
DELETE_GLOBS = ["__pycache__", "*.backup"]         # 递归删

KEEP_TOOLS = ["acet_format.py", "acet_cli.py", "prepare_image.py", "make_testdata.py",
              "selftest.py", "check_pcsx2_slots.py", "README.md"]
# 用户自己的卡：一张都不动
USER_CARDS = {"Mcd001.ps2", "Mcd001_embdata2.ps2", "Mcd_SL.ps2", "Mcd002.ps2",
              "Mcd0022.ps2", "ACSL_SL_US2JP_v2.ps2"}


def sha(path, n=1 << 20):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(n), b""):
            h.update(chunk)
    return h.hexdigest()


def dirsize(p):
    if not os.path.isdir(p):
        return 0, 0
    n = s = 0
    for root, _dirs, files in os.walk(p):
        for f in files:
            n += 1
            s += os.path.getsize(os.path.join(root, f))
    return n, s


def pcsx2_running():
    try:
        out = subprocess.run(["tasklist", "/FI", "IMAGENAME eq pcsx2-qt.exe"],
                             capture_output=True, text=True, timeout=30).stdout
        return "pcsx2-qt.exe" in out
    except Exception:
        return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--apply", action="store_true", help="真的执行（默认只演算）")
    ap.add_argument("--memcards", action="store_true", help="顺带清理记忆卡里的测试卡")
    a = ap.parse_args()
    print("=" * 96)
    print("项目清理 [%s模式]   %s" % ("执行" if a.apply else "演算", PROJ))
    print("=" * 96)

    total_files = total_bytes = 0

    # ---------- 1. 打包一次性脚本 ----------
    print("\n【0】从归档里捞回要留作工具用的脚本: %s" % ", ".join(RESCUE))
    for f in RESCUE:
        src = os.path.join(SELFTEST, "_archive", f)
        if os.path.exists(src):
            print("   %-24s → _selftest\\%-16s %s" % (f, f, "已移动" if a.apply else "将移动"))
            if a.apply:
                shutil.move(src, os.path.join(SELFTEST, f))
        elif os.path.exists(os.path.join(SELFTEST, f)):
            print("   %-24s 已在 _selftest\\  ✅" % f)

    zb = os.path.join(SELFTEST, ZIP_NAME)
    pack = []
    for d in ZIP_DIRS:
        for root, _dirs, files in os.walk(d):
            for f in files:
                p = os.path.join(root, f)
                pack.append((p, os.path.relpath(p, SELFTEST)))
    for f in ZIP_FILES:
        p = os.path.join(SELFTEST, f)
        if os.path.exists(p):
            pack.append((p, f))
    print("\n【1】一次性脚本 → %s（%d 个文件）" % (ZIP_NAME, len(pack)))
    if pack:
        if a.apply and not os.path.exists(zb):
            with zipfile.ZipFile(zb, "w", zipfile.ZIP_DEFLATED) as z:
                for p, arc in sorted(pack):
                    z.write(p, arc)
            print("   已打包 → %s（%.1f KB）" % (zb, os.path.getsize(zb) / 1024))
        elif os.path.exists(zb):
            print("   %s 已存在（跳过打包）" % ZIP_NAME)
        else:
            print("   将打包 → %s" % zb)
        for p, arc in sorted(pack):
            print("      + %s" % arc)
    # 打包成功后，把"只进 zip"的那些脚本从目录里删掉
    if a.apply and os.path.exists(zb):
        for f in ZIP_FILES:
            p = os.path.join(SELFTEST, f)
            if os.path.exists(p):
                os.remove(p)
                print("   已打包并移除: %s" % f)

    # ---------- 2. 删目录 ----------
    print("\n【2】删除过程产物目录")
    for d in DELETE_TREES:
        n, s = dirsize(d)
        if not n:
            print("   %-30s (不存在)" % os.path.relpath(d, PROJ))
            continue
        total_files += n
        total_bytes += s
        print("   %-30s %2d 个文件 / %7.1f MB   %s"
              % (os.path.relpath(d, PROJ), n, s / 1048576, "已删除" if a.apply else "将删除"))
        if a.apply:
            shutil.rmtree(d, ignore_errors=True)

    # ---------- 3. 删散落的临时物 ----------
    print("\n【3】删除散落的临时物（%s）" % "、".join(DELETE_GLOBS))
    hits = []
    for root, dirs, files in os.walk(PROJ):
        if os.sep + "src" + os.sep in root + os.sep or os.sep + "dist" + os.sep in root + os.sep:
            continue
        for d in list(dirs):
            if d == "__pycache__":
                hits.append(os.path.join(root, d))
        for f in files:
            if f.endswith(".backup"):
                hits.append(os.path.join(root, f))
    for p in hits:
        n, s = dirsize(p) if os.path.isdir(p) else (1, os.path.getsize(p))
        total_files += n
        total_bytes += s
        print("   %-52s %s" % (os.path.relpath(p, PROJ), "已删除" if a.apply else "将删除"))
        if a.apply:
            shutil.rmtree(p, ignore_errors=True) if os.path.isdir(p) else os.remove(p)
    if not hits:
        print("   （无）")

    print("\n   合计：%d 个文件 / %.1f MB" % (total_files, total_bytes / 1048576))

    # ---------- 4. 记忆卡 ----------
    if a.memcards:
        print("\n【4】记忆卡目录：只删「有逐字节相同副本」的测试卡；用户自己的卡不动")
        pool = {}
        for d in (os.path.join(OUT, "evidence"), os.path.join(OUT, "_archive", "cards"), OUT):
            if os.path.isdir(d):
                for f in os.listdir(d):
                    if f.endswith(".ps2"):
                        pool.setdefault(f, os.path.join(d, f))
        running = pcsx2_running()
        print("   PCSX2 运行中? %s" % ("★ 是 —— 拒绝执行" if running else "否 ✅"))
        mine = [f for f in sorted(os.listdir(MC_DIR))
                if f.endswith(".ps2") and f not in USER_CARDS]
        todel = []
        for f in mine:
            p, dup = os.path.join(MC_DIR, f), pool.get(f)
            if dup and os.path.exists(dup) and sha(p) == sha(dup):
                print("   %-24s 可删（副本 %s）" % (f, os.path.relpath(dup, PROJ)))
                todel.append(p)
            else:
                print("   %-24s ★保留" % f)
        if todel and a.apply and not running:
            for p in todel:
                os.remove(p)
            print("   已删除 %d 张" % len(todel))
        elif todel:
            print("   将删除 %d 张（加 --apply 且退出 PCSX2 才生效）" % len(todel))

    # ---------- 5. 清理后的样子 ----------
    print("\n【5】保留的东西")
    for d in ("docs", "tools", "testdata", "out/evidence", "out/preview", "_selftest", "src", "dist"):
        n, s = dirsize(os.path.join(PROJ, d.replace("/", os.sep)))
        print("   %-18s %3d 个文件 / %7.2f MB" % (d, n, s / 1048576))
    print("   tools/ 内容: %s" % ", ".join(KEEP_TOOLS))
    print("\n(默认演算；--apply 才动文件)")


if __name__ == "__main__":
    raise SystemExit(main())
