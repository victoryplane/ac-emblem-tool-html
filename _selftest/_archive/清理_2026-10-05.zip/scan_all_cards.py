# -*- coding: utf-8 -*-
r"""只读：扫描**所有** PS2 记忆卡，把里面每一份徽章数据都找出来并验证。

认两处：
  ① 目录名以 `E<两位数字>` 结尾（`BASLUS-20435E00` / `BISLPS-25112E02` …）= 单体徽章存档
  ② 目录名以 `EMB` 结尾（LR）= 目录里是 `data0..data7`

另外顺带在**普通存档**（`S##` / `GAME` / `sav00`）里搜徽章块，看"当前装备的徽章"是否内嵌在那里。

⚠ 全程只读：只用 Card.read_page / read_file，不写任何字节。
"""
import glob
import hashlib
import importlib.util
import os
import re
import sys

MC_DIR = r"C:\Users\M\Documents\PCSX2\memcards"
SURV = r"E:\Armored Core\Armored Core\PS2\AC3_CN\tools\30-存档\61_mc_survey.py"
OUT = r"E:\Armored Core\Armored Core\PS2\emblem-tool\testdata\real"
TOOLS = r"E:\Armored Core\Armored Core\PS2\emblem-tool\tools"

spec = importlib.util.spec_from_file_location("sv", SURV)
sv = importlib.util.module_from_spec(spec)
spec.loader.exec_module(sv)
sys.path.insert(0, TOOLS)
import acet_format as af

MAGIC = af.EMBLEM_HEADER
found = []


def scan_card(path, tag):
    try:
        card = sv.Card(path)
    except Exception as e:
        print("  [跳过] %s: %s" % (os.path.basename(path), e))
        return
    ents = card.dirents(card.rootdir, card.dir_count(card.rootdir))
    print("  %-28s 根目录 %d 项" % (os.path.basename(path), len(ents)))
    for e in ents:
        name = e["name"]
        if name in (".", ".."):
            continue
        is_emb_dir = name.endswith("EMB")
        is_emb_slot = re.search(r"E\d\d$", name) is not None
        is_dir = bool(e["mode"] & 0x8000) and e["length"] and name.startswith("B")
        if not is_dir:
            continue
        subs = card.dirents(e["cluster"], e["length"])
        files = [s for s in subs if s["name"] not in (".", "..") and s["length"]]
        if is_emb_dir or is_emb_slot:
            print("    ★ 徽章目录 [%s]  文件 %d" % (name, len(files)))
            for s in files:
                data = card.read_file(s["cluster"], s["length"])
                kind = af.save_kind(data)
                note = ""
                if kind in ("emblem-raw", "emblem-lr", "container"):
                    try:
                        ok, bad = af.verify_checksums(data)
                        note = "  校验%s" % ("18/18 通过" if ok else "有 %d 段不符" % len(bad))
                    except Exception as ex:
                        note = "  校验异常: %s" % ex
                print("        %-14s %7d B  %-12s%s" % (s["name"], s["length"], kind, note))
                if kind in ("emblem-raw", "emblem-lr", "container"):
                    found.append((tag, name, s["name"], bytes(data)))
        else:
            # 普通存档：在里面找徽章块（找魔数 / 或 >=0x4440 的文件）
            for s in files:
                data = card.read_file(s["cluster"], s["length"])
                hits = data.count(MAGIC)
                if hits:
                    off = data.find(MAGIC)
                    print("    ⚑ 普通存档 [%s]/%s 里出现徽章魔数 %d 次（首个 @0x%X）"
                          % (name, s["name"], hits, off))
                    found.append((tag, name + "/" + s["name"] + "@0x%X" % off, s["name"], bytes(data)))


print("=== 扫描所有记忆卡（只读）===")
for p in sorted(glob.glob(os.path.join(MC_DIR, "*.ps2"))):
    scan_card(p, os.path.basename(p))

print("\n=== 汇总：可用作徽章样本的文件 %d 个 ===" % len(found))
os.makedirs(OUT, exist_ok=True)
for tag, dirname, fname, data in found:
    kind = af.save_kind(data)
    if kind == "container":
        # 容器：把徽章块切出来
        try:
            off = af.find_offset(data)
            data = data[off:off + 0x4440]
            kind = "emblem-raw"
        except Exception:
            continue
    safe = re.sub(r"[^0-9A-Za-z_.-]", "_", "%s__%s" % (tag, dirname))
    out = os.path.join(OUT, "%s__%s" % (safe, fname))
    open(out, "wb").write(data)
    print("  → %-60s %6d B  %s" % (os.path.basename(out), len(data),
                                   hashlib.sha256(data).hexdigest()[:16]))
print("\n(只读完成；未向任何记忆卡写入字节)")
