# -*- coding: utf-8 -*-
r"""检查 README / 关键文档里写出的**项目相对路径**是否存在（死链自检）。

只认"看起来确实是路径"的：必须以已知顶层目录开头（`docs/` `tools/` `testdata/` `out/`
`_selftest/` `src/` `dist/` `../`），并且不含通配符/占位符。
命令行（`python xxx`、`cd xxx`）、PCSX2 配置文件、裸文件名都不算。

    python _selftest\check_links.py
"""
import os
import re

# 不管这个脚本被放在哪一层，都往上找到项目根（含 tools/acet_format.py 的那一层）
ROOT = os.path.dirname(os.path.abspath(__file__))
while not os.path.exists(os.path.join(ROOT, "tools", "acet_format.py")):
    parent = os.path.dirname(ROOT)
    if parent == ROOT:
        break
    ROOT = parent
DOCS = ["README.md", "out/README.md", "_selftest/README.md", "tools/README.md",
        "testdata/README.md", "docs/01-项目理解/07-限制与已知问题.md",
        "docs/01-项目理解/04-记忆卡与存档处理.md", "_selftest/04-末段校验差一字节.md"]
PREFIX = ("docs/", "docs\\", "tools/", "tools\\", "testdata/", "testdata\\", "out/", "out\\",
          "_selftest/", "_selftest\\", "src/", "src\\", "dist/", "dist\\", "../")
SKIP_CHARS = "*<>$|"
ALLOW = {"src/main.cpp",                  # 上游**历史**提交里的路径，正文已说明，不算死链
         "testdata/_work/"}               # selftest.py 的临时目录（跑测试时才有，属正常）

bad = 0
for d in DOCS:
    p = os.path.join(ROOT, d)
    if not os.path.exists(p):
        print("  ✗ 文档本身不存在: %s" % d)
        bad += 1
        continue
    base = os.path.dirname(p)
    txt = open(p, encoding="utf-8").read()
    cand = set(re.findall(r"`([^`\n]+)`", txt)) | set(re.findall(r"\]\(([^)\n]+)\)", txt))
    for c in sorted(cand):
        c = c.strip().rstrip("。，；")
        if c.startswith(("http", "#")):
            continue
        for pre in ("python ", "cd ", "py "):
            if c.startswith(pre):
                c = c[len(pre):].strip()
        if not c.startswith(PREFIX) or any(ch in c for ch in SKIP_CHARS) or ":" in c:
            continue
        if c in ALLOW:
            continue
        ok = False
        for cp in (c, c.replace("\\", "/")):
            for rootdir in (base, ROOT, os.path.join(ROOT, "_selftest")):
                if os.path.exists(os.path.join(rootdir, cp)):
                    ok = True
        if not ok:
            print("  ✗ %-40s %s" % (d, c))
            bad += 1
print("死链 %d 处" % bad)
