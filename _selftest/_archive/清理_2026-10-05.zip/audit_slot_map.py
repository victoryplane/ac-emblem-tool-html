# -*- coding: utf-8 -*-
r"""只读：把每张卡上**每个徽章槽**的内容做成"指纹表"，一眼看出"游戏画面上那张图是哪张卡的哪一格"。

为什么需要它：ACLR 的记忆卡槽在 PCSX2 里被**每游戏设置**改写过（见 `SLPS-25462_FEBEC38B.ini`
的 `[MemoryCards] Slot2_Filename`），所以"我在设置里挂的是哪张卡"**不等于**"LR 实际读哪张卡"。
要判定"LR 画面上那三格到底是哪张卡的哪几格"，必须先把**所有卡的每一格**都算出来。

指纹 = 块 SHA256 前 12 位 + 不透明像素里的前 3 种颜色及占比。
    · 洋红/青棋盘 → 只有 3 色且两色各占 ~45%
    · 紫恶魔 / 红树 / 反色恶魔 / 蓝白 MIRAGE / 红黑 CREST → 各有明显主色

用法:
    python _selftest\audit_slot_map.py [卡路径 ...]      # 默认扫 out\ 与 memcards\ 的 Mcd001*
"""
from __future__ import annotations

import glob
import hashlib
import importlib.util
import os
import re
import sys

SURV = r"E:\Armored Core\Armored Core\PS2\AC3_CN\tools\30-存档\61_mc_survey.py"
PROJ = r"E:\Armored Core\Armored Core\PS2\emblem-tool"
MC_DIR = r"C:\Users\M\Documents\PCSX2\memcards"
sys.path.insert(0, os.path.join(PROJ, "tools"))
import acet_format as af                                        # noqa: E402

spec = importlib.util.spec_from_file_location("sv", SURV)
sv = importlib.util.module_from_spec(spec)
spec.loader.exec_module(sv)


def sig(blk: bytes) -> str:
    """图指纹：SHA256[:12] + 前三主色占比。"""
    try:
        rgba = af.extract_image(blk, alpha_mode="index0")
    except Exception as e:
        return "提取失败: %s" % e
    from collections import Counter
    c = Counter()
    for i in range(0, len(rgba), 4):
        if rgba[i + 3]:
            c[(rgba[i], rgba[i + 1], rgba[i + 2])] += 1
    tot = sum(c.values()) or 1
    top = "  ".join("%02X%02X%02X:%4.1f%%" % (r, g, b, 100.0 * n / tot)
                    for (r, g, b), n in c.most_common(3))
    return "%s  色数%3d  %s" % (hashlib.sha256(blk).hexdigest()[:12].upper(), len(c), top)


def slots_of(path):
    """返回 [(目录名, 文件名, 块, 是否 LR)]，只含真·徽章数据。"""
    out = []
    try:
        card = sv.Card(path)
    except Exception as e:                       # 卡被 PCSX2 独占打开时会到这里
        print("   [读不到] %s" % e)
        return out
    for e in card.dirents(card.rootdir, card.dir_count(card.rootdir)):
        nm = e["name"]
        if nm in (".", "..") or not nm.startswith("B"):
            continue
        is_emb = bool(re.search(r"E\d\d$", nm)) or nm.endswith("EMB")
        if not is_emb:
            continue
        for s in card.dirents(e["cluster"], e["length"]):
            if s["name"] in (".", "..") or not s["length"]:
                continue
            data = bytes(card.read_file(s["cluster"], s["length"]))
            kind = af.save_kind(data)
            if kind not in ("emblem-raw", "emblem-lr"):
                continue
            out.append((nm, s["name"], data, kind == "emblem-lr"))
    return out


paths = sys.argv[1:]
if not paths:
    paths = sorted(glob.glob(os.path.join(PROJ, "out", "Mcd001*.ps2")))
    for extra in ("Mcd001_embdata2.ps2", "Mcd001.ps2", "Mcd001_LRtest2.ps2", "Mcd001_TEST.ps2"):
        p = os.path.join(MC_DIR, extra)
        if os.path.exists(p):
            paths.append(p)

# 同一格的"别名"表：把出现过的指纹归类成可读名字
NAMES = {}
for p in paths:
    tag = ("memcards" if os.path.dirname(p).rstrip("\\").lower().endswith("memcards")
           else "out") + "/" + os.path.basename(p)
    print("\n" + "=" * 110)
    print("★ %s   (%d 字节)" % (tag, os.path.getsize(p)))
    for dn, fn, blk, is_lr in slots_of(p):
        ok, bad = af.verify_checksums(blk)
        print("   %-18s %-18s %-3s 校验%-4s %s"
              % (dn, fn, "LR" if is_lr else "非LR", "18/18" if ok else "%d段坏" % len(bad), sig(blk)))

# 跨卡统计：哪些格子内容相同
print("\n" + "=" * 110)
print("=== 同名内容归并（同一 SHA 只列一次）===")
seen = {}
for p in paths:
    tag = os.path.basename(p)
    for dn, fn, blk, is_lr in slots_of(p):
        h = hashlib.sha256(blk).hexdigest()[:12].upper()
        seen.setdefault(h, []).append("%s:%s/%s" % (tag, dn, fn))
for h, where in sorted(seen.items(), key=lambda kv: -len(kv[1])):
    print("  %s  ×%-3d %s" % (h, len(where), "  ".join(where[:6]) + (" …" if len(where) > 6 else "")))
