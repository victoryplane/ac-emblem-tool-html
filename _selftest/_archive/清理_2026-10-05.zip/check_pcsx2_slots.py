# -*- coding: utf-8 -*-
r"""只读自检：**PCSX2 实际会把哪张记忆卡插进哪个槽**。

## 为什么必须有这个工具

PCSX2 v2.x 的记忆卡设置有两层，**每游戏设置会覆盖全局设置**：

    is\PCSX2.ini                    ←「设置 → 记忆卡插槽」这个对话框写的就是它
    gamesettings\<序列号>_<CRC>.ini  ← Game Properties（每游戏设置）写的是它，**它赢**

于是会出现这种极难自查的情况（本项目实测踩到，浪费了一整轮排查）：

    对话框里明明写着  Slot 2 = Mcd001_TEST.ps2
    但 emulog 是        McdSlot 1 [File]: Mcd001_embdata2.ps2   ← 实际挂的是源卡

⇒ **"我在对话框里挂的是哪张卡" ≠ "游戏读的是哪张卡"。** 每次进游戏验证前先跑一遍本工具。

参考（PCSX2 官方 issue，确认"每游戏记忆卡覆盖"是真实存在的机制，且 UI 上不好改）：
  · https://github.com/PCSX2/pcsx2/issues/9032   「Per-game memory card overrides don't work until reinserted」
  · https://github.com/PCSX2/pcsx2/issues/10723  「Can't move around memcards on per-game settings … neither remove them」

## 用法

    python tools\check_pcsx2_slots.py                     # 默认找 C:\Users\M\Documents\PCSX2
    python tools\check_pcsx2_slots.py --pcsx2 "D:\PCSX2"
    python tools\check_pcsx2_slots.py --emblems           # 顺便列出各卡上的徽章槽内容

全程只读，不写任何文件。
"""
from __future__ import annotations

import argparse
import configparser
import glob
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
try:
    import acet_format as af
except Exception:                                    # 允许在缺核心模块时仍能查槽位
    af = None

DEFAULT_PCSX2 = r"C:\Users\M\Documents\PCSX2"
SLOTS = (1, 2)                                        # 记忆卡插槽 1 / 2（PCSX2 界面上的叫法）
MCDSLOT = {1: 0, 2: 1}                                # 界面 Slot1 = 日志里的 McdSlot 0


# ---------------------------------------------------------------- ini 读取
def read_ini(path):
    cp = configparser.ConfigParser(strict=False, interpolation=None)
    cp.optionxform = str                              # PCSX2 的键名大小写敏感
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            cp.read_file(f)
    except Exception as e:
        return None, str(e)
    return cp, None


def mc_of(cp):
    """从 ini 里取 {槽号: (启用, 文件名)}；没有的键返回 None。"""
    out = {}
    if cp is None or not cp.has_section("MemoryCards"):
        return out
    for s in SLOTS:
        if cp.has_option("MemoryCards", "Slot%d_Filename" % s):
            fn = cp.get("MemoryCards", "Slot%d_Filename" % s).strip()
            en = True
            if cp.has_option("MemoryCards", "Slot%d_Enable" % s):
                en = cp.getboolean("MemoryCards", "Slot%d_Enable" % s)
            out[s] = (en, fn)
    return out


# ---------------------------------------------------------------- 日志解析
def parse_log(pcsx2):
    """把 emulog.txt 按「每次启动」切开，只返回**最后一次启动**的实际情况。

    一次启动的边界 = `ELF changed, active CRC XXXXXXXX`（新的一次运行）。日志在整个 PCSX2
    进程生命周期里是累积的，所以**必须按启动分组** —— 否则会把几十次旧启动的插卡记录
    混在一起，得出"卡一直在换"的假象。
    """
    log = os.path.join(pcsx2, "logs", "emulog.txt")
    res = {"path": log, "boots": 0, "serial": None, "crc": None, "iso": None,
           "mcd": [], "history": []}
    if not os.path.exists(log):
        return res
    all_lines = open(log, "rb").read().decode("utf-8", "replace").splitlines()
    # 正序扫：一次启动 = 上一条 `ELF changed, active CRC` 之后 → 本条 `ELF changed` 为止。
    # （Serial / isoFile / McdSlot 都出现在 `ELF changed` **之前**，所以必须让它们落在
    #   结束于该 CRC 行的这一段里，否则会把它们的归属错到上一次启动。）
    seg_start = 0
    for i, line in enumerate(all_lines):
        m = re.search(r"ELF changed, active CRC ([0-9A-Fa-f]{8})", line)
        if not m:
            continue
        seg = all_lines[seg_start:i + 1]
        seg_start = i + 1
        serial = iso = None
        mcd = []
        for l in seg:
            mm = re.search(r"\bSerial:\s*(\S+)", l)       # 行首有 [时间戳]，不能加 ^ 锚
            if mm:
                serial = mm.group(1).strip()
            mm = re.search(r"isoFile open ok: (.+)$", l)
            if mm:
                iso = mm.group(1).strip()
            mm = re.search(r"^\[([\d.]+)\]\s*McdSlot (\d) \[File\]: (\S+) \[([^\]]*)\]", l)
            if mm:
                mcd.append((int(mm.group(2)), mm.group(3), mm.group(4)))
        res["history"].append((m.group(1).upper(), mcd, iso, serial))
    # 最后一次 `ELF changed` 之后的行 = 本次运行中途的热插拔，归到最后一启动
    if res["history"]:
        for l in all_lines[seg_start:]:
            mm = re.search(r"^\[([\d.]+)\]\s*McdSlot (\d) \[File\]: (\S+) \[([^\]]*)\]", l)
            if mm:
                res["history"][-1][1].append((int(mm.group(2)), mm.group(3), mm.group(4)))
    res["boots"] = len(res["history"])
    if res["history"]:
        crc, mcd, iso, serial = res["history"][-1]       # 最后一次启动
        res.update(crc=crc, mcd=mcd, iso=iso, serial=serial)
    return res


# ---------------------------------------------------------------- 徽章指纹
def emblem_lines(card_path):
    """列出卡上每个徽章槽的「前三种颜色占比」，用来一眼对上游戏画面。"""
    if af is None:
        return ["   (未加载 acet_format，跳过)"]
    surv = r"E:\Armored Core\Armored Core\PS2\AC3_CN\tools\30-存档\61_mc_survey.py"
    try:
        import importlib.util
        spec = importlib.util.spec_from_file_location("sv_slots", surv)
        sv = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(sv)
        card = sv.Card(card_path)
    except Exception as e:
        return ["   [读不到] %s" % e]
    from collections import Counter
    out = []
    for e in card.dirents(card.rootdir, card.dir_count(card.rootdir)):
        nm = e["name"]
        if nm in (".", "..") or not nm.startswith("B"):
            continue
        if not (re.search(r"E\d\d$", nm) or nm.endswith("EMB")):
            continue
        for s in card.dirents(e["cluster"], e["length"]):
            if s["name"] in (".", "..") or not s["length"]:
                continue
            data = bytes(card.read_file(s["cluster"], s["length"]))
            if af.save_kind(data) not in ("emblem-raw", "emblem-lr"):
                continue
            kind = "LR" if af.is_lr_save(data) else "非LR"
            try:
                rgba = af.extract_image(data, alpha_mode="index0")
                c = Counter()
                for i in range(0, len(rgba), 4):
                    if rgba[i + 3]:
                        c[(rgba[i], rgba[i + 1], rgba[i + 2])] += 1
                tot = sum(c.values()) or 1
                top = "  ".join("%02X%02X%02X:%.0f%%" % (r, g, b, 100.0 * n / tot)
                                for (r, g, b), n in c.most_common(3))
            except Exception as ex:
                top = "提取失败 %s" % ex
            out.append("   %-18s %-18s %-4s %s" % (nm, s["name"], kind, top))
    return out or ["   (这张卡上没有徽章槽)"]


# ---------------------------------------------------------------- main
def main(argv=None):
    ap = argparse.ArgumentParser(description="只读检查 PCSX2 实际挂载的记忆卡")
    ap.add_argument("--pcsx2", default=DEFAULT_PCSX2, help="PCSX2 用户目录（含 inis/ gamesettings/ logs/ memcards/）")
    ap.add_argument("--emblems", action="store_true", help="顺便列出各张被引用的卡上的徽章槽内容")
    ap.add_argument("--all-boots", action="store_true", help="列出本次进程内每一次启动的插卡记录")
    a = ap.parse_args(argv)

    pcsx2 = os.path.abspath(a.pcsx2)
    if not os.path.isdir(pcsx2):
        print("找不到 PCSX2 目录: %s（用 --pcsx2 指定）" % pcsx2)
        return 2
    mcdir = os.path.join(pcsx2, "memcards")

    print("=" * 100)
    print("PCSX2 目录 : %s" % pcsx2)
    print("记忆卡目录 : %s" % mcdir)
    print("=" * 100)

    # ---------- 1. 全局设置 ----------
    gcp, gerr = read_ini(os.path.join(pcsx2, "inis", "PCSX2.ini"))
    if gerr:
        print("\n[!] 读全局 ini 失败: %s" % gerr)
    gmc = mc_of(gcp)
    print("\n【1】全局设置  inis\\PCSX2.ini  ← 就是「设置 → 记忆卡插槽」那个对话框")
    for s in SLOTS:
        if s in gmc:
            en, fn = gmc[s]
            print("    Slot %d : %s  %s" % (s, "启用" if en else "停用", fn or "(空)"))
        else:
            print("    Slot %d : (未设置)" % s)

    # ---------- 2. 每游戏覆盖 ----------
    print("\n【2】每游戏覆盖  gamesettings\\*.ini  ← **它覆盖上面那张表**")
    overrides = {}
    for p in sorted(glob.glob(os.path.join(pcsx2, "gamesettings", "*.ini"))):
        cp, err = read_ini(p)
        mc = mc_of(cp)
        if not mc:
            continue
        overrides[os.path.basename(p)] = (p, mc)
        mt = os.path.getmtime(p)
        import datetime
        print("    ★ %-34s (改于 %s)" % (os.path.basename(p),
              datetime.datetime.fromtimestamp(mt).strftime("%Y-%m-%d %H:%M:%S")))
        for s in sorted(mc):
            en, fn = mc[s]
            print("         Slot %d = %s" % (s, fn or "(空)"))
    if not overrides:
        print("    （没有任何游戏覆盖记忆卡设置 ✅）")

    # ---------- 3. 模拟器实际做了什么 ----------
    lg = parse_log(pcsx2)
    print("\n【3】模拟器实际挂载了什么  logs\\emulog.txt  ← 这是**事实**，不是设置")
    if lg["iso"]:
        print("    上次运行 ISO : %s" % lg["iso"])
    if lg["serial"] or lg["crc"]:
        print("    游戏         : Serial=%s  CRC=%s" % (lg["serial"], lg["crc"]))
    if lg["mcd"]:
        print("    最后一次启动时插的卡（McdSlot 0 = 界面上的 Slot 1；McdSlot 1 = Slot 2）:")
        for slot, fn, note in lg["mcd"]:
            print("        McdSlot %d [File]: %-28s %s" % (slot, fn, note))
    else:
        print("    （日志里没找到插卡记录）")
    if lg["boots"] > 1:
        print("    （本进程共 %d 次启动；以上只列最后一次。用 --all-boots 看全部）" % lg["boots"])
    if a.all_boots and lg["history"]:
        print("\n    ── 全部启动记录（新的在前，最多 12 条）──")
        for i, (crc, mcd, iso, serial) in enumerate(reversed(lg["history"]), 1):
            if i > 12:
                break
            cards = "  ".join("McdSlot%d=%s" % (s, f) for s, f, _ in mcd) or "(无插卡记录)"
            print("      %2d) CRC=%s  %s" % (i, crc, cards))

    # ---------- 4. 结论：实际生效表 ----------
    # 每游戏 ini 的键是 <序列号>_<CRC>.ini；序列号可能只在日志更早的地方出现 ⇒ 退化为按 CRC 找
    key = None
    if lg["crc"]:
        key = ("%s_%s.ini" % (lg["serial"], lg["crc"])) if lg["serial"] else None
        if key not in overrides:
            cand = [k for k in overrides if k.upper().endswith("_%s.INI" % lg["crc"])]
            key = cand[0] if cand else key
    print("\n【4】下一次启动**实际**会读哪张卡（按配置推断）")
    if key:
        print("    生效的每游戏配置: gamesettings\\%s%s"
              % (key, "" if key in overrides else "   （该文件不存在 → 纯用全局设置）"))
    for s in SLOTS:
        ov = overrides.get(key, (None, {}))[1].get(s) if key else None
        if ov:
            src = "★每游戏覆盖 (%s)" % key
            en, fn = ov
        elif s in gmc:
            src = "全局设置"
            en, fn = gmc[s]
        else:
            src, en, fn = "未设置", False, ""
        exists = os.path.exists(os.path.join(mcdir, fn)) if fn else False
        print("    Slot %d = %-28s [%s]%s" % (s, fn or "(空)", src,
              "" if (not fn or exists) else "   ← ★ 文件不存在！"))

    # ---------- 5. 警告 ----------
    print("\n【5】警告")
    warn = 0
    for name, (p, mc) in overrides.items():
        for s, (en, fn) in sorted(mc.items()):
            g = gmc.get(s, (None, None))
            if g[1] is not None and g[1] != fn:
                warn += 1
                print("    ★★ %s 把 Slot %d 钉死在 `%s`，"
                      "而全局设置里 Slot %d 是 `%s`。" % (name, s, fn or "(空)", s, g[1] or "(空)"))
                print("       ⇒ **游戏读到的是 `%s`，不是你对话框里选的那张。**" % (fn or "(空)"))
                print("       改法：编辑该 ini，删掉 [MemoryCards] 里的 Slot%d_Filename 行（先备份）；" % s)
                print("             或在模拟器里打开 Game Properties 用 reset 取消该覆盖"
                      "（UI 有时不允许直接改，见 PCSX2 issue #10723）。")
            else:
                print("    · %s 覆盖 Slot %d = %s（与全局一致或全局为空，无冲突）" % (name, s, fn or "(空)"))
    if not warn:
        print("    没有任何「每游戏覆盖 vs 全局」冲突 ✅")
    # 实际挂载 vs 结论（只比"最后一次启动"的日志）
    if lg["mcd"]:
        got = {slot: fn for slot, fn, _ in lg["mcd"]}
        for s in SLOTS:
            want = None
            ov = overrides.get(key, (None, {}))[1].get(s) if key else None
            if ov:
                want = ov[1]
            elif s in gmc:
                want = gmc[s][1]
            real = got.get(MCDSLOT[s])
            if real is not None and (want or "") != real:
                print("    ★ 上次启动 McdSlot %d 实际挂的是 `%s`，而现在的配置推断是 `%s`"
                      % (MCDSLOT[s], real, want or "(空)"))
                print("      （若你刚改过设置，这条属正常：设置对**下一次**启动生效。）")

    # ---------- 6. 可选：徽章内容 ----------
    if a.emblems:
        print("\n【6】各张被引用的卡上的徽章槽（用来对上游戏画面）")
        seen = set()
        for s in SLOTS:
            ov = overrides.get(key, (None, {}))[1].get(s) if key else None
            fn = ov[1] if ov else (gmc.get(s, (None, ""))[1])
            if not fn or fn in seen:
                continue
            seen.add(fn)
            print("  ── Slot %d : %s" % (s, fn))
            for line in emblem_lines(os.path.join(mcdir, fn)):
                print(line)

    print("\n(全程只读；未修改任何文件)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
