# -*- coding: utf-8 -*-
r"""★ 写入实验：把 data0（恶魔徽章）**反色**后作为一个新槽位 `data2` 写进 LR 记忆卡。

> 重点在**写入链路**（往卡上新建一个徽章槽），不在导出。
> 全程只写**副本**；源卡 `Mcd001.ps2` 只读，脚本末尾会用 SHA256 证明它没被碰过。

复用本工作区已有的记忆卡写层（不重造）：
  · 读结构 / 簇链 / dirent：`AC3_CN\tools\30-存档\61_mc_survey.py::Card`
  · 写页 + ECC + FAT    ：`AC3_CN\tools\30-存档\65_us2jp.py::Writable`
    （★ 那个类解决了一个大坑：读-改-写必须从**副本**句柄读，否则 FAT 写入被静默回退）

写入清单（先给计划，再执行）：
  1. 复制 `Mcd001.ps2` → 新卡（源卡不碰）
  2. 构造新徽章块：`data0` 的**调色板 RGB 逐项取反**，alpha 保持不动，然后重算 18 段校验
  3. 分配 18 个空闲簇（17,440 B ÷ 1024），写数据 + 每页重算 ECC
  4. 写 FAT 链：`0x80000000 | next`，末簇 `0x80000000 | 0x7FFFFFFF`
  5. 把 `data0` 的 dirent **克隆**一份（改名 `data2`、改首簇、长度不变）写进 EMB 目录的第 7 号空槽
  6. 把**根目录**里 `BISLPS-25462EMB` 条目的 `length` 7 → 8（项数）
  7. 回读校验：条目存在、文件 17,440 B、18/18 校验、ECC 正确、图像确为反色
"""
from __future__ import annotations

import hashlib
import importlib.util
import os
import shutil
import struct
import sys

MC_DIR = r"C:\Users\M\Documents\PCSX2\memcards"
SRC_CARD = os.path.join(MC_DIR, "Mcd001.ps2")
DST_CARD = os.path.join(MC_DIR, "Mcd001_embdata2.ps2")
PROJ = r"E:\Armored Core\Armored Core\PS2\emblem-tool"
OUT_DIR = os.path.join(PROJ, "out")
SURV = r"E:\Armored Core\Armored Core\PS2\AC3_CN\tools\30-存档\61_mc_survey.py"
US2JP = r"E:\Armored Core\Armored Core\PS2\AC3_CN\tools\30-存档\65_us2jp.py"
sys.path.insert(0, os.path.join(PROJ, "tools"))
import acet_format as af                     # noqa: E402

EMB = "BISLPS-25462EMB"
NEWNAME = "data2"
LAST = 0x7FFFFFFF


def load_mod(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(spec)
    sys.modules[name] = m            # 让 65_us2jp 里的 import 能命中
    spec.loader.exec_module(m)
    return m


sv = load_mod("sv", SURV)
us2jp = load_mod("us2jp", US2JP)
Writable = us2jp.Writable

src_sha_before = hashlib.sha256(open(SRC_CARD, "rb").read()).hexdigest().upper()
print("源卡 SHA256（写前）: %s" % src_sha_before)

# ---------- 1) 构造反色徽章块 ----------
data0 = open(os.path.join(PROJ, "testdata", "real", "BISLPS-25462EMB_data0.raw"), "rb").read()
assert len(data0) == 0x4420
blk = bytearray(data0)
pal_phys = af.offset_index(af.LR_IMAGE_OFFSET + af.NUM_PIXELS, 0)
n_inv = 0
for i in range(256):
    for ch in range(3):                       # 只反 RGB，alpha 保持
        p = af.offset_index(af.LR_IMAGE_OFFSET + af.NUM_PIXELS + i * 4 + ch, 0)
        blk[p] = 255 - blk[p]
        n_inv += 1
af.apply_checksums(blk)
blk = bytes(blk)
ok, bad = af.verify_checksums(blk)
print("反色块: %d 字节, 反了 %d 个 RGB 通道, 校验 %s"
      % (len(blk), n_inv, "18/18 通过" if ok else "失败 %r" % (bad,)))
print("  palette[0]: %s → %s （alpha 保持 0x40）"
      % (data0[pal_phys:pal_phys + 4].hex(' '), blk[pal_phys:pal_phys + 4].hex(' ')))
img_inv = af.extract_image(blk, alpha_mode="gs")
img_org = af.extract_image(data0, alpha_mode="gs")
assert bytes(255 - x for x in img_org[:3]) == img_inv[:3], "反色自检失败"
print("  自检: 提取图的 RGB 确为原图取反 ✓")

# ---------- 2) 复制卡 ----------
os.makedirs(OUT_DIR, exist_ok=True)
shutil.copyfile(SRC_CARD, DST_CARD)
print("\n副本已建: %s" % DST_CARD)

c = Writable(DST_CARD)

# ---------- 3) 定位 EMB 目录 ----------
root_cnt = c.dir_count(c.rootdir)
roots = c.dirents(c.rootdir, root_cnt)
emb = [e for e in roots if e["name"] == EMB][0]
emb_chain = c.chain(emb["cluster"], 64)
root_chain = c.chain(c.rootdir, 64)
print("EMB: 根条目 length=%d, 簇链=%s (%d 槽)" % (emb["length"], emb_chain, len(emb_chain) * c.ppc))
subs = c.dirents(emb["cluster"], emb["length"])
names = [s["name"] for s in subs]
print("现有项: %s" % names)
assert NEWNAME not in names, "%s 已存在，别覆盖" % NEWNAME

# 找空槽
need_bytes = emb["length"] * 512
raw = bytearray()
for cl in emb_chain:
    for k in range(c.ppc):
        raw += c._rd_page(c.data_page(cl, k))
slots = len(emb_chain) * c.ppc
free = None
for i in range(slots):
    if (i + 1) * 512 > len(raw):
        break
    m = struct.unpack_from('<I', raw, i * 512)[0]
    if m == 0xFFFFFFFF:
        free = i
        break
assert free is not None, "EMB 目录没有空槽（需要扩目录）"
print("空槽 = 第 %d 号（目录第 %d 簇 第 %d 页）" % (free, free // c.ppc, free % c.ppc))
assert free == emb["length"], "空槽不在项数之后（%d vs %d），先别写" % (free, emb["length"])

# ---------- 4) 分配 18 个空闲簇 ----------
used = set()
used.add(c.ifc[0])
for fc in c.ind:
    if fc != 0xFFFFFFFF:
        used.add(fc)
for cl in root_chain:
    used.add(cl)
for e in roots:
    if e["name"] in (".", ".."):
        continue
    for cl in c.chain(e["cluster"], 4096):
        used.add(cl)
    for s in c.dirents(e["cluster"], e["length"]):
        if s["name"] in (".", "..") or not s["length"]:
            continue
        for cl in c.chain(s["cluster"], 4096):
            used.add(cl)
print("已用簇 %d 个（含系统区 + 目录链 + 文件链）" % len(used))

ncl = (len(blk) + 1023) // 1024
alloc, cur = [], c.aoff + 2
while len(alloc) < ncl:
    if cur >= c.aend - 4:
        raise SystemExit("卡上空间不足")
    if cur in used:
        cur += 1
        continue
    alloc.append(cur); used.add(cur); cur += 1
print("分配 %d 簇: %s ... %s（首簇 rel=%d）" % (len(alloc), alloc[:4], alloc[-2:], alloc[0]))

# ---------- 5) 写数据 + FAT + ECC ----------
for i, cl in enumerate(alloc):
    c.write_cluster_bytes(cl, blk[i * 1024:(i + 1) * 1024])
for i, cl in enumerate(alloc):
    last = (i == len(alloc) - 1)
    c.set_fat(cl, (0x80000000 | LAST) if last else (0x80000000 | alloc[i + 1]))
print("数据 + FAT 链 + ECC 已写")

# ---------- 6) 克隆 data0 的 dirent → data2 ----------
d0e = [s for s in subs if s["name"] == "data0"][0]
d0raw = bytearray(raw[d0e["index"] * 512:(d0e["index"] + 1) * 512])
new = bytearray(d0raw)
struct.pack_into('<I', new, 0x10, alloc[0])          # 首簇
new[0x40:0x60] = b'\x00' * 0x20                      # 清名
new[0x40:0x40 + len(NEWNAME)] = NEWNAME.encode('ascii')
assert struct.unpack_from('<I', new, 0x04)[0] == len(blk)
pg = c.data_page(emb_chain[free // c.ppc], free % c.ppc)
c.write_page_raw(pg, bytes(new))
print("新 dirent 已写进 EMB 第 %d 号槽（页 %d）" % (free, pg))

# ---------- 7) 根目录条目 length 7 → 8 ----------
re_idx = [i for i, e in enumerate(roots) if e["name"] == EMB][0]
rpg = c.data_page(root_chain[re_idx // c.ppc], re_idx % c.ppc)
page = bytearray(c._rd_page(rpg))
old_len = struct.unpack_from('<I', page, 0x04)[0]
struct.pack_into('<I', page, 0x04, old_len + 1)
c.write_page_raw(rpg, bytes(page))
print("根目录 [%s] 条目 length: %d → %d（页 %d）" % (EMB, old_len, old_len + 1, rpg))
c.f.close()

# ---------- 8) 回读校验 ----------
print("\n" + "=" * 62)
print("回读校验（用只读句柄重新打开新卡）")
c2 = sv.Card(DST_CARD)
r2 = c2.dirents(c2.rootdir, c2.dir_count(c2.rootdir))
e2 = [e for e in r2 if e["name"] == EMB][0]
print("  根条目 length = %d（应为 8）" % e2["length"])
s2 = c2.dirents(e2["cluster"], e2["length"])
print("  目录项: %s" % [(x["name"], x["length"]) for x in s2])
tgt = [x for x in s2 if x["name"] == NEWNAME][0]
got = c2.read_file(tgt["cluster"], tgt["length"])
print("  %s: %d 字节, 首簇 rel=%d" % (NEWNAME, len(got), tgt["cluster"]))
print("  与预期块逐字节相同: %s" % (got == blk))
ok, bad = af.verify_checksums(got)
print("  徽章校验: %s" % ("18/18 通过" if ok else "失败 %r" % (bad,)))
gsame = af.extract_image(got, alpha_mode="gs") == img_inv
print("  提取图与反色图一致: %s" % gsame)
bad_ecc = []
for cl in alloc:
    for k in range(c2.ppc):
        if not c2.c.ecc_ok(c2.data_page(cl, k)):
            bad_ecc.append((cl, k))
print("  数据簇 %d 页 ECC: %s" % (len(alloc) * c2.ppc,
                                "全部正确" if not bad_ecc else "有 %d 页不符 %s" % (len(bad_ecc), bad_ecc[:5])))
# 新 dirent 所在页与根目录条目页也要 ECC 正确
for tag, pageno in (("新 dirent 页", pg), ("根目录条目页", rpg)):
    print("  %s (%d) ECC: %s" % (tag, pageno, "正确" if c2.c.ecc_ok(pageno) else "✗ 不符"))

# ---------- 9) 存一份到项目里 + 证明源卡未变 ----------
shutil.copyfile(DST_CARD, os.path.join(OUT_DIR, "Mcd001_embdata2.ps2"))
src_sha_after = hashlib.sha256(open(SRC_CARD, "rb").read()).hexdigest().upper()
print("\n源卡 SHA256（写后）: %s" % src_sha_after)
print("★ 源卡未被修改: %s" % (src_sha_before == src_sha_after))
print("新卡: %s  (%d 字节)" % (DST_CARD, os.path.getsize(DST_CARD)))
print("项目内副本: %s" % os.path.join(OUT_DIR, "Mcd001_embdata2.ps2"))
