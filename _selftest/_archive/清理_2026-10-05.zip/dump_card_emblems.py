# -*- coding: utf-8 -*-
r"""只读：从指定记忆卡里把所有徽章（`E##` 目录 / `EMB/dataX`）读出来并导出 PNG。

用法:
    python _selftest\dump_card_emblems.py "C:\...\Mcd001_embdata2.ps2" [输出目录]
"""
import importlib.util
import os
import re
import sys

SURV = r"E:\Armored Core\Armored Core\PS2\AC3_CN\tools\30-存档\61_mc_survey.py"
PROJ = r"E:\Armored Core\Armored Core\PS2\emblem-tool"
sys.path.insert(0, os.path.join(PROJ, "tools"))
import acet_format as af                     # noqa: E402

spec = importlib.util.spec_from_file_location("sv", SURV)
sv = importlib.util.module_from_spec(spec)
spec.loader.exec_module(sv)

CARD = sys.argv[1] if len(sys.argv) > 1 else r"C:\Users\M\Documents\PCSX2\memcards\Mcd001_embdata2.ps2"
OUT = sys.argv[2] if len(sys.argv) > 2 else os.path.join(PROJ, "out", "from_card")
os.makedirs(OUT, exist_ok=True)

card = sv.Card(CARD)
print("记忆卡 : %s  (%d 字节)" % (CARD, card.c.size))
roots = card.dirents(card.rootdir, card.dir_count(card.rootdir))
print("根目录 : %d 项" % len(roots))
print()
print("=== 根目录全部条目 ===")
for e in roots:
    if e["name"] in (".", ".."):
        continue
    tag = ""
    if re.search(r"E\d\d$", e["name"]):
        tag = "  ← ★ 徽章存档（E##）"
    elif e["name"].endswith("EMB"):
        tag = "  ← ★ 徽章目录（EMB，内含 data0..7）"
    print("  %-22s mode=0x%04X len=%-6d cluster=%-6d%s"
          % (e["name"], e["mode"], e["length"], e["cluster"], tag))

found = []
for e in roots:
    nm = e["name"]
    if nm in (".", "..") or not nm.startswith("B"):
        continue
    # ⚠ 坑：**不能**用 `mode & 0x2000` 判目录 —— 本卡实测
    #    目录 = 0x8427、文件 = 0x8497，**两者的 bit13(0x2000) 都是 0**。
    #    （`61_mc_survey.py` 里的 `is_dir=bool(mode & 0x2000)` 因此恒为 False，别信它。）
    # ★ 2026-10-04 复核（`_selftest/check_dirent_bits.py`，4 张卡共 450 个 dirent，
    #    按**结构证据**判定：该簇能否解析出 `.`/`..` 表）：
    #      目录 mode = 0x8427(211 个) + 0xA426(4 个，根目录的 `.` 项)
    #      文件 mode = 0x8497(235 个)          ⇒ 两类取值集合**完全不相交**
    #      bit4 / bit5 / bit7 三个位都能 100% 分离；bit13 在目录里只有 1.9%（就是那 4 个根 `.`）
    #    ⇒ 最稳的判据是**结构**（能不能解析出 `.` / `..` 表），其次才是 mode 值；
    #      **不要按名字判**：LR 的 `BISLPS-25462EMB` 目录里有一个**文件**也叫 `BISLPS-25462EMB`
    #      （32 字节头文件），按名字会被误判成目录（本脚本第一版就因此少扫了一轮）。
    #    这里仍按名字选（本工具只关心 `E##` / `EMB`），但请知道这只是"够用"而非"正确"。
    is_emb = bool(re.search(r"E\d\d$", nm)) or nm.endswith("EMB")
    if not is_emb:
        continue
    try:
        subs = card.dirents(e["cluster"], e["length"])
    except Exception as ex:
        print("\n[%s] 目录读失败: %s" % (nm, ex)); continue
    files = [s for s in subs if s["name"] not in (".", "..") and s["length"]]
    print("\n" + "=" * 70)
    print("★ [%s]  %d 个文件" % (nm, len(files)))
    for s in files:
        try:
            data = card.read_file(s["cluster"], s["length"])
        except Exception as ex:
            print("   %-12s 读失败: %s" % (s["name"], ex)); continue
        kind = af.save_kind(data)
        note = ""
        if kind in ("emblem-raw", "emblem-lr", "container"):
            try:
                off = af.find_offset(data) if kind == "container" else 0
                blk = data[off:off + (af.LR_SAVE_SIZE if af.is_lr_save(data) else af.SAVE_SIZE)]
                ok, bad = af.verify_checksums(blk if kind != "container" else data)
                note = "  校验%s" % ("18/18 通过 ✅" if ok else "有 %d 段不符 ❌" % len(bad))
            except Exception as ex:
                note = "  校验异常: %s" % ex
        print("   %-14s %7d B  %-12s%s" % (s["name"], s["length"], kind, note))
        found.append((nm, s["name"], data, kind))

print("\n" + "=" * 70)
print("=== 导出 ===")
from PIL import Image                                   # noqa: E402
n_ok = 0
for dirname, fname, data, kind in found:
    if kind not in ("emblem-raw", "emblem-lr", "container"):
        continue
    blk = data
    if kind == "container":
        off = af.find_offset(data)
        blk = data[off:off + (af.LR_SAVE_SIZE if len(data) - off == af.LR_SAVE_SIZE else af.SAVE_SIZE)]
    try:
        rgba = af.extract_image(blk, alpha_mode="index0")
    except Exception as ex:
        print("  %s/%s 提取失败: %s" % (dirname, fname, ex)); continue
    im = Image.frombytes("RGBA", (128, 128), rgba)
    safe = re.sub(r"[^0-9A-Za-z_.-]", "_", "%s__%s" % (dirname, fname))
    p = os.path.join(OUT, safe + ".png")
    im.save(p)
    op = sum(1 for i in range(3, len(rgba), 4) if rgba[i] == 255)
    print("  → %-44s 不透明 %5d px  %s" % (safe + ".png", op,
          "LR" if af.is_lr_save(blk) else "非LR"))
    n_ok += 1
print("\n共导出 %d 张 → %s" % (n_ok, OUT))
print("(只读；未向记忆卡写入任何字节)")
