# -*- coding: utf-8 -*-
r"""★ 第五张验证卡 `Mcd001_LRtest2.ps2` —— 自带"身份标识"，专治"模拟器读的到底是不是这张卡"。

> ⚠ **本文件开头那段"热插拔没真正生效"的推理已被推翻（2026-10-04 更晚）。**
> 真因是 **PCSX2 的每游戏记忆卡覆盖**：`gamesettings\SLPS-25462_FEBEC38B.ini` 里
> `[MemoryCards] Slot2_Filename = Mcd001_embdata2.ps2` 把 **LR 的 slot 2 钉死在源卡上**，
> 所以那个 slot 上永远是源卡内容，跟换卡/热插拔/缓存都无关。
> 详见 `04-末段校验差一字节.md` §十四.5；检查工具 `../tools/check_pcsx2_slots.py`。
> **下面原文保留，只作记录；不要再据此提"缓存/热插拔"类假设。**

## 为什么要这张

卡 3 的实测回报无法用同一张卡解释（详见 `04-末段校验差一字节.md` §十四）：
  · LR 显示"恶魔 / 红树 / 反色恶魔" ⇒ 只有**源卡**或卡 1 的 `data2` 是反色恶魔（卡 3 是玫瑰）
  · NX **卡死** ⇒ **源卡**的 NX 五槽 `0xDF` 全是 0（重复槽号），**必然卡死**；卡 3 已修成 0..4
  · SL = 2 个玫瑰 ⇒ 只有卡 3 是这样
⇒ 最自洽的解释是：**LR/NX 那次模拟器读到的仍是源卡内容**（热插拔没真正生效），
  到 SL 那次才切到卡 3。于是"N X 卡死 ⇒ 清零的作品常量有害"这条推论**不成立**。

（已离线排除的其它可能：`Mcd001_final3.ps2` 与建卡时副本逐字节相同 ⇒ 模拟器没回写；
  LR 目录无重名、无簇重叠、全部连续；`static.ico`/`icon.sys`/32B 头文件在四张卡上完全相同，
  而游戏在"有 data2"和"没 data2"的卡上画面不同 ⇒ **LR 缩略图确实来自 dataX**。）

## 本卡的两层"身份标识"

1. **改这里的 `icon.sys` 标题**（+ NX 各槽标题）—— 不改数据、只改标题字段：
      LR 保存的标题 → `ACLR LRtest2`
      NX 五个槽     → `NXTEST-0` … `NXTEST-4`
   ⇒ 在 **PCSX2 自己的记忆卡管理界面**（或 BIOS 浏览器）里就能看到这些字，
     **不用进游戏**就能确认 slot 上挂的确实是这张卡。
2. **LR 槽内容换成绝不可能混淆的图**：
      data0 不动（紫恶魔）／data1 ← **MIRAGE（蓝白）**／data2 ← **CREST（红黑）**

NX 五格仍用卡 1 已实机通过的配置（含 `0xDF` 0..4），作为对照。
"""
from __future__ import annotations

import hashlib
import importlib.util
import os
import shutil
import sys

MC_DIR = r"C:\Users\M\Documents\PCSX2\memcards"
SRC_CARD = os.path.join(MC_DIR, "Mcd001_embdata2.ps2")
DST_CARD = os.path.join(MC_DIR, "Mcd001_LRtest2.ps2")
PROJ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SURV = r"E:\Armored Core\Armored Core\PS2\AC3_CN\tools\30-存档\61_mc_survey.py"
US2JP = r"E:\Armored Core\Armored Core\PS2\AC3_CN\tools\30-存档\65_us2jp.py"
sys.path.insert(0, os.path.join(PROJ, "tools"))
import acet_format as af                                    # noqa: E402

REAL = os.path.join(PROJ, "testdata", "real")
OUT = os.path.join(PROJ, "out")
LR_DIR = "BISLPS-25462EMB"

TITLE_OFF = 0xC0          # icon.sys 里标题字符串的偏移
TITLE_LEN_BYTE = 0x06     # 标题字节数
TITLE_MAX = 0x68          # 68 字节


def load_mod(name, path):
    s = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(s)
    sys.modules[name] = m
    s.loader.exec_module(m)
    return m


sv = load_mod("sv", SURV)
us2jp = load_mod("us2jp", US2JP)
c0 = sv.Card(SRC_CARD)


def dirs(card):
    return {e["name"]: e for e in card.dirents(card.rootdir, card.dir_count(card.rootdir))
            if e["name"] not in (".", "..")}


def files_of(card, dn):
    d = dirs(card)[dn]
    return {s["name"]: s for s in card.dirents(d["cluster"], d["length"])
            if s["name"] not in (".", "..") and s["length"]}


def blob(card, dn, fn):
    s = files_of(card, dn)[fn]
    return card.read_file(s["cluster"], s["length"])


def load_img(path):
    return af.extract_image(af.read_save_file(path), alpha_mode="index0")


def retitle(ico: bytes, title: str) -> bytearray:
    """只改 icon.sys 的标题字段（0x06 长度 + 0xC0 起 68 字节），别的一律不动。"""
    b = bytearray(ico)
    t = title.encode('cp932')
    assert len(t) <= TITLE_MAX, "标题太长"
    b[TITLE_LEN_BYTE] = len(t)
    b[TITLE_OFF:TITLE_OFF + TITLE_MAX] = bytes(TITLE_MAX)
    b[TITLE_OFF:TITLE_OFF + len(t)] = t
    return b


IMG_MIRAGE = load_img(os.path.join(REAL, "BISLPS-25169E00.raw"))
IMG_CREST = load_img(os.path.join(REAL, "BISLPS-25338E00.raw"))
IMG_ROSE = load_img(os.path.join(REAL, "BASLUS-20644E02_rawblock.raw"))
TAIL_NX = af.header_tail_from_save(blob(c0, "BISLPS-25338E00", "BISLPS-25338E00"))
print("NX 作品常量 = %s" % TAIL_NX.hex(' '))
print("LR 块头     = %s" % af.LR_EMBLEM_HEADER.hex(' '))

# ---------- 构造 ----------
blocks, tags = {}, {}


def plan(dn, fn, tag, b):
    blocks[(dn, fn)] = bytes(b)
    tags[(dn, fn)] = tag


plan(LR_DIR, "data1", "★ LR 从零造 MIRAGE（蓝白）", af.encode_emblem(IMG_MIRAGE, is_lr=True))
plan(LR_DIR, "data2", "★ LR 从零造 CREST（红黑）", af.encode_emblem(IMG_CREST, is_lr=True))
plan("BISLPS-25338E00", "BISLPS-25338E00", "NX E00 玫瑰（卡1 已通过）", af.encode_emblem(IMG_ROSE, False, TAIL_NX))
plan("BISLPS-25338E01", "BISLPS-25338E01", "NX E01 MIRAGE（卡1 已通过）", af.encode_emblem(IMG_MIRAGE, False, TAIL_NX))
plan("BISLPS-25338E02", "BISLPS-25338E02", "NX E02 CREST（卡1 已通过）", af.encode_emblem(IMG_CREST, False, TAIL_NX))
plan("BISLPS-25338E03", "BISLPS-25338E03", "NX E03 玫瑰·不填未用项（卡1 已通过）",
     af.encode_emblem(IMG_ROSE, False, TAIL_NX, fill_unused=False))
plan("BISLPS-25338E04", "BISLPS-25338E04", "NX E04 真实 CREST 原样（卡1 已通过）",
     blob(c0, "BISLPS-25338E04", "BISLPS-25338E04"))

print("\n=== 构造 ===")
for (dn, fn), b in sorted(blocks.items()):
    is_lr = af.is_lr_save(b)
    okC, badC = af.verify_checksums(b)
    print("  %-26s %-42s 校验 真实%s" % (dn + "/" + fn, tags[(dn, fn)], "✅" if okC else "❌%r" % (badC,)))

# ---------- 写入 ----------
src_sha = hashlib.sha256(open(SRC_CARD, "rb").read()).hexdigest().upper()
shutil.copyfile(SRC_CARD, DST_CARD)
w = us2jp.Writable(DST_CARD)
touched = []


def write_file(dn, fn, data, note):
    s = files_of(w, dn)[fn]
    assert s["length"] == len(data), "%s/%s 长度 %d != %d" % (dn, fn, s["length"], len(data))
    ch = w.chain(s["cluster"], 4096)
    ncl = (len(data) + 1023) // 1024
    assert len(ch) >= ncl
    for i in range(ncl):
        w.write_cluster_bytes(ch[i], data[i * 1024:(i + 1) * 1024])
    touched.append((dn, s["cluster"], ncl))
    print("  %-30s %-16s %d 簇" % (dn + "/" + fn, note, ncl))


print("\n=== 写入徽章数据 ===")
for (dn, fn), b in sorted(blocks.items()):
    write_file(dn, fn, b, "")

print("\n=== 改标题（身份标识）===")
# LR：整个目录共用一个 icon.sys
ico = blob(w, LR_DIR, "icon.sys")
new = retitle(ico, "ACLR LRtest2")
write_file(LR_DIR, "icon.sys", bytes(new), "标题 → ACLR LRtest2")
# NX：每个槽一个 icon.sys（同时把槽位号 0xDF 从源卡的"全是 0"改成 0..4）
for i in range(5):
    dn = "BISLPS-25338E%02d" % i
    s = files_of(w, dn)["icon.sys"]
    ch = w.chain(s["cluster"], 8)
    ic = bytearray(w.read_file(s["cluster"], 1024))       # 整簇读写，保留空隙
    old = ic[0xDF]
    # ★ 顺序很重要：**0xDF（槽位号）落在标题字段内部**（标题第 31 字节），
    #   所以必须"先写标题、再写 0xDF"，否则清零标题字段会把槽位号一起抹掉 ⇒ NX 必卡死。
    t = ("NXTEST-%d" % i).encode('cp932')
    ic[TITLE_LEN_BYTE] = len(t)
    ic[TITLE_OFF:TITLE_OFF + TITLE_MAX] = bytes(TITLE_MAX)
    ic[TITLE_OFF:TITLE_OFF + len(t)] = t
    ic[0xDF] = i
    assert ic[0xDF] == i, "槽位号被标题覆盖了"
    w.write_cluster_bytes(ch[0], bytes(ic))
    touched.append((dn + "/icon.sys", s["cluster"], 1))
    print("  %-30s 0xDF %02X→%02X 标题 → NXTEST-%d" % (dn, old, i, i))
w.f.close()

# ---------- 回读 ----------
print("\n=== 回读 ===")
c2 = sv.Card(DST_CARD)
allok = True
for (dn, fn), want in sorted(blocks.items()):
    got = blob(c2, dn, fn)
    same = got == want
    print("  %-30s 与预期相同 %-5s 校验 %-5s" % (dn + "/" + fn, same, af.verify_checksums(got)[0]))
    allok = allok and same and af.verify_checksums(got)[0]
for dn, fn, note in ((LR_DIR, "data0", "LR 紫恶魔（对照，未动）"),
                     ("BISLPS-25169E00", "BISLPS-25169E00", "SL（未动）"),
                     ("BISLPS-25169E01", "BISLPS-25169E01", "SL（未动）")):
    same = blob(c2, dn, fn) == blob(c0, dn, fn)
    print("  %-30s 未改动 %-5s  （%s）" % (dn + "/" + fn, same, note))
    allok = allok and same
# 标题核对
ic = blob(c2, LR_DIR, "icon.sys")
print("  LR icon.sys 标题 = %r（长度字节 0x06 = %d）"
      % (ic[TITLE_OFF:TITLE_OFF + ic[TITLE_LEN_BYTE]].decode('cp932', 'replace'), ic[TITLE_LEN_BYTE]))
for i in range(5):
    dn = "BISLPS-25338E%02d" % i
    ic = blob(c2, dn, "icon.sys")
    print("  %s 标题 = %r  0xDF=%d"
          % (dn, ic[TITLE_OFF:TITLE_OFF + ic[TITLE_LEN_BYTE]].decode('cp932', 'replace'), ic[0xDF]))

# ---------- 逐页 diff ----------
a = open(SRC_CARD, "rb").read()
b = open(DST_CARD, "rb").read()
S = sv.mc.STRIDE
diff = [n for n in range(len(a) // S) if a[n * S:n * S + 512] != b[n * S:n * S + 512]]
exp = set()
for dn, first, ncl in touched:
    for cl in c2.chain(first, 4096)[:ncl]:
        exp.add(c2.data_page(cl, 0)); exp.add(c2.data_page(cl, 1))
print("\n全盘差异 %d 页 / %d；预期之外多改的页: %s"
      % (len(diff), len(a) // S, sorted(set(diff) - exp) or "无 ✅"))
print("源卡 SHA256 写前 = 写后: %s"
      % (src_sha == hashlib.sha256(open(SRC_CARD, "rb").read()).hexdigest().upper()))
shutil.copyfile(DST_CARD, os.path.join(OUT, os.path.basename(DST_CARD)))

try:
    from PIL import Image
    for (dn, fn), blk in blocks.items():
        Image.frombytes("RGBA", (128, 128),
                        af.extract_image(blk, alpha_mode="index0")).save(
            os.path.join(OUT, "lrtest2_%s_%s.png" % (dn, fn)))
    print("已导出预期外观 → out/lrtest2_*.png")
except Exception as e:
    print("(PNG 跳过: %s)" % e)

print("""
================================================================================
新卡：%s

★ 第 0 步（不用进游戏）：在 **PCSX2 的记忆卡管理界面**里确认 slot 上挂的是这个文件，
   并且 **LR 那条存档的标题显示 `ACLR LRtest2`**。看不到这个标题 ⇒ 挂的不是这张卡。
   （NX 五个槽的标题分别是 `NXTEST-0` … `NXTEST-4`。）

★ 第 1 步：**完全退出 PCSX2 再重新打开**（不要用运行中的热插拔），然后再进 LR：

【LR 日版】徽章画面应出现 **MIRAGE（蓝白）** 和 **CREST（红黑）**
     紫恶魔（没动）→ ★MIRAGE → ★CREST → …
   出现 ⇒ ★ LR 从零造打通（LR 块头就是之前卡死的原因）
   仍是"恶魔 / 红树 / 反色恶魔" ⇒ 模拟器读的仍不是这张卡（请回报标题那一栏看到什么）

【NX 日版】五格内容全部是卡 1 已实机通过的 ⇒ 应 5 格都正常（含不再卡死）
================================================================================
""" % DST_CARD)
raise SystemExit(0 if allok else 1)
