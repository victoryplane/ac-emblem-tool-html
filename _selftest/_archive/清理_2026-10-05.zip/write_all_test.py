# -*- coding: utf-8 -*-
r"""★★ 第六张卡 `Mcd001_TEST.ps2` —— 用"从没出现过的图"填满**所有**徽章槽。

## 为什么这么做

`Mcd001_LRtest2.ps2` 实测：磁盘上 `data1=MIRAGE`、`data2=CREST`（直读确认），
PCSX2 的 slot 2 也确认指向它，但 LR 画面显示的仍是**源卡**的"红树 / 反色恶魔"，
且磁盘文件与建卡副本逐字节相同 ⇒ **模拟器没有回写**，它读的是**内存里的旧卡**
（改 slot 的文件不会让运行中的 PCSX2 重读记忆卡）。

于是本卡的设计目标是：**让"有没有读到我这张卡"这件事一眼可判，且与格子顺序无关。**

做法：生成一张**用户从没见过的图**（洋红/青 8×8 棋盘 + 白边），
写进 **LR data0/data1/data2 + NX E00..E04 + SL E00/E01 共 10 个槽**。
你文件夹里任何旧卡都**不可能**有这张图 ⇒ 只要游戏里任何一格显示了它，
就证明读的是这张新卡。

（NX 槽位号 `0xDF` 仍要修成 0..4；SL 的 `0xDF` 本来就是 0/1，不动。
 **不改任何标题** —— 上一轮那个"标题标记"在你界面上看不到，已弃用。）
"""
from __future__ import annotations

import hashlib
import importlib.util
import os
import shutil
import sys

MC_DIR = r"C:\Users\M\Documents\PCSX2\memcards"
SRC_CARD = os.path.join(MC_DIR, "Mcd001_embdata2.ps2")
DST_CARD = os.path.join(MC_DIR, "Mcd001_TEST.ps2")
PROJ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SURV = r"E:\Armored Core\Armored Core\PS2\AC3_CN\tools\30-存档\61_mc_survey.py"
US2JP = r"E:\Armored Core\Armored Core\PS2\AC3_CN\tools\30-存档\65_us2jp.py"
sys.path.insert(0, os.path.join(PROJ, "tools"))
import acet_format as af                                    # noqa: E402

REAL = os.path.join(PROJ, "testdata", "real")
OUT = os.path.join(PROJ, "out")
LR_DIR = "BISLPS-25462EMB"


def load_mod(name, path):
    s = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(s)
    sys.modules[name] = m
    s.loader.exec_module(m)
    return m


sv = load_mod("sv", SURV)
us2jp = load_mod("us2jp", US2JP)
c0 = sv.Card(SRC_CARD)


def dirs(card):
    return {e["name"]: e for e in card.dirents(card.rootdir, card.dir_count(card.rootdir))
            if e["name"] not in (".", "..")}


def files_of(card, dn):
    d = dirs(card)[dn]
    return {s["name"]: s for s in card.dirents(d["cluster"], d["length"])
            if s["name"] not in (".", "..") and s["length"]}


def blob(card, dn, fn):
    s = files_of(card, dn)[fn]
    return card.read_file(s["cluster"], s["length"])


# ---------- 生成"从没出现过的图" ----------
MAGENTA = (255, 0, 255, 255)
CYAN = (0, 255, 255, 255)
WHITE = (255, 255, 255, 255)

TESTSET = set()
img = bytearray()
for y in range(128):
    for x in range(128):
        if x < 8 or x >= 120 or y < 8 or y >= 120:
            c = WHITE                                  # 白边
        elif ((x - 8) // 14 + (y - 8) // 14) % 2 == 0:
            c = MAGENTA
        else:
            c = CYAN
        img += bytes(c)
        TESTSET.add(c)
img = bytes(img)
assert len(TESTSET) <= 255, len(TESTSET)
print("★ 测试图：洋红/青 8×8 棋盘 + 白边，共 %d 色（你文件夹里任何旧卡都不会有它）" % len(TESTSET))

TAIL_SL = af.header_tail_from_save(blob(c0, "BISLPS-25169E00", "BISLPS-25169E00"))
TAIL_NX = af.header_tail_from_save(blob(c0, "BISLPS-25338E00", "BISLPS-25338E00"))

# ---------- 计划：所有徽章槽都写这张图 ----------
blocks, tags = {}, {}


def plan(dn, fn, tag, b):
    blocks[(dn, fn)] = bytes(b)
    tags[(dn, fn)] = tag


plan(LR_DIR, "data0", "LR 槽1", af.encode_emblem(img, is_lr=True))
plan(LR_DIR, "data1", "LR 槽2", af.encode_emblem(img, is_lr=True))
plan(LR_DIR, "data2", "LR 槽3", af.encode_emblem(img, is_lr=True))
for i in range(5):
    dn = "BISLPS-25338E%02d" % i
    plan(dn, dn, "NX 槽%d" % (i + 1), af.encode_emblem(img, False, TAIL_NX))
for i in range(2):
    dn = "BISLPS-25169E%02d" % i
    plan(dn, dn, "SL 槽%d" % (i + 1), af.encode_emblem(img, False, TAIL_SL))

print("\n=== 构造 %d 个槽 ===" % len(blocks))
for (dn, fn), b in sorted(blocks.items()):
    got = af.extract_image(b, alpha_mode="index0")
    okC, _ = af.verify_checksums(b)
    print("  %-26s %-8s 图往返一致 %-5s 校验 %s"
          % (dn + "/" + fn, tags[(dn, fn)], got == img, "✅" if okC else "❌"))

# ---------- 写入 ----------
src_sha = hashlib.sha256(open(SRC_CARD, "rb").read()).hexdigest().upper()
shutil.copyfile(SRC_CARD, DST_CARD)
w = us2jp.Writable(DST_CARD)
touched = []

print("\n=== 写入 ===")
for (dn, fn), b in sorted(blocks.items()):
    s = files_of(w, dn)[fn]
    assert s["length"] == len(b)
    ch = w.chain(s["cluster"], 4096)
    ncl = (len(b) + 1023) // 1024
    for i in range(ncl):
        w.write_cluster_bytes(ch[i], b[i * 1024:(i + 1) * 1024])
    touched.append((dn, s["cluster"], ncl))

print("=== 修 NX 槽位号 icon.sys@0xDF（源卡全是 0 ⇒ 会卡死）===")
for i in range(5):
    dn = "BISLPS-25338E%02d" % i
    s = files_of(w, dn)["icon.sys"]
    ch = w.chain(s["cluster"], 8)
    ic = bytearray(w.read_file(s["cluster"], 1024))     # 整簇；不碰标题
    old = ic[0xDF]
    ic[0xDF] = i
    assert ic[0xDF] == i
    w.write_cluster_bytes(ch[0], bytes(ic))
    touched.append((dn + "/icon.sys", s["cluster"], 1))
    print("  %-16s 0xDF %02X → %02X" % (dn, old, i))
w.f.close()

# ---------- 回读 ----------
print("\n=== 回读 ===")
c2 = sv.Card(DST_CARD)
allok = True
for (dn, fn), want in sorted(blocks.items()):
    got = blob(c2, dn, fn)
    same = got == want
    okC, _ = af.verify_checksums(got)
    imgok = af.extract_image(got, alpha_mode="index0") == img
    print("  %-26s 字节一致 %-5s 校验 %-5s 图一致 %-5s"
          % (dn + "/" + fn, same, "✅" if okC else "❌", imgok))
    allok = allok and same and okC and imgok

a = open(SRC_CARD, "rb").read()
b = open(DST_CARD, "rb").read()
S = sv.mc.STRIDE
diff = [n for n in range(len(a) // S) if a[n * S:n * S + 512] != b[n * S:n * S + 512]]
exp = set()
for dn, first, ncl in touched:
    for cl in c2.chain(first, 4096)[:ncl]:
        exp.add(c2.data_page(cl, 0)); exp.add(c2.data_page(cl, 1))
print("\n全盘差异 %d 页 / %d；预期之外多改的页: %s"
      % (len(diff), len(a) // S, sorted(set(diff) - exp) or "无 ✅"))
print("源卡 SHA256 写前 = 写后: %s"
      % (src_sha == hashlib.sha256(open(SRC_CARD, "rb").read()).hexdigest().upper()))
shutil.copyfile(DST_CARD, os.path.join(OUT, os.path.basename(DST_CARD)))

try:
    from PIL import Image
    Image.frombytes("RGBA", (128, 128), img).save(os.path.join(OUT, "TEST_测试图.png"))
    print("已导出 → out/TEST_测试图.png（这就是那 10 个槽应该显示的样子）")
except Exception as e:
    print("(PNG 跳过: %s)" % e)

print("""
================================================================================
新卡：%s

★★ 第 0 步（最重要）：**把 PCSX2 程序完全关掉**（不是退回标题画面，是把 PCSX2 窗口关掉），
   再重新打开。改 slot 的文件不会让运行中的 PCSX2 重读记忆卡。
   打开后确认 Memory Card slot 2 = `Mcd001_TEST.ps2`。

★ 第 1 步：这张卡上**所有 10 个徽章槽**都换成了同一张"你从没见过的图"
   （洋红/青色棋盘 + 白边，见 out/TEST_测试图.png）：

      LR：第 1、2、3 格
      NX：第 1~5 格
      SL：第 1、2 格

   只要**任何一格**显示了这张图 ⇒ 证明读的确实是这张新卡（旧卡里不可能有它）。

★ 注意：如果某一格显示的是"当前装备的徽章"，那一格**不是卡上的槽**，不用管它。

★ 请回报：LR / NX / SL 各看到几格是"棋盘图"、几格还是老样子。
================================================================================
""" % DST_CARD)
raise SystemExit(0 if allok else 1)
