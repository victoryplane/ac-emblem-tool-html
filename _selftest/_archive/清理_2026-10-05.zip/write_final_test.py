# -*- coding: utf-8 -*-
r"""★★★ 实机验证卡 `Mcd001_final.ps2` —— 检验"末段校验差一字节"这个根因修正。

已确立（见 validate_writer.py）：
  · 新写入器作用在 10 份真实存档上**逐字节复原**（最强正确性判据）
  · 紧凑编码的产物尾部现在是 `80 CB 01 00*9`，与游戏自己的 SL/NX 存档**完全一致**
  · 旧写法（尾部全零）在真实末段写法下差 0xFF ⇒ 这解释了一直以来的 `破損ファイル`

本卡一次问清 3 件事：
  ① 修正后**紧凑编码**能不能被游戏接受（这是通用导入工具的主路径）
  ② 两个作品（NX / SL）是否都成立
  ③ 未用调色板项"填不填"是否影响（尾段校验字节会因此从 CB 变成 4B）

NX 的 5 个槽原本是**逐字节相同的 5 份**，所以要先把 `icon.sys@0xDF`（槽位号）
从"全是 0"改成 0..4 —— 否则会卡死，测不出结果。

槽位安排（★ 每格的预期外观都不一样，好分辨）：
  NX E00 = 紧凑「玫瑰」+填满          ← 主修正测试
  NX E01 = 紧凑「MIRAGE(蓝白)」+填满
  NX E02 = 紧凑「CREST(红黑)」+填满   （用游戏自己的图走紧凑路径）
  NX E03 = 紧凑「玫瑰」**不填**未用项  ← 判别"填不填是否重要"
  NX E04 = 真实 CREST **原样通过**     ← 对照：应与原来一模一样
  SL E00 = 紧凑「玫瑰」+填满          ← 在 SL 上复现主修正
  SL E01 = 紧凑「CREST(红黑)」+填满

源卡只读；产物写到新卡。
"""
from __future__ import annotations

import hashlib
import importlib.util
import os
import shutil
import sys

MC_DIR = r"C:\Users\M\Documents\PCSX2\memcards"
SRC_CARD = os.path.join(MC_DIR, "Mcd001_embdata2.ps2")
DST_CARD = os.path.join(MC_DIR, "Mcd001_final.ps2")
PROJ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SURV = r"E:\Armored Core\Armored Core\PS2\AC3_CN\tools\30-存档\61_mc_survey.py"
US2JP = r"E:\Armored Core\Armored Core\PS2\AC3_CN\tools\30-存档\65_us2jp.py"
sys.path.insert(0, os.path.join(PROJ, "tools"))
import acet_format as af                                    # noqa: E402

REAL = os.path.join(PROJ, "testdata", "real")
OUT = os.path.join(PROJ, "out")


def load_mod(name, path):
    s = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(s)
    sys.modules[name] = m
    s.loader.exec_module(m)
    return m


sv = load_mod("sv", SURV)
us2jp = load_mod("us2jp", US2JP)
c0 = sv.Card(SRC_CARD)


def dirs(card):
    return {e["name"]: e for e in card.dirents(card.rootdir, card.dir_count(card.rootdir))
            if e["name"] not in (".", "..")}


def files_of(card, dn):
    d = dirs(card)[dn]
    return {s["name"]: s for s in card.dirents(d["cluster"], d["length"])
            if s["name"] not in (".", "..") and s["length"]}


def blob(card, dn, fn):
    s = files_of(card, dn)[fn]
    return card.read_file(s["cluster"], s["length"])


# ---------- 素材 ----------
def load_img(path, alpha="index0"):
    return af.extract_image(af.read_save_file(path), alpha_mode=alpha)


IMG_ROSE = load_img(os.path.join(REAL, "BASLUS-20644E02_rawblock.raw"))
IMG_MIRAGE = load_img(os.path.join(REAL, "BISLPS-25169E00.raw"))
IMG_CREST = load_img(os.path.join(REAL, "BISLPS-25338E00.raw"))
TAIL_NX = af.header_tail_from_save(blob(c0, "BISLPS-25338E00", "BISLPS-25338E00"))
TAIL_SL = af.header_tail_from_save(blob(c0, "BISLPS-25169E00", "BISLPS-25169E00"))
print("NX 作品常量 = %s" % TAIL_NX.hex(' '))
print("SL 作品常量 = %s" % TAIL_SL.hex(' '))

PLAN = [
    # (槽目录名, 标签, 数据块)
    ("BISLPS-25338E00", "紧凑玫瑰 + 填满", lambda: af.encode_emblem(IMG_ROSE, False, TAIL_NX)),
    ("BISLPS-25338E01", "紧凑 MIRAGE + 填满", lambda: af.encode_emblem(IMG_MIRAGE, False, TAIL_NX)),
    ("BISLPS-25338E02", "紧凑 CREST + 填满", lambda: af.encode_emblem(IMG_CREST, False, TAIL_NX)),
    ("BISLPS-25338E03", "紧凑玫瑰 ★不填未用项", lambda: af.encode_emblem(IMG_ROSE, False, TAIL_NX,
                                                                        fill_unused=False)),
    ("BISLPS-25338E04", "真实 CREST 原样通过", None),        # None = 原字节 + 重算校验
    ("BISLPS-25169E00", "紧凑玫瑰 + 填满", lambda: af.encode_emblem(IMG_ROSE, False, TAIL_SL)),
    ("BISLPS-25169E01", "紧凑 CREST + 填满", lambda: af.encode_emblem(IMG_CREST, False, TAIL_SL)),
]

newblk = {}
print("\n=== 构造 ===")
for dn, tag, build in PLAN:
    s = files_of(c0, dn)[dn]
    orig = blob(c0, dn, dn)
    if build is None:
        b = bytearray(orig)
        af.apply_checksums(b)                 # 应逐字节复原
        assert bytes(b) == orig, "原样通过竟然改了字节"
        b = bytes(b)
    else:
        b = bytes(build())
    assert len(b) == len(orig) == af.SAVE_SIZE
    okC, badC = af.verify_checksums(b)
    okA, _ = af.verify_checksums_upstream(b)
    newblk[dn] = b
    # ★ 该槽写出来的图必须能逐像素还原（防止调色板映射 / 乱序 / 索引出错）
    got = af.extract_image(b, alpha_mode="index0")
    which = {IMG_ROSE: "玫瑰", IMG_MIRAGE: "MIRAGE", IMG_CREST: "CREST"}.get(got)
    assert which is not None or build is None, "%s 提取回来的图对不上任何素材" % dn
    print("  %-16s %-22s 图=%-6s 引用槽 %3d  末段 %02X %02X %s  校验 真实%s 上游%s"
          % (dn, tag, which or "(原样)", len(af.used_palette_slots(b)), b[0x4434], b[0x4435],
             b[0x4436:0x4440].hex(' ')[:8],
             "✅" if okC else "❌%r" % (badC,), "✅" if okA else "❌"))

# ---------- 写入 ----------
src_sha = hashlib.sha256(open(SRC_CARD, "rb").read()).hexdigest().upper()
shutil.copyfile(SRC_CARD, DST_CARD)
c = us2jp.Writable(DST_CARD)
roots = dirs(c)
touched = []

print("\n=== 写入徽章数据 ===")
for dn, tag, _ in PLAN:
    s = files_of(c, dn)[dn]
    ch = c.chain(s["cluster"], 4096)
    ncl = (len(newblk[dn]) + 1023) // 1024
    assert len(ch) >= ncl
    for i in range(ncl):
        c.write_cluster_bytes(ch[i], newblk[dn][i * 1024:(i + 1) * 1024])
    touched.append((dn, s["cluster"], ncl))
    print("  %-16s %d 簇" % (dn, ncl))

print("\n=== 修 NX 槽位号 icon.sys@0xDF（原本全是 0 ⇒ 会卡死）===")
for i in range(5):
    dn = "BISLPS-25338E%02d" % i
    s = files_of(c, dn)["icon.sys"]
    ch = c.chain(s["cluster"], 8)
    # ★ 读满整簇（1024 B）而不是文件长度（964 B）：文件长度之外的空隙字节也原样写回，
    #   否则会把它们清成 0，造成多余的页改动。
    ic = bytearray(c.read_file(s["cluster"], 1024))
    old = ic[0xDF]
    ic[0xDF] = i
    assert 0xDF < s["length"], "0xDF 落在文件长度之外了"
    c.write_cluster_bytes(ch[0], bytes(ic))
    print("  %-16s 0xDF %02X → %02X（整簇 1024 B 写回，空隙保留）" % (dn, old, i))
    touched.append((dn + "/icon.sys", s["cluster"], 1))
c.f.close()

# ---------- 回读 ----------
print("\n=== 回读 ===")
c2 = sv.Card(DST_CARD)
allok = True
for dn, tag, _ in PLAN:
    got = blob(c2, dn, dn)
    same = got == newblk[dn]
    okC, _ = af.verify_checksums(got)
    eccbad = []
    d = dirs(c2)[dn]
    s = files_of(c2, dn)[dn]
    ch = c2.chain(s["cluster"], 4096)
    for cl in ch[:(len(got) + 1023) // 1024]:
        for k in range(2):
            if not c2.c.ecc_ok(c2.data_page(cl, k)):
                eccbad.append(cl)
    print("  %-16s 与预期相同 %-5s 校验 %-5s ECC %s"
          % (dn, same, "✅" if okC else "❌", "✅" if not eccbad else "❌ %s" % eccbad))
    allok = allok and same and okC and not eccbad
for i in range(5):
    dn = "BISLPS-25338E%02d" % i
    ic = blob(c2, dn, "icon.sys")
    print("  %-16s icon.sys@0xDF = %d" % (dn, ic[0xDF]))

# ---------- 逐页 diff ----------
a = open(SRC_CARD, "rb").read()
b = open(DST_CARD, "rb").read()
S = sv.mc.STRIDE
diff = [n for n in range(len(a) // S) if a[n * S:n * S + 512] != b[n * S:n * S + 512]]
exp = set()
for dn, first, ncl in touched:
    ch = c2.chain(first, 4096)
    for cl in ch[:ncl]:
        exp.add(c2.data_page(cl, 0)); exp.add(c2.data_page(cl, 1))
print("\n全盘差异 %d 页 / %d；预期之外多改的页: %s"
      % (len(diff), len(a) // S, sorted(set(diff) - exp) or "无 ✅"))
print("源卡 SHA256 写前 = 写后: %s"
      % (src_sha == hashlib.sha256(open(SRC_CARD, "rb").read()).hexdigest().upper()))

shutil.copyfile(DST_CARD, os.path.join(OUT, os.path.basename(DST_CARD)))

# ---------- 预期外观 ----------
try:
    from PIL import Image
    for dn, tag, _ in PLAN:
        Image.frombytes("RGBA", (128, 128),
                        af.extract_image(newblk[dn], alpha_mode="index0")).save(
            os.path.join(OUT, "final_%s.png" % dn))
    print("\n已导出预期外观 7 张 → out/final_*.png")
except Exception as e:
    print("(PNG 跳过: %s)" % e)

print("""
================================================================================
新卡：%s
挂到 PCSX2 的 slot，进游戏【徽章】画面，逐格 load，按下表回报哪几格是「破損ファイル」：

  NX 槽 1 (E00)  应显示【玫瑰】            ← ★ 主修正测试
  NX 槽 2 (E01)  应显示【MIRAGE 蓝白】
  NX 槽 3 (E02)  应显示【CREST 红黑】
  NX 槽 4 (E03)  应显示【玫瑰】            ← 不填未用项；尾段校验字节是 4B 而非 CB
  NX 槽 5 (E04)  应显示【CREST 红黑】      ← 对照：原样数据，必须正常
  SL 槽 1 (E00)  应显示【玫瑰】            ← ★ 在 SL 上复现
  SL 槽 2 (E01)  应显示【CREST 红黑】

★ 判读：
   全 7 格都正常            ⇒ 根因确认（末段校验差一字节），非 LR 写入打通
   只有 4 格 (E03) 破損     ⇒ 校验位置对了，但"未用调色板项"确实要按游戏惯例填
   5 格 (E04) 也破損        ⇒ 写入器还有别的问题（对照格都坏了）
   第 1 格好、第 6/7 格也破 ⇒ NX 与 SL 有作品级差异，需要分开定位
================================================================================
""" % DST_CARD)
raise SystemExit(0 if allok else 1)
