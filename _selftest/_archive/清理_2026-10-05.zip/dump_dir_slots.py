# -*- coding: utf-8 -*-
r"""只读：把一张卡上目录的**槽位**逐页列出来，回答三个问题：

1. **一个 dirent 多大？** —— 本脚本按 **512 字节 = 一页一项**（实测：`. ` 条目的 name 字段
   正好落在页内 `0x40`，所以"64 字节一项、一页 8 项"的假设是错的）。
2. **"空槽"在真卡上长什么样？**（mode 全 FF？全 0？bit15=0？）
3. **"从未被写过的页"长什么样？**（备用区是不是 `FF×16`）

为什么要问：往 LR 的 `BISLPS-25462EMB` 里新建槽时，实现选择了"**再分配一个簇**"。
若该目录其实有空槽，这个选择就是错的；若它真满了（4 簇 × 2 页 = 8 槽 = 8 项），
扩簇就是唯一出路 —— 而新扩出来的簇第 1 页从未被写过，得确认这种页在真卡上的形态。

    python _selftest\dump_dir_slots.py [卡路径]
"""
from __future__ import annotations

import importlib.util
import os
import sys

SURV = r"E:\Armored Core\Armored Core\PS2\AC3_CN\tools\30-存档\61_mc_survey.py"
PROJ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

spec = importlib.util.spec_from_file_location("sv", SURV)
sv = importlib.util.module_from_spec(spec)
spec.loader.exec_module(sv)

CARD = sys.argv[1] if len(sys.argv) > 1 else os.path.join(PROJ, "out", "evidence", "Mcd001_embdata2.ps2")
RAW = open(CARD, "rb").read()
card = sv.Card(CARD)
print("卡: %s（%d 字节）\n" % (os.path.basename(CARD), len(RAW)))


def pdata(n):
    return RAW[n * 528:n * 528 + 512]


def pspare(n):
    return RAW[n * 528 + 512:n * 528 + 528]


def spare_tag(n):
    s = pspare(n)
    if s == b"\xff" * 16:
        return "FF×16(未写入)"
    if s == b"\x00" * 16:
        return "全0"
    return "其它:" + s[:4].hex()


def dirent_at(n):
    d = pdata(n)
    mode = int.from_bytes(d[0:4], "little")
    length = int.from_bytes(d[4:8], "little")
    clu = int.from_bytes(d[0x10:0x14], "little")
    nm = d[0x40:0x60].split(b"\x00")[0]
    try:
        nm = nm.decode("shift_jis", "replace")
    except Exception:
        nm = repr(nm)
    # ★ 空槽的判据：整页 0xFF（真卡实测形态）**或** bit15=0（未使用）。
    #   ⚠ 0xFFFFFFFF 的 bit15 = 1，只按 bit15 判会把空槽当成"已用"（我第一版就错了）。
    empty = (mode == 0xFFFFFFFF) or (mode & 0x8000) == 0
    return mode, length, clu, nm, not empty


def dump_dir(label, first, declared):
    chain = card.chain(first, 4096)
    print("=== %s  cluster=%d  声明项数=%d  簇链=%s（%d 簇 = %d 槽）==="
          % (label, first, declared, chain, len(chain), len(chain) * 2))
    used = 0
    total = 0
    for ci, cl in enumerate(chain):
        for page in (0, 1):
            n = card.data_page(cl, page)
            mode, length, clu, nm, exists = dirent_at(n)
            total += 1
            used += 1 if exists else 0
            print("  簇[%d] cl%-5d 页%d 绝对页%-6d mode=0x%08X %s len=%-6d clu=%-6d %-22r 备用区=%s"
                  % (ci, cl, page, n, mode, "用" if exists else "空", length, clu, nm, spare_tag(n)))
    print("  ⇒ %d 槽用了 %d 个：%s\n"
          % (total, used, "**满了，新建必须扩簇**" if used == total else "还有空槽，不该扩簇"))
    return used, total


print("=== 每个目录：链上到底有没有空槽 ===")
roots = card.dirents(card.rootdir, card.dir_count(card.rootdir))
print("（根目录自己）")
dump_dir("根目录", card.rootdir, card.dir_count(card.rootdir))
for e in roots:
    if e["name"] in (".", "..") or not e["length"]:
        continue
    if not (e["name"].endswith("EMB") or e["name"].endswith("GAME")):
        continue
    dump_dir(e["name"], e["cluster"], e["length"])

print("=== 参考：真卡上「部分使用的目录簇」（只看备用区，判断未写入页的形态）===")
for cl in card.chain(card.rootdir, 4096):
    line = "  cl%-5d" % cl
    for page in (0, 1):
        n = card.data_page(cl, page)
        _, _, _, _, exists = dirent_at(n)
        line += "  页%d: %s 备用=%s" % (page, "用" if exists else "空", spare_tag(n))
    print(line)
