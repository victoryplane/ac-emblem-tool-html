#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""acet 的命令行版本 —— 官方 `acet.exe` / `acet-cli.exe` 的 Python 等价实现。

命令行兼容上游用法（拖动文件到脚本上也能用）：

    python tools/acet_cli.py SAVEFILE              # 提取 → SAVEFILE.png
    python tools/acet_cli.py SAVEFILE IMAGE.png    # 注入（先备份为 SAVEFILE.backup）

另外多出几个上游没有的开关：

    python tools/acet_cli.py SAVEFILE --info       # 只打印结构信息，不改文件
    python tools/acet_cli.py SAVEFILE --verify      # 独立复核校验字节
    python tools/acet_cli.py SAVEFILE --out X.png   # 指定提取输出路径
    python tools/acet_cli.py SAVEFILE IMAGE.png --no-fill-unused   # 注入时不填未用调色板项

★ 末段校验字节按**真实位置**写（非 LR `0x4435` / LR `0x4415`）。
  上游 `acet` 写在 `0x4434` / `0x4414`，差一个字节 —— 它之所以"能用"是因为总在已有
  存档上原地注入；**从空白块造**存档会被游戏判 `破損ファイル`。
  详见 `_selftest/04-末段校验差一字节.md`。

与官方 exe 的差别（有意为之）：
  * 不弹"Press enter key to continue"，出错直接非零退出，方便脚本调用；
  * 颜色数溢出时**报错**而不是静默截断（上游会串色，见 docs/01-项目理解/05-限制与已知问题.md）；
  * 注入前默认自动备份（与 v1.0.1+ 行为一致）。

图像读写依赖 Pillow（`pip install Pillow`）；格式核心 acet_format.py 零依赖。
"""

from __future__ import annotations

import argparse
import os
import shutil
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import acet_format as af  # noqa: E402


def _need_pillow():
    try:
        from PIL import Image  # noqa: F401
    except ImportError:
        sys.exit("需要 Pillow 来读写 PNG：pip install Pillow\n"
                 "（或直接用官方二进制 dist/v1.0.2/acet.exe，它自带 LodePNG）")


def img_size_for(save: bytes) -> tuple[int, int]:
    return af.IMAGE_WIDTH, af.IMAGE_HEIGHT


def cmd_info(save: bytes, path: str) -> int:
    kind = af.save_kind(save)
    print("文件       : %s" % path)
    print("大小       : %d 字节 (0x%X)" % (len(save), len(save)))
    print("判定       : %s" % {
        "emblem-raw": "非 LR 原始徽章存档 (0x4440)",
        "emblem-lr": "Last Raven 原始徽章存档 (0x4420)",
        "container": "容器/记忆卡文件（内含徽章块，靠 12 字节魔数定位）",
        "unknown": "无法识别",
    }.get(kind, kind))

    if kind in ("unknown",):
        return 1

    is_lr = af.is_lr_save(save)
    base = af.find_offset(save) if len(save) > af.SAVE_SIZE else 0
    print("徽章块起点 : 0x%X" % base)
    print("布局       : %s" % ("Last Raven（调色板不乱序）" if is_lr else "非 LR（调色板乱序）"))
    img_off = af.LR_IMAGE_OFFSET if is_lr else af.IMAGE_OFFSET
    print("图像偏移   : 徽章块 + 0x%X，%d×%d 索引色"
          % (img_off, af.IMAGE_WIDTH, af.IMAGE_HEIGHT))
    print("调色板偏移 : 徽章块 + 0x%X（256 项 × 4 通道）"
          % af.offset_index(img_off + af.NUM_PIXELS, base))
    print("末段数据   : 徽章块 + 0x%X 起 %d 字节（含 palette[255].alpha @+0x%X）"
          % (af.FINAL_SEG_OFF, af.FINAL_DATA_LEN[is_lr], af.FINAL_ALPHA_POS[is_lr]))
    print("末段校验位 : 徽章块 + 0x%X   ← ★ 真实位置（上游那个早一字节的写法见 "
          "apply_checksums_upstream）" % af.FINAL_CHECK_POS[is_lr])

    # ★★ 统计必须**逐像素 / 逐字节**走 offset_index ——
    #    像素区与调色板区中间都夹着校验字节（每 0x3FF 逻辑字节 1 个），
    #    用连续切片 `save[o : o+N]` 读会在第一个校验字节之后**整体错位**。
    #    （本函数早先就是这么写的，导致"索引 0 的像素数"少数了 16 个。）
    def pix(i):
        return save[af.offset_index(img_off + i, base)]

    def pal(k, ch):
        return save[af.offset_index(img_off + af.NUM_PIXELS + k * 4 + ch, base)]

    indices = bytes(pix(i) for i in range(af.NUM_PIXELS))
    used = sorted(set(indices))
    print("索引取值范围: %d..%d，实际用到 %d 个索引"
          % (min(used), max(used), len(used)))
    # ★ 与游戏一致的口径：**索引 0 = 背景/透明**（实机定案，见 02-存档格式规范.md §五）。
    #   alpha 字节**不是**游戏用的判据 —— 这里两个都报，避免再被字节误导。
    zero_alpha = [k for k in range(256) if pal(k, 3) == 0]
    transparent = sum(1 for b in indices if b == 0)
    print("调色板 alpha=0 的项: %d 个%s"
          % (len(zero_alpha), ("（前几个：%s）" % zero_alpha[:8]) if zero_alpha else ""))
    print("透明像素数 : %d / %d (%.1f%%)   ← ★ 按「索引 0 = 透明」（与实机一致）"
          % (transparent, af.NUM_PIXELS, 100.0 * transparent / af.NUM_PIXELS))
    if 0 in used:
        t = []
        for ch in range(3):
            t.append(pal(0, ch))
        print("索引 0 的调色板项: %s  （alpha=0x%02X；⚠ alpha 不影响显示）"
              % (" ".join("%02x" % v for v in t), pal(0, 3)))

    ok, bad = af.verify_checksums(save)
    print("校验字节   : %s" % ("全部自洽" if ok else "有 %d 段不符" % len(bad)))
    for name, pos, got, want in bad[:10]:
        print("             %s @0x%X 文件=0x%02X 期望=0x%02X" % (name, pos, got, want))
    return 0


def cmd_verify(save: bytes) -> int:
    ok, bad = af.verify_checksums(save)
    if ok:
        print("校验全部通过（18 段）")
        return 0
    print("校验不通过，%d 段不符：" % len(bad))
    for name, pos, got, want in bad:
        print("  %-14s @0x%-6X 文件=0x%02X 期望=0x%02X" % (name, pos, got, want))
    return 1


def cmd_extract(save: bytes, out: str | None, path: str, alpha_mode: str) -> int:
    _need_pillow()
    from PIL import Image
    rgba = af.extract_image(save, alpha_mode=alpha_mode)
    w, h = img_size_for(save)
    im = Image.frombytes("RGBA", (w, h), rgba)
    out = out or (path + ".png")
    im.save(out)
    print("已提取 → %s  (%d×%d, alpha=%s)" % (out, w, h, alpha_mode))
    return 0


def cmd_inject(save: bytearray, image_path: str, path: str, no_backup: bool,
               fill_unused: bool = True) -> int:
    _need_pillow()
    from PIL import Image
    im = Image.open(image_path).convert("RGBA")
    if im.size != (af.IMAGE_WIDTH, af.IMAGE_HEIGHT):
        print("提示：图像是 %dx%d，上游要求恰好 %dx%d —— 这里按最近邻缩放到目标尺寸"
              % (im.size[0], im.size[1], af.IMAGE_WIDTH, af.IMAGE_HEIGHT))
        im = im.resize((af.IMAGE_WIDTH, af.IMAGE_HEIGHT), Image.NEAREST)
    rgba = im.tobytes()

    # 预估颜色数，避免上游那种"静默截断"
    _, pal = af.inject_pixels_to_indices(rgba)
    print("量化后调色板项数：%d（含透明项 1）" % len(pal))
    if len(pal) > 256:
        sys.exit("错误：颜色数超过上限（最多 255 色 + 透明）。请先减色再注入。")

    if not no_backup:
        bak = path + ".backup"
        shutil.copyfile(path, bak)
        print("已备份 → %s" % bak)

    af.inject_image(save, rgba)
    if fill_unused:
        # 游戏自己写的存档里，未用调色板项的 alpha 一律是 0x80（槽 0 除外），不留 0。
        # 只影响"没被任何像素引用"的项 ⇒ 不改变图像。
        n = af.fill_unused_palette(save)
        af.apply_checksums(save)
        print("已按游戏惯例填满未用调色板项：%d 项 → 00 00 00 80" % n)
    af.write_save_file(path, save)
    print("已注入 → %s" % path)

    ok, bad = af.verify_checksums(bytes(save))
    print("写后校验：%s" % ("通过" if ok else "不通过 %r" % (bad[:3],)))
    return 0 if ok else 1


def main(argv: list[str]) -> int:
    ap = argparse.ArgumentParser(
        prog="acet_cli.py", add_help=True,
        description="AC PS2 徽章存档工具（PNG 提取 / 注入）")
    ap.add_argument("save", help="徽章存档文件（或含徽章块的容器）")
    ap.add_argument("image", nargs="?", help="要注入的 PNG；给了就注入，不给就提取")
    ap.add_argument("--info", action="store_true", help="只打印结构信息")
    ap.add_argument("--verify", action="store_true", help="只复核校验字节")
    ap.add_argument("--out", help="提取输出路径（默认 SAVEFILE.png）")
    ap.add_argument("--alpha", choices=("acet", "gs", "index0"), default="acet",
                    help="alpha 归一方式：acet=上游行为（任何非零 alpha 都当成全不透明；"
                         "用于与官方 exe 逐像素对齐）；index0=★与实机显示一致（调色板索引 0 透明、"
                         "其余不透明，忽略 alpha 字节）；gs=按 PS2 GS 0..0x80 映射（分析用，实机证明不是游戏行为）")
    ap.add_argument("--no-backup", action="store_true", help="注入前不备份")
    ap.add_argument("--no-fill-unused", action="store_true",
                    help="注入后不填未用调色板项。默认会填（游戏自己写的存档里未用项 alpha 一律 "
                         "0x80，槽 0 除外）；只影响没被任何像素引用的项，不改变图像。"
                         "★ 实机已确认**不是必需**，填它只是让输出与游戏产物同形"
                         "（见 _selftest/04-末段校验差一字节.md §八）")
    args = ap.parse_args(argv)

    if not os.path.exists(args.save):
        sys.exit("找不到文件：%s" % args.save)

    save = af.read_save_file(args.save)
    kind = af.save_kind(save)

    if args.info:
        return cmd_info(save, args.save)
    if args.verify:
        return cmd_verify(save)

    if kind == "unknown":
        sys.exit("无法识别：%s 既不是徽章存档（0x4440 / 0x4420），"
                 "也不含 12 字节魔数。" % args.save)

    if args.image:
        if not os.path.exists(args.image):
            sys.exit("找不到图像：%s" % args.image)
        return cmd_inject(bytearray(save), args.image, args.save, args.no_backup,
                          fill_unused=not args.no_fill_unused)
    return cmd_extract(save, args.out, args.save, args.alpha)


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
