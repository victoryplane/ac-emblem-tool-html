# -*- coding: utf-8 -*-
r"""穷举卡上所有 dirent，判定**哪个 mode 位才是"目录"位**。

背景：`61_mc_survey.py` 用 `mode & 0x2000` 判目录（恒为 False，有坑）；
`dump_card_emblems.py` 的注释说"本卡实测目录 = 0x8427、文件 = 0x8497，两者的 bit13 都是 0"。
后来 TS 移植时又有人报告 "bit7 才是唯一能 100% 分离的位" —— 两说都只给了一半。
本脚本把 4 张证据卡上**全部 dirent** 拉出来，按"结构证据"给每个条目判定目录/文件，再逐位统计。

判定"是目录"的**结构证据**（不依赖 mode 位）：
  · 名字是 `.` / `..`
  · 名字形如 `E##` 或以 `EMB` 结尾（徽章存档目录，已知）
  · 该 entry 指向的簇，第 0 页能解析出**合法的 dirent 表**（名字可打印、length 合理）

    python _selftest\check_dirent_bits.py
"""
from __future__ import annotations

import importlib.util
import os
import re
import sys

SURV = r"E:\Armored Core\Armored Core\PS2\AC3_CN\tools\30-存档\61_mc_survey.py"
PROJ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
EVID = os.path.join(PROJ, "out", "evidence")

spec = importlib.util.spec_from_file_location("sv", SURV)
sv = importlib.util.module_from_spec(spec)
spec.loader.exec_module(sv)


def is_dir_by_structure(card, e):
    """★ 结构证据：一个条目的簇第 0 页能否解析出以 `.` / `..` 开头的表。

    这是**唯一可靠**的判据 —— 按名字判会踩坑：LR 的 `BISLPS-25462EMB` 目录里
    有一个**文件**也叫 `BISLPS-25462EMB`（32 字节头），按名字会被误判成目录。
    """
    if e["name"] in (".", ".."):
        return True
    if not e.get("length"):
        return False
    try:
        ents = card.dirents(e["cluster"], 2)
    except Exception:
        return False
    return (len(ents) >= 2
            and ents[0].get("name") == "." and ents[1].get("name") == "..")


rows = []
for card_path in sorted(
        os.path.join(EVID, f) for f in os.listdir(EVID) if f.endswith(".ps2")):
    card = sv.Card(card_path)
    roots = card.dirents(card.rootdir, card.dir_count(card.rootdir))
    for e in roots:
        kind = "dir" if is_dir_by_structure(card, e) else "file"
        rows.append((os.path.basename(card_path), e["name"], e["mode"], kind, e["length"]))
        if e["name"] in (".", "..") or not e["length"]:
            continue
        try:
            kids = card.dirents(e["cluster"], e["length"])
        except Exception:
            kids = []
        for s in kids:
            k2 = "dir" if is_dir_by_structure(card, s) else "file"
            rows.append((os.path.basename(card_path), e["name"] + "/" + s["name"],
                         s["mode"], k2, s["length"]))

print("=== 全部 dirent 的 mode × 结构判定 ===")
from collections import Counter
cnt = Counter((r[2], r[3]) for r in rows)
for (mode, tag), n in sorted(cnt.items()):
    print("   mode=0x%04X  结构上=%-4s × %d" % (mode, tag, n))

print("\n=== 逐位分析（按结构判定分组）===")
dirs = [(r[1], r[2]) for r in rows if r[3] == "dir"]
files = [(r[1], r[2]) for r in rows if r[3] == "file"]
print("   目录样本 %d 个，文件样本 %d 个" % (len(dirs), len(files)))
print("\n   位     掩码     目录里为1    文件里为1    分离?")
for bit in range(16):
    mask = 1 << bit
    d = sum(1 for _, m in dirs if m & mask) / max(1, len(dirs))
    f = sum(1 for _, m in files if m & mask) / max(1, len(files))
    sep = ""
    if d == 0 and f == 1:
        sep = "★ 能（文件=1 目录=0）"
    elif d == 1 and f == 0:
        sep = "★ 能（目录=1 文件=0）"
    print("   bit%-2d  0x%04X   %5.1f%%       %5.1f%%      %s"
          % (bit, mask, d * 100, f * 100, sep))

print("\n=== 结论 ===")
dset = sorted({m for _, m in dirs})
fset = sorted({m for _, m in files})
print("   目录 mode 取值: %s" % ", ".join("0x%04X" % m for m in dset))
print("   文件 mode 取值: %s" % ", ".join("0x%04X" % m for m in fset))
common = set(dset) & set(fset)
print("   两者共有取值  : %s" % (", ".join("0x%04X" % m for m in sorted(common)) or "无"))
if dset and fset:
    x = dset[0] ^ fset[0]
    print("   示例异或 0x%04X ⇒ 差异位: %s"
          % (x, ", ".join("bit%d(0x%04X)" % (b, 1 << b) for b in range(16) if x & (1 << b))))
print("\n   反例（mode 与结构不符的条目，最多 10 条）:")
bad = 0
for name, mode, kind in [(r[1], r[2], r[3]) for r in rows]:
    if (mode == 0x8497 and kind == "dir") or (mode == 0x8427 and kind == "file"):
        print("      0x%04X  %-44s 结构上=%s" % (mode, name[:44], kind))
        bad += 1
        if bad >= 10:
            break
if not bad:
    print("      （无 —— 说明有某个位能 100% 分离，见上表）")
