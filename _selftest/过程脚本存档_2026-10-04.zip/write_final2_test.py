# -*- coding: utf-8 -*-
r"""★ 第二张验证卡 `Mcd001_final2.ps2` —— 把剩下两个悬案一次问清。

背景：`Mcd001_final.ps2` 已实机确认 **7/7 格正常读取** ⇒ 非 LR 写入打通
（根因＝末段校验写早一个字节，见 `04-末段校验差一字节.md`）。剩下的问题：

  ① **非 LR 头里那 9 字节「作品常量」（0x14..0x1C）到底会不会被游戏校验？**
     若**不会** ⇒ AC2 / AC2AA / AC3 / NB 就**不再被"必须有该作品的真实徽章样本"卡住**，
     对"通用导入工具"是实质利好。
     唯一那条正面证据（`bisect` 卡 E02）有两个混淆因素：那轮用的是**旧写入器**，
     且卡上 NX 槽 `icon.sys@0xDF` 全是 0。现在写入器已修正、槽位号也修好了，可以干净复测。

  ② **LR 从零造**（把 UIImage 编成 LR 块写进槽，而不是在真实块上原地注入）
     —— 推断已打通（旧写入器在 LR 上空尾同样差 0xFF），但从未实机验证。

槽位安排：

  NX（日版 SLPS-25338；★ 5 个槽的 `icon.sys@0xDF` 会一并修成 0..4，否则卡死）
    E00 = 紧凑玫瑰 + 作品常量 **清零**        ← ★ 关键：问"是否被校验"
    E01 = 紧凑玫瑰 + 作品常量 **换成 SL 的**   ← ★ 问"是否必须匹配本作品"
    E02 = 紧凑玫瑰 + 真常量（NX 值）          ← 对照，应正常
    E03 = 紧凑 MIRAGE + 真常量                ← 第二个图像（好分辨）
    E04 = **不动**（原 CREST）                ← 对照，必须正常

  LR（日版 SLPS-25462；BISLPS-25462EMB 目录里的 dataN）
    data0 / data1 = **不动**（真实恶魔 / 红树）← 对照，必须正常
    data2 = **从零造的玫瑰**（LR 布局，无 9 字节字段）← ★ 问"LR 从零造能不能过"

源卡只读；产物写到新卡。
"""
from __future__ import annotations

import hashlib
import importlib.util
import os
import shutil
import sys

MC_DIR = r"C:\Users\M\Documents\PCSX2\memcards"
SRC_CARD = os.path.join(MC_DIR, "Mcd001_embdata2.ps2")
DST_CARD = os.path.join(MC_DIR, "Mcd001_final2.ps2")
PROJ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SURV = r"E:\Armored Core\Armored Core\PS2\AC3_CN\tools\30-存档\61_mc_survey.py"
US2JP = r"E:\Armored Core\Armored Core\PS2\AC3_CN\tools\30-存档\65_us2jp.py"
sys.path.insert(0, os.path.join(PROJ, "tools"))
import acet_format as af                                    # noqa: E402

REAL = os.path.join(PROJ, "testdata", "real")
OUT = os.path.join(PROJ, "out")
LR_DIR = "BISLPS-25462EMB"


def load_mod(name, path):
    s = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(s)
    sys.modules[name] = m
    s.loader.exec_module(m)
    return m


sv = load_mod("sv", SURV)
us2jp = load_mod("us2jp", US2JP)
c0 = sv.Card(SRC_CARD)


def dirs(card):
    return {e["name"]: e for e in card.dirents(card.rootdir, card.dir_count(card.rootdir))
            if e["name"] not in (".", "..")}


def files_of(card, dn):
    d = dirs(card)[dn]
    return {s["name"]: s for s in card.dirents(d["cluster"], d["length"])
            if s["name"] not in (".", "..") and s["length"]}


def blob(card, dn, fn):
    s = files_of(card, dn)[fn]
    return card.read_file(s["cluster"], s["length"])


def load_img(path):
    return af.extract_image(af.read_save_file(path), alpha_mode="index0")


IMG_ROSE = load_img(os.path.join(REAL, "BASLUS-20644E02_rawblock.raw"))
IMG_MIRAGE = load_img(os.path.join(REAL, "BISLPS-25169E00.raw"))
TAIL_NX = af.header_tail_from_save(blob(c0, "BISLPS-25338E00", "BISLPS-25338E00"))
TAIL_SL = af.header_tail_from_save(blob(c0, "BISLPS-25169E00", "BISLPS-25169E00"))
print("NX 作品常量 = %s" % TAIL_NX.hex(' '))
print("SL 作品常量 = %s（拿它来冒充 NX 的）" % TAIL_SL.hex(' '))

ZERO9 = bytes(9)

# ---------- 计划 ----------
NX_PLAN = [
    ("BISLPS-25338E00", "紧凑玫瑰 + 常量【清零】", IMG_ROSE, ZERO9),
    ("BISLPS-25338E01", "紧凑玫瑰 + 常量【换成 SL 的】", IMG_ROSE, TAIL_SL),
    ("BISLPS-25338E02", "紧凑玫瑰 + 真常量（对照）", IMG_ROSE, TAIL_NX),
    ("BISLPS-25338E03", "紧凑 MIRAGE + 真常量", IMG_MIRAGE, TAIL_NX),
    ("BISLPS-25338E04", None, None, None),          # 不动
]
LR_TARGET = "data2"

build = {}

print("\n=== 构造 ===")
for dn, tag, img, tail9 in NX_PLAN:
    if tag is None:
        print("  %-16s （不动，保留原 CREST）" % dn)
        continue
    b = bytes(af.encode_emblem(img, is_lr=False, header_tail=tail9))
    orig = blob(c0, dn, dn)
    assert len(b) == len(orig) == af.SAVE_SIZE
    build[dn] = b
    got = af.extract_image(b, alpha_mode="index0")
    which = {IMG_ROSE: "玫瑰", IMG_MIRAGE: "MIRAGE"}.get(got, "?")
    okC, badC = af.verify_checksums(b)
    okA, _ = af.verify_checksums_upstream(b)
    print("  %-16s %-26s 图=%-6s 常量=%s  校验 真实%s 上游%s"
          % (dn, tag, which, b[0x14:0x1D].hex(' '),
             "✅" if okC else "❌%r" % (badC,), "✅" if okA else "❌"))

lr_blk = bytes(af.encode_emblem(IMG_ROSE, is_lr=True))
lr_orig = blob(c0, LR_DIR, LR_TARGET)
assert len(lr_blk) == len(lr_orig) == af.LR_SAVE_SIZE
okC, badC = af.verify_checksums(lr_blk)
okA, _ = af.verify_checksums_upstream(lr_blk)
print("  %-16s %-26s 图=%-6s 末段 %02X %02X  校验 真实%s 上游%s"
      % (LR_DIR + "/" + LR_TARGET, "LR 从零造玫瑰", "玫瑰",
         lr_blk[0x4414], lr_blk[0x4415],
         "✅" if okC else "❌%r" % (badC,), "✅" if okA else "❌"))

# ---------- 写入 ----------
src_sha = hashlib.sha256(open(SRC_CARD, "rb").read()).hexdigest().upper()
shutil.copyfile(SRC_CARD, DST_CARD)
c = us2jp.Writable(DST_CARD)
touched = []


def overwrite(dn, fn, data, tag):
    s = files_of(c, dn)[fn]
    assert s["length"] == len(data), "%s/%s 长度 %d != %d" % (dn, fn, s["length"], len(data))
    ch = c.chain(s["cluster"], 4096)
    ncl = (len(data) + 1023) // 1024
    assert len(ch) >= ncl
    for i in range(ncl):
        c.write_cluster_bytes(ch[i], data[i * 1024:(i + 1) * 1024])
    touched.append((dn, s["cluster"], ncl))
    print("  %-34s %-24s %d 簇" % (dn + "/" + fn, tag, ncl))


print("\n=== 写入 ===")
for dn in build:
    overwrite(dn, dn, build[dn], "NX 徽章数据")
overwrite(LR_DIR, LR_TARGET, lr_blk, "LR 从零造徽章数据")

print("\n=== 修 NX 槽位号 icon.sys@0xDF（原本全是 0 ⇒ 会卡死）===")
for i in range(5):
    dn = "BISLPS-25338E%02d" % i
    s = files_of(c, dn)["icon.sys"]
    ch = c.chain(s["cluster"], 8)
    ic = bytearray(c.read_file(s["cluster"], 1024))     # 整簇读回，保留空隙字节
    old = ic[0xDF]
    ic[0xDF] = i
    c.write_cluster_bytes(ch[0], bytes(ic))
    touched.append((dn + "/icon.sys", s["cluster"], 1))
    print("  %-16s 0xDF %02X → %02X" % (dn, old, i))
c.f.close()

# ---------- 回读 ----------
print("\n=== 回读 ===")
c2 = sv.Card(DST_CARD)
allok = True
for dn, want in list(build.items()) + [(LR_DIR + "/" + LR_TARGET, lr_blk)]:
    if "/" in dn:
        d, fn = dn.split("/")
        got = blob(c2, d, fn)
    else:
        got = blob(c2, dn, dn)
    same = got == want
    okC, _ = af.verify_checksums(got)
    print("  %-34s 与预期相同 %-5s 校验 %-5s" % (dn, same, "✅" if okC else "❌"))
    allok = allok and same and okC
print("  未动的槽仍与源卡一致: NX E04 %s / LR data0 %s / LR data1 %s"
      % (blob(c2, "BISLPS-25338E04", "BISLPS-25338E04") == blob(c0, "BISLPS-25338E04", "BISLPS-25338E04"),
         blob(c2, LR_DIR, "data0") == blob(c0, LR_DIR, "data0"),
         blob(c2, LR_DIR, "data1") == blob(c0, LR_DIR, "data1")))

# ---------- 逐页 diff ----------
a = open(SRC_CARD, "rb").read()
b = open(DST_CARD, "rb").read()
S = sv.mc.STRIDE
diff = [n for n in range(len(a) // S) if a[n * S:n * S + 512] != b[n * S:n * S + 512]]
exp = set()
for dn, first, ncl in touched:
    ch = c2.chain(first, 4096)
    for cl in ch[:ncl]:
        exp.add(c2.data_page(cl, 0)); exp.add(c2.data_page(cl, 1))
print("\n全盘差异 %d 页 / %d；预期之外多改的页: %s"
      % (len(diff), len(a) // S, sorted(set(diff) - exp) or "无 ✅"))
print("源卡 SHA256 写前 = 写后: %s"
      % (src_sha == hashlib.sha256(open(SRC_CARD, "rb").read()).hexdigest().upper()))
shutil.copyfile(DST_CARD, os.path.join(OUT, os.path.basename(DST_CARD)))

# ---------- 预期外观 ----------
try:
    from PIL import Image
    for dn in build:
        Image.frombytes("RGBA", (128, 128),
                        af.extract_image(build[dn], alpha_mode="index0")).save(
            os.path.join(OUT, "final2_%s.png" % dn))
    Image.frombytes("RGBA", (128, 128),
                    af.extract_image(lr_blk, alpha_mode="index0")).save(
        os.path.join(OUT, "final2_LR_%s.png" % LR_TARGET))
    print("\n已导出预期外观 → out/final2_*.png")
except Exception as e:
    print("(PNG 跳过: %s)" % e)

print("""
================================================================================
新卡：%s

【NX 日版】进徽章画面，5 格逐格 load：
  槽 1 (E00) 紧凑玫瑰 + 常量【清零】        ← ★ 关键：它若正常 ⇒ 那 9 字节不被校验
  槽 2 (E01) 紧凑玫瑰 + 常量【换成 SL 的】   ← ★ 它若破損而槽 1 正常 ⇒ 要求"非零即可"
  槽 3 (E02) 紧凑玫瑰 + 真常量（对照）       ← 必须正常
  槽 4 (E03) 紧凑 MIRAGE（对照）             ← 必须正常
  槽 5 (E04) 原 CREST（没动，对照）          ← 必须正常

【LR 日版】进徽章画面（应能看到 data0..data7 那些格）：
  格 1 原恶魔（没动）／格 2 原红树（没动）   ← 必须正常
  格 3 = ★【从零造的玫瑰】                   ← ★ 它若正常 ⇒ LR 从零造打通
                                               （原来是"反色恶魔"，现在应变成玫瑰）

★ 判读：
  槽1 正常               ⇒ 9 字节作品常量**不被校验** ⇒ AC2/AC2AA/AC3/NB 不再被样本卡住
  槽1 破損、槽2/3 正常    ⇒ 它被校验，但只要求"非零"（不用匹配作品）
  槽1/2 都破損、槽3 正常  ⇒ 必须填**本作品**的那个常量（那就要真实样本）
  LR 格 3 正常            ⇒ LR 从零造打通
================================================================================
""" % DST_CARD)
raise SystemExit(0 if allok else 1)
