# -*- coding: utf-8 -*-
r"""★ 非 LR 写入测试：把"紧凑调色板 + 索引过乱序"的自制徽章写进 SL 的一个槽。

为什么做这个：
  · 已验证：**LR 写入**实机 OK（data2）；**非 LR 读取** 5 份真实样本全 OK；
  · ❌ **非 LR 写入没验过** —— 而 SL / NX / AC2 / AC3 全是非 LR，是通用导入工具的主路径。
  · 真实非 LR 样本的索引是**稀疏**的（NX CREST 用 19 个散布在 0..30），
    而我们打算写**紧凑**的（0..N-1）。"纯查表"的证据支持两者等价，但必须实机确认。

做法（最小改动、可回退）：
  1. 复制 `Mcd001_embdata2.ps2` → `Mcd001_nlrtest.ps2`（源卡不碰）
  2. 拿公开样本里的**玫瑰**（非 LR，BASLUS-20644E02）当内容 —— 一眼能认出来
  3. 用 `af.inject_image` 重新编码到一份空白 0x4440 块 ⇒ 这就是 acet 的**紧凑调色板**方案
  4. 覆盖 `BISLPS-25169E01` 的数据文件（**长度相同 17,472 ⇒ 原地覆盖，不动 FAT/目录项**）
  5. 回读校验 + 与原文件逐页 diff（应只有该文件占用的那些页变化）
"""
from __future__ import annotations

import hashlib
import importlib.util
import os
import shutil
import sys

MC_DIR = r"C:\Users\M\Documents\PCSX2\memcards"
SRC_CARD = os.path.join(MC_DIR, "Mcd001_embdata2.ps2")
DST_CARD = os.path.join(MC_DIR, "Mcd001_nlrtest.ps2")
PROJ = r"E:\Armored Core\Armored Core\PS2\emblem-tool"
SURV = r"E:\Armored Core\Armored Core\PS2\AC3_CN\tools\30-存档\61_mc_survey.py"
US2JP = r"E:\Armored Core\Armored Core\PS2\AC3_CN\tools\30-存档\65_us2jp.py"
sys.path.insert(0, os.path.join(PROJ, "tools"))
import acet_format as af                      # noqa: E402

TARGET_DIR = "BISLPS-25169E01"                # SL 日版徽章槽 1（当前是 MIRAGE 的重复副本）
SOURCE = os.path.join(PROJ, "testdata", "real", "BASLUS-20644E02_rawblock.raw")   # 玫瑰（非 LR）


def load_mod(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(spec)
    sys.modules[name] = m
    spec.loader.exec_module(m)
    return m


sv = load_mod("sv", SURV)
us2jp = load_mod("us2jp", US2JP)

# ---------- 1) 构造"紧凑调色板"的玫瑰 ----------
rose = af.read_save_file(SOURCE)
img = af.extract_image(rose, alpha_mode="index0")
blank = af.make_blank_save(is_lr=False, with_header=True)      # 0x4440
af.inject_image(blank, img)                                     # ← acet 的紧凑方案
new_blk = bytes(blank)
ok, bad = af.verify_checksums(new_blk)
n_colors = len({(img[i], img[i+1], img[i+2]) for i in range(0, len(img), 4) if img[i+3] == 0xFF})

# 原始玫瑰（游戏自己的稀疏排布）作对比
u_src = sorted(set(rose[af.offset_index(af.IMAGE_OFFSET, 0):][:0] or []))
src_idx = [rose[af.offset_index(af.IMAGE_OFFSET + i, 0)] for i in range(af.NUM_PIXELS)]
new_idx = [new_blk[af.offset_index(af.IMAGE_OFFSET + i, 0)] for i in range(af.NUM_PIXELS)]
print("内容：玫瑰（非 LR）")
print("  颜色数 %d；原文件索引 %d 个（最大 %d，%s）"
      % (n_colors, len(set(src_idx)), max(src_idx), "稀疏" if len(set(src_idx)) < max(src_idx) + 1 else "紧凑"))
print("  新编码索引 %d 个（最大 %d，%s）"
      % (len(set(new_idx)), max(new_idx), "稀疏" if len(set(new_idx)) < max(new_idx) + 1 else "紧凑"))
print("  新块 18 段校验: %s" % ("18/18 通过 ✅" if ok else "❌ %r" % (bad,)))
print("  提取回来与原图逐像素一致: %s" % (af.extract_image(new_blk, alpha_mode="index0") == img))
assert len(new_blk) == 0x4440

# ---------- 2) 复制卡 + 定位目标文件 ----------
src_sha = hashlib.sha256(open(SRC_CARD, "rb").read()).hexdigest().upper()
shutil.copyfile(SRC_CARD, DST_CARD)
c = us2jp.Writable(DST_CARD)
roots = c.dirents(c.rootdir, c.dir_count(c.rootdir))
d = [e for e in roots if e["name"] == TARGET_DIR][0]
subs = c.dirents(d["cluster"], d["length"])
f = [s for s in subs if s["name"] == TARGET_DIR][0]
print("\n目标: [%s]/%s  %d 字节  首簇 rel=%d" % (TARGET_DIR, f["name"], f["length"], f["cluster"]))
assert f["length"] == len(new_blk), "长度不同就得动 FAT/目录项，本脚本只做等长覆盖"

chain = c.chain(f["cluster"], 4096)
ncl = (len(new_blk) + 1023) // 1024
print("  簇链 %d 簇（需要 %d）: %s" % (len(chain), ncl, chain[:6]))
assert len(chain) >= ncl

# ---------- 3) 等长原地覆盖 + 重算 ECC ----------
for i in range(ncl):
    c.write_cluster_bytes(chain[i], new_blk[i * 1024:(i + 1) * 1024])
c.f.close()
print("已写入 %d 簇（等长覆盖，FAT/目录项未动）" % ncl)

# ---------- 4) 回读 ----------
c2 = sv.Card(DST_CARD)
r2 = c2.dirents(c2.rootdir, c2.dir_count(c2.rootdir))
d2 = [e for e in r2 if e["name"] == TARGET_DIR][0]
s2 = c2.dirents(d2["cluster"], d2["length"])
f2 = [s for s in s2 if s["name"] == TARGET_DIR][0]
got = c2.read_file(f2["cluster"], f2["length"])
print("\n回读: %d 字节, 与预期块逐字节相同 %s" % (len(got), got == new_blk))
ok2, bad2 = af.verify_checksums(got)
print("  校验 %s" % ("18/18 通过 ✅" if ok2 else "❌ %r" % (bad2,)))
print("  提取图与原图一致 %s" % (af.extract_image(got, alpha_mode="index0") == img))
eccbad = [p for cl in chain[:ncl] for p in (c2.data_page(cl, 0), c2.data_page(cl, 1))
          if not c2.c.ecc_ok(p)]
print("  ECC 不符页: %s" % (eccbad if eccbad else "无 ✅"))

# ---------- 5) 逐页 diff ----------
a = open(SRC_CARD, "rb").read(); b = open(DST_CARD, "rb").read()
S = sv.mc.STRIDE
diff = [n for n in range(len(a)//S) if a[n*S:n*S+512] != b[n*S:n*S+512]]
exp = set()
for cl in chain[:ncl]:
    exp.add(c2.data_page(cl, 0)); exp.add(c2.data_page(cl, 1))
print("\n全盘差异 %d 页 / %d；预期之外多改的页: %s"
      % (len(diff), len(a)//S, sorted(set(diff) - exp) or "无 ✅"))
print("源卡 SHA256 写前 = 写后: %s" % (src_sha == hashlib.sha256(open(SRC_CARD, "rb").read()).hexdigest().upper()))
print("\n新卡: %s" % DST_CARD)
print("⇒ 进游戏看 **SL 的第 2 个徽章格（E01）**：应出现**玫瑰**（原来那里是 MIRAGE 的重复副本）")
