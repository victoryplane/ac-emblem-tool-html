# -*- coding: utf-8 -*-
r"""★ 第四张验证卡 `Mcd001_LRtest.ps2` —— 专攻 LR，且**不会被认错卡**。

## 为什么要重做

`Mcd001_final3.ps2` 的实测回报出现矛盾：
  · SL 看到 **2 个玫瑰** ⇒ 只能是卡 3（卡 3 的两个 SL 槽都是玫瑰）；
  · LR 看到 **恶魔 / 红树 / 反色恶魔** ⇒ 磁盘上卡 3 的 `data2` 明明是**玫瑰**
    （`_selftest/inspect_lr_slots.py` 直接读卡确认：块头 `00 44 00 00`、图 = 玫瑰）。
  ⇒ 那次测试里**至少换了卡**（"恶魔/红树/反色恶魔 + 只有 3 个槽 + 其余 NO DATA"
    正是**源卡** `Mcd001_embdata2.ps2` 的样子）。

## 本卡的设计（三条原则）

1. **改名**：`Mcd001_LRtest.ps2`（不再叫 finalN，避免和之前几张混淆）。
2. **LR 换 2 个槽、且新内容不可能被误认为旧内容**：
     data0 不动（紫恶魔，**对照**）／data1 ← 从零造 **MIRAGE（蓝白）**／data2 ← 从零造 **CREST（红黑）**
     期望画面：紫恶魔、**MIRAGE**、**CREST**（三个都一眼分得清）
3. **NX 全部用卡 1 已实机验证过的内容 + 槽位号 0..4** —— 零风险**对照**：
     若这一屏仍然卡死 ⇒ 卡死**不是**"9 字节作品常量清零"造成的，而是别的原因（含源卡 0xDF 那种）。
     若不卡死 ⇒ 反证卡 2/卡 3 的卡死就是那个清零的常量造成的。

SL 不动（保留源卡的两个 MIRAGE），本卡不管 SL。
源卡只读。
"""
from __future__ import annotations

import hashlib
import importlib.util
import os
import shutil
import sys

MC_DIR = r"C:\Users\M\Documents\PCSX2\memcards"
SRC_CARD = os.path.join(MC_DIR, "Mcd001_embdata2.ps2")
DST_CARD = os.path.join(MC_DIR, "Mcd001_LRtest.ps2")
PROJ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SURV = r"E:\Armored Core\Armored Core\PS2\AC3_CN\tools\30-存档\61_mc_survey.py"
US2JP = r"E:\Armored Core\Armored Core\PS2\AC3_CN\tools\30-存档\65_us2jp.py"
sys.path.insert(0, os.path.join(PROJ, "tools"))
import acet_format as af                                    # noqa: E402

REAL = os.path.join(PROJ, "testdata", "real")
OUT = os.path.join(PROJ, "out")
LR_DIR = "BISLPS-25462EMB"


def load_mod(name, path):
    s = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(s)
    sys.modules[name] = m
    s.loader.exec_module(m)
    return m


sv = load_mod("sv", SURV)
us2jp = load_mod("us2jp", US2JP)
c0 = sv.Card(SRC_CARD)


def dirs(card):
    return {e["name"]: e for e in card.dirents(card.rootdir, card.dir_count(card.rootdir))
            if e["name"] not in (".", "..")}


def files_of(card, dn):
    d = dirs(card)[dn]
    return {s["name"]: s for s in card.dirents(d["cluster"], d["length"])
            if s["name"] not in (".", "..") and s["length"]}


def blob(card, dn, fn):
    s = files_of(card, dn)[fn]
    return card.read_file(s["cluster"], s["length"])


def load_img(path):
    return af.extract_image(af.read_save_file(path), alpha_mode="index0")


IMG_ROSE = load_img(os.path.join(REAL, "BASLUS-20644E02_rawblock.raw"))
IMG_MIRAGE = load_img(os.path.join(REAL, "BISLPS-25169E00.raw"))
IMG_CREST = load_img(os.path.join(REAL, "BISLPS-25338E00.raw"))
TAIL_NX = af.header_tail_from_save(blob(c0, "BISLPS-25338E00", "BISLPS-25338E00"))
print("NX 作品常量 = %s" % TAIL_NX.hex(' '))
print("LR 块头     = %s" % af.LR_EMBLEM_HEADER.hex(' '))

build, tags = {}, {}


def plan(dn, fn, tag, img, is_lr=False, tail9=None, fill=True):
    b = bytes(af.encode_emblem(img, is_lr=is_lr, header_tail=tail9, fill_unused=fill))
    build[(dn, fn)] = b
    tags[(dn, fn)] = tag
    return b


print("\n=== 构造 ===")
# ---- LR：两个"从零造"（testdata/real 的图与真实 LR 块无关，外观一眼可分）----
plan(LR_DIR, "data1", "★ LR 从零造 MIRAGE", IMG_MIRAGE, is_lr=True)
plan(LR_DIR, "data2", "★ LR 从零造 CREST", IMG_CREST, is_lr=True)
# ---- NX：完全复刻卡 1 已实机通过的 5 格（零风险对照）----
plan("BISLPS-25338E00", "BISLPS-25338E00", "玫瑰 + 真常量（卡1 已通过）", IMG_ROSE, tail9=TAIL_NX)
plan("BISLPS-25338E01", "BISLPS-25338E01", "MIRAGE + 真常量（卡1 已通过）", IMG_MIRAGE, tail9=TAIL_NX)
plan("BISLPS-25338E02", "BISLPS-25338E02", "CREST + 真常量（卡1 已通过）", IMG_CREST, tail9=TAIL_NX)
plan("BISLPS-25338E03", "BISLPS-25338E03", "玫瑰 + 真常量 +★★不填未用项（卡1 已通过）",
     IMG_ROSE, tail9=TAIL_NX, fill=False)
plan("BISLPS-25338E04", "BISLPS-25338E04", "CREST 真实块原样（卡1 已通过）", IMG_CREST, tail9=TAIL_NX)

for (dn, fn), b in sorted(build.items()):
    is_lr = af.is_lr_save(b)
    okC, badC = af.verify_checksums(b)
    okA, _ = af.verify_checksums_upstream(b)
    print("  %-26s %-40s %s=%s 引用槽%3d  校验 真实%s 上游%s"
          % (dn + "/" + fn, tags[(dn, fn)], "块头" if is_lr else "常量",
             (bytes(b[:4]).hex(' ') if is_lr else b[0x14:0x1D].hex(' ')),
             len(af.used_palette_slots(b)),
             "✅" if okC else "❌%r" % (badC,), "✅" if okA else "❌"))

# NX E04 要"真实块原样"：用源卡的真实 CREST 字节（而不是重新编码）
real_crest = blob(c0, "BISLPS-25338E04", "BISLPS-25338E04")
c = bytearray(real_crest)
af.apply_checksums(c)
assert bytes(c) == real_crest, "原样通过竟然改了字节"
build[("BISLPS-25338E04", "BISLPS-25338E04")] = real_crest
print("  （NX E04 换成源卡真实字节，逐字节复原 ✅）")

# ---------- 写入 ----------
src_sha = hashlib.sha256(open(SRC_CARD, "rb").read()).hexdigest().upper()
shutil.copyfile(SRC_CARD, DST_CARD)
w = us2jp.Writable(DST_CARD)
touched = []

print("\n=== 写入 ===")
for (dn, fn), b in sorted(build.items()):
    s = files_of(w, dn)[fn]
    assert s["length"] == len(b), "%s/%s 长度 %d != %d" % (dn, fn, s["length"], len(b))
    ch = w.chain(s["cluster"], 4096)
    ncl = (len(b) + 1023) // 1024
    assert len(ch) >= ncl
    for i in range(ncl):
        w.write_cluster_bytes(ch[i], b[i * 1024:(i + 1) * 1024])
    touched.append((dn, s["cluster"], ncl))
    print("  %-26s %d 簇" % (dn + "/" + fn, ncl))

print("\n=== 修 NX 槽位号 icon.sys@0xDF（源卡全是 0 ⇒ 必然卡死）===")
for i in range(5):
    dn = "BISLPS-25338E%02d" % i
    s = files_of(w, dn)["icon.sys"]
    ch = w.chain(s["cluster"], 8)
    ic = bytearray(w.read_file(s["cluster"], 1024))
    old = ic[0xDF]
    ic[0xDF] = i
    w.write_cluster_bytes(ch[0], bytes(ic))
    touched.append((dn + "/icon.sys", s["cluster"], 1))
    print("  %-16s 0xDF %02X → %02X" % (dn, old, i))
w.f.close()

# ---------- 回读 ----------
print("\n=== 回读 ===")
c2 = sv.Card(DST_CARD)
allok = True
for (dn, fn), want in sorted(build.items()):
    got = blob(c2, dn, fn)
    same = got == want
    okC, _ = af.verify_checksums(got)
    print("  %-26s 与预期相同 %-5s 校验 %-5s" % (dn + "/" + fn, same, "✅" if okC else "❌"))
    allok = allok and same and okC
for dn, fn, note in ((LR_DIR, "data0", "LR 紫恶魔（对照，未动）"),
                     ("BISLPS-25169E00", "BISLPS-25169E00", "SL 原 MIRAGE（未动）")):
    same = blob(c2, dn, fn) == blob(c0, dn, fn)
    print("  %-26s 未改动 %-5s  （%s）" % (dn + "/" + fn, same, note))
    allok = allok and same

# ---------- 逐页 diff ----------
a = open(SRC_CARD, "rb").read()
b = open(DST_CARD, "rb").read()
S = sv.mc.STRIDE
diff = [n for n in range(len(a) // S) if a[n * S:n * S + 512] != b[n * S:n * S + 512]]
exp = set()
for dn, first, ncl in touched:
    for cl in c2.chain(first, 4096)[:ncl]:
        exp.add(c2.data_page(cl, 0)); exp.add(c2.data_page(cl, 1))
print("\n全盘差异 %d 页 / %d；预期之外多改的页: %s"
      % (len(diff), len(a) // S, sorted(set(diff) - exp) or "无 ✅"))
print("源卡 SHA256 写前 = 写后: %s"
      % (src_sha == hashlib.sha256(open(SRC_CARD, "rb").read()).hexdigest().upper()))
shutil.copyfile(DST_CARD, os.path.join(OUT, os.path.basename(DST_CARD)))

try:
    from PIL import Image
    for (dn, fn), blk in build.items():
        Image.frombytes("RGBA", (128, 128),
                        af.extract_image(blk, alpha_mode="index0")).save(
            os.path.join(OUT, "lrtest_%s_%s.png" % (dn, fn)))
    Image.frombytes("RGBA", (128, 128),
                    af.extract_image(blob(c0, LR_DIR, "data0"), alpha_mode="index0")).save(
        os.path.join(OUT, "lrtest_LR_data0_未动.png"))
    print("已导出预期外观 → out/lrtest_*.png")
except Exception as e:
    print("(PNG 跳过: %s)" % e)

print("""
================================================================================
新卡：%s
★ 这次请**先确认挂在 slot 上的是这个文件名**（`Mcd001_LRtest.ps2`），并**冷启动**游戏。

【LR 日版】徽章画面 —— 期望看到（从左到右）：
     紫恶魔（没动）→ ★MIRAGE（蓝白）→ ★CREST（红黑）→ 当前装备那个 → 其余 NO DATA
  ★ 只要第 2 / 3 格变成了 MIRAGE / CREST ⇒ LR 从零造打通（块头 bug 已修）
  ★ 若仍是"恶魔 / 红树 / 反色恶魔" ⇒ 说明**挂的不是这张卡**（那是源卡的样子）

【NX 日版】徽章画面 —— 这一屏的内容**全部是卡 1 已实机通过的**，属于对照：
     槽 1 玫瑰 / 槽 2 MIRAGE / 槽 3 CREST / 槽 4 玫瑰 / 槽 5 CREST   （5 格都应正常）
  ★ 它若仍然卡死 ⇒ 卡死**不是**"9 字节作品常量清零"造成的，另有原因
  ★ 它若正常     ⇒ 反证卡 2/卡 3 的卡死就是那个清零的常量造成的

★ 顺便请回报：上次卡 3 的 SL 两格（都是玫瑰）**是"能读取"还是只是"图标显示"**？
================================================================================
""" % DST_CARD)
raise SystemExit(0 if allok else 1)
