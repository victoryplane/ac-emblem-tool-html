# -*- coding: utf-8 -*-
r"""★ 只读：把 LR 目录的**原始** dirent 一条条摊开，不按名字去重。

动机：`files_of()` 用的是 `{名字: 条目}` 字典 —— **重名条目会被后来的覆盖掉**。
如果目录里有两个 `data2`（或 `data2` 的簇链与别的文件重叠），就会出现
"我们写的那个"和"游戏读的那个"不是同一份 —— 这正好能解释
"磁盘上是玫瑰、游戏里显示反色恶魔"。

本脚本检查：
  ① 原始 dirent 列表（含 '.' '..'），名字是否有重复
  ② 每个文件的 dirent 前 0x30 字节原样 dump（mode / length / cluster / 时间戳…）
  ③ 各文件占用的簇区间，是否有**重叠**
  ④ `dataN` 的簇链是否连续（有些游戏不跟 FAT，直接按 length 从首簇连读）
"""
from __future__ import annotations

import importlib.util
import os
import struct
import sys

PROJ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SURV = r"E:\Armored Core\Armored Core\PS2\AC3_CN\tools\30-存档\61_mc_survey.py"

spec = importlib.util.spec_from_file_location("sv", SURV)
sv = importlib.util.module_from_spec(spec)
spec.loader.exec_module(sv)

MC_DIR = r"C:\Users\M\Documents\PCSX2\memcards"
CARDS = ["Mcd001_embdata2.ps2", "Mcd001_final3.ps2"]
LR_DIR = "BISLPS-25462EMB"

for cn in CARDS:
    p = os.path.join(MC_DIR, cn)
    if not os.path.exists(p):
        continue
    card = sv.Card(p)
    roots = [e for e in card.dirents(card.rootdir, card.dir_count(card.rootdir))
             if e["name"] not in (".", "..")]
    d = [e for e in roots if e["name"] == LR_DIR]
    print("=" * 92)
    print("卡 %s   →  %s   （根目录里叫这名字的条目有 %d 条）" % (cn, LR_DIR, len(d)))
    print("=" * 92)
    e = d[0]
    raw = bytearray()
    chain = card.chain(e["cluster"], 64)
    for cl in chain:
        for k in range(card.ppc):
            raw += card.c.read_page(card.data_page(cl, k))
    print("目录簇链 %s  项数(len)=%d" % (chain[:6], e["length"]))

    n = e["length"]
    names = []
    rows = []
    for i in range(n):
        blk = bytes(raw[i * 512:(i + 1) * 512])
        mode = struct.unpack_from('<H', blk, 0)[0]
        length = struct.unpack_from('<I', blk, 4)[0]
        cluster = struct.unpack_from('<I', blk, 0x10)[0]
        nm = blk[0x40:0x40 + 32].split(b'\x00')[0].decode('cp932', 'replace')
        names.append(nm)
        rows.append((i, nm, mode, length, cluster))
        print("  [%d] mode=0x%04X len=%-7d 首簇=%-6d 名=%-18r 前 0x18: %s"
              % (i, mode, length, cluster, nm, blk[:0x18].hex(' ')))

    dup = [x for x in set(names) if names.count(x) > 1]
    print("  ⇒ 重名条目: %s" % (dup if dup else "无 ✅"))

    # ---- 簇区间 & 重叠 ----
    print("  --- 簇占用 ---")
    spans = {}
    for i, nm, mode, length, cluster in rows:
        if nm in (".", "..") or not length:
            continue
        ch = card.chain(cluster, 4096)
        ncl = (length + 1023) // 1024
        used = ch[:ncl]
        spans[nm] = (used, ncl)
        contiguous = used == list(range(used[0], used[0] + len(used)))
        print("    %-18s %6d B  %2d 簇  %s..%s  连续? %s"
              % (nm, length, ncl, used[0], used[-1], "是 ✅" if contiguous else "**否** ← 游戏若不跟 FAT 就会读错"))
    ks = list(spans)
    for a in range(len(ks)):
        for b in range(a + 1, len(ks)):
            sa, sb = set(spans[ks[a]][0]), set(spans[ks[b]][0])
            ov = sa & sb
            if ov:
                print("    ⚠ 簇重叠：%s 与 %s 共享 %d 个簇 %s"
                      % (ks[a], ks[b], len(ov), sorted(ov)[:8]))
    print()

    # ---- 游戏可能按"名字里 dataN 排序"读，这里列出 dataN 的映射 ----
    dts = sorted([r for r in rows if r[1].startswith("data") and r[1][4:].isdigit()],
                 key=lambda r: int(r[1][4:]))
    print("  dataN 映射（按名字数字序）: %s"
          % ", ".join("%s→首簇%d(len %d)" % (r[1], r[4], r[3]) for r in dts))
    print("  而**按目录顺序**出现的 dataN: %s"
          % ", ".join(r[1] for r in rows if r[1].startswith("data") and r[1][4:].isdigit()))
    print()
