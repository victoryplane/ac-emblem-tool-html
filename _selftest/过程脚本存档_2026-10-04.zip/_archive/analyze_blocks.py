# -*- coding: utf-8 -*-
r"""★ 字节级剖析：真实非 LR 样本 vs 我们的"紧凑重编码"，逐字段对照。

目的：`compact` 写法在 SL/NX 上被游戏判 `破損ファイル`，而已排除：
  · 9 字节作品常量（补了仍破）
  · 未用调色板项为 0（填满仍破）
  · 写入机制 / ECC / FAT（回读逐字节一致、ECC 全对）
  · 隐藏的**内容**校验（结构保持地改调色板色值 → 正常 load）
  · ICO / icon.sys（缩略图由存档数据渲染；icon.sys 无内容字段）

于是必须把"我们造的块"和"游戏自己造的块"做**穷尽**的字段对照，
把从没被变动过的字节找出来（尤其是 0x00..0x24 头里除魔数和作品常量以外的部分、
以及 0x4435..0x443F 那 11 字节尾巴）。
"""
from __future__ import annotations

import os
import sys

PROJ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(PROJ, "tools"))
import acet_format as af                                    # noqa: E402

REAL = os.path.join(PROJ, "testdata", "real")

SL_JP = ["BISLPS-25169E00.raw", "BISLPS-25169E01.raw"]
NX_JP = ["BISLPS-25338E%02d.raw" % i for i in range(5)]
SL_US = ["BASLUS-20644E02_rawblock.raw"]
LR = ["BISLPS-25462EMB_data0.raw", "BISLPS-25462EMB_data1.raw"]

ORDER = SL_US + SL_JP + NX_JP + LR


def stats(blk: bytes):
    is_lr = af.is_lr_save(blk)
    io = af.LR_IMAGE_OFFSET if is_lr else af.IMAGE_OFFSET
    size = len(blk)
    px = bytes(blk[af.offset_index(io + i, 0)] for i in range(af.NUM_PIXELS))
    pal = bytes(blk[af.offset_index(io + af.NUM_PIXELS + k, 0)] for k in range(af.PALETTE_SIZE))
    used_slots = sorted({(px[i] if is_lr else af.unscramble_palette(px[i])) for i in range(af.NUM_PIXELS)})
    nz_slots = [k for k in range(256) if any(pal[k * 4 + c] for c in range(4))]
    rgba_used = len({pal[k * 4:k * 4 + 4] for k in used_slots})
    return dict(size=size, is_lr=is_lr, px=px, pal=pal, used=used_slots,
                nz=nz_slots, rgba_used=rgba_used,
                tail=bytes(blk[size - 11:]), final=blk[size - 12])


def sect(title):
    print("\n" + "=" * 78)
    print(title)
    print("=" * 78)


# --------------------------------------------------------------------------
sect("一、每份真实样本：头 0x00..0x24 与尾 0x4435..0x4440")
print("%-30s %s" % ("文件", "头 0x00..0x24 (36 B)"))
hdr = {}
for nm in ORDER:
    p = os.path.join(REAL, nm)
    if not os.path.exists(p):
        continue
    b = af.read_save_file(p)
    s = stats(b)
    hdr[nm] = bytes(b[:0x24])
    print("%-30s %s   | 尾11B %s" % (nm, b[:0x24].hex(' '), s["tail"].hex(' ')))

print("\n%-30s %s" % ("★ 紧凑重编码（空白块+注入）", ""))
rose = af.read_save_file(os.path.join(REAL, "BASLUS-20644E02_rawblock.raw"))
tail9 = af.header_tail_from_save(rose)
comp = af.make_blank_save(is_lr=False, with_header=True, header_tail=tail9)
af.inject_image(comp, af.extract_image(rose, alpha_mode="index0"))
comp = bytes(comp)
sc = stats(comp)
print("%-30s %s   | 尾11B %s" % ("compact-rose", comp[:0x24].hex(' '), sc["tail"].hex(' ')))

# --------------------------------------------------------------------------
sect("二、头部每个字节：真实样本是否恒定 / 我们是否相符")
for off in range(0x24):
    vals = {}
    for nm in ORDER:
        if nm in hdr:
            vals.setdefault(hdr[nm][off], []).append(nm)
    tag = "★恒定" if len(vals) == 1 else "  变化"
    v = sorted(vals)
    print("0x%02X %-6s 真实取值 %s" % (
        off, tag,
        " ".join("%02X(%d份)" % (k, len(vv)) for k, vv in sorted(vals.items()))))
print("\n我们(compact) 与 SL 真实样本的头部差异字节：")
for off in range(0x24):
    a, b = comp[off], hdr[SL_JP[0]][off]
    if a != b:
        print("  0x%02X  我们=%02X  真实=%02X" % (off, a, b))

# --------------------------------------------------------------------------
sect("三、尾部 11 字节 0x4435..0x443F：真实样本取值")
for nm in ORDER:
    if nm not in hdr:
        continue
    b = af.read_save_file(os.path.join(REAL, nm))
    s = stats(b)
    print("%-30s 末校验 %02X | 尾11B %s | 尾全零? %s" % (
        nm, s["final"], s["tail"].hex(' '), not any(s["tail"])))

# --------------------------------------------------------------------------
sect("四、调色板：槽 0..3 / 252..255，零值项计数，被引用槽数")
print("%-30s %-23s %-23s %5s %5s %5s %5s" % (
    "文件", "palette[0]", "palette[1]", "零项", "引用", "最大", "RGBA"))
for nm in ORDER:
    if nm not in hdr:
        continue
    b = af.read_save_file(os.path.join(REAL, nm))
    s = stats(b)
    pal, used = s["pal"], s["used"]
    zero = 256 - len(s["nz"])
    print("%-30s %-23s %-23s %5d %5d %5d %5d" % (
        nm, pal[0:4].hex(' '), pal[4:8].hex(' '),
        zero, len(used), max(used), s["rgba_used"]))
print("%-30s %-23s %-23s %5d %5d %5d %5d" % (
    "compact-rose", sc["pal"][0:4].hex(' '), sc["pal"][4:8].hex(' '),
    256 - len(sc["nz"]), len(sc["used"]), max(sc["used"]), sc["rgba_used"]))

print("\n真实样本 palette[0] 的 alpha 字节（关键：是不是 0x80/0x40/0x00）：")
for nm in ORDER:
    if nm not in hdr:
        continue
    b = af.read_save_file(os.path.join(REAL, nm))
    s = stats(b)
    print("  %-30s palette[0] = %s   alpha = 0x%02X" % (nm, s["pal"][0:4].hex(' '), s["pal"][3]))
print("  %-30s palette[0] = %s   alpha = 0x%02X" % ("compact-rose", sc["pal"][0:4].hex(' '), sc["pal"][3]))

# --------------------------------------------------------------------------
sect("五、紧凑重编码 vs 真实 SL 样本：差异落在哪些区域")
ref = af.read_save_file(os.path.join(REAL, SL_JP[0]))
diff = [i for i in range(min(len(ref), len(comp))) if ref[i] != comp[i]]
print("差异字节数 %d / %d" % (len(diff), len(ref)))
io = af.IMAGE_OFFSET
pal_lo = af.offset_index(io + af.NUM_PIXELS, 0)
pal_hi = af.offset_index(io + af.NUM_PIXELS + af.PALETTE_SIZE - 1, 0) + 1
ranges, cur = [], None
for i in diff:
    if cur and i == cur[1] + 1:
        cur[1] = i
    else:
        cur = [i, i]; ranges.append(cur)
print("差异区间 %d 段；按区域分类：" % len(ranges))
buckets = {"头部 0x00..0x24": 0, "索引区": 0, "调色板区": 0, "尾部 0x4410..": 0, "校验字节": 0}
for a, b in ranges:
    n = b - a + 1
    if b < io:
        buckets["头部 0x00..0x24"] += n
    elif b < pal_lo:
        buckets["索引区"] += n
    elif b < pal_hi:
        buckets["调色板区"] += n
    else:
        buckets["尾部 0x4410.."] += n
for k, v in buckets.items():
    print("  %-16s %d" % (k, v))

print("\n头部差异明细（0x00..0x%X）：" % io)
for i in diff:
    if i < io:
        print("  0x%02X  真实=%02X  我们=%02X" % (i, ref[i], comp[i]))
print("尾部（>= 0x%X）差异明细：" % pal_hi)
tail_diffs = [i for i in diff if i >= pal_hi]
if len(tail_diffs) <= 60:
    for i in tail_diffs:
        print("  0x%04X  真实=%02X  我们=%02X" % (i, ref[i], comp[i]))
else:
    print("  共 %d 个（只列首尾）" % len(tail_diffs))
    for i in tail_diffs[:30] + tail_diffs[-10:]:
        print("  0x%04X  真实=%02X  我们=%02X" % (i, ref[i], comp[i]))

# --------------------------------------------------------------------------
sect("六、NX 5 份是否真的逐字节相同")
nx = []
for nm in NX_JP:
    p = os.path.join(REAL, nm)
    if os.path.exists(p):
        nx.append((nm, af.read_save_file(p)))
if nx:
    base = nx[0][1]
    for nm, b in nx:
        print("  %-30s 与 %s 相同: %s" % (nm, nx[0][0], b == base))

# --------------------------------------------------------------------------
sect("七、索引区：像素字节 0 的个数 / 用到的像素字节集合大小")
for nm in ORDER:
    if nm not in hdr:
        continue
    b = af.read_save_file(os.path.join(REAL, nm))
    s = stats(b)
    px = s["px"]
    print("%-30s 像素字节==0: %6d  不同像素字节: %3d  引用槽: %3d  槽集合紧凑? %s"
          % (nm, px.count(0), len(set(px)), len(s["used"]),
             len(s["used"]) == max(s["used"]) + 1))
print("%-30s 像素字节==0: %6d  不同像素字节: %3d  引用槽: %3d  槽集合紧凑? %s"
      % ("compact-rose", sc["px"].count(0), len(set(sc["px"])), len(sc["used"]),
         len(sc["used"]) == max(sc["used"]) + 1))

# --------------------------------------------------------------------------
sect("八、真实样本用到的槽是否都落在「32 块 / 8 组」边界上（乱序映射的线索）")
for nm in ORDER:
    if nm not in hdr:
        continue
    b = af.read_save_file(os.path.join(REAL, nm))
    s = stats(b)
    used = s["used"]
    groups = sorted({(k % 32) // 8 for k in used})
    blocks = sorted({k // 32 for k in used})
    print("%-30s 用到的 32-块 %s  组(0..3) %s" % (nm, blocks, groups))
