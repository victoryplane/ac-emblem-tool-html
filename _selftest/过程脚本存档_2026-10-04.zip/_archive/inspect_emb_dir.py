# -*- coding: utf-8 -*-
r"""只读：把 LR 卡上 `BISLPS-25462EMB` 目录的结构看仔细，为"新增 data2"做准备。

要弄清：
  · 目录自己的簇链有几簇 ⇒ 一共几个 512 B 的 dirent 槽位（够不够放新项）
  · '.' 项的 length（= 目录项数）当前是多少
  · 根目录里那个 `BISLPS-25462EMB` 条目的 length 是否也等于项数
  · 现存每个文件的 dirent 长什么样（新项就照 `data0` 克隆）
  · 那个同名的 32 字节"存档头文件"里到底有没有项数
"""
import importlib.util
import os
import struct
import sys

MC = r"C:\Users\M\Documents\PCSX2\memcards\Mcd001.ps2"
SURV = r"E:\Armored Core\Armored Core\PS2\AC3_CN\tools\30-存档\61_mc_survey.py"
spec = importlib.util.spec_from_file_location("sv", SURV)
sv = importlib.util.module_from_spec(spec)
spec.loader.exec_module(sv)

c = sv.Card(MC)
root_count = c.dir_count(c.rootdir)
roots = c.dirents(c.rootdir, root_count)
print("根目录：count=%d, 链=%s" % (root_count, c.chain(c.rootdir, 64)))

for target in ("BISLPS-25462EMB", "BISLPS-25462GAME"):
    e = [x for x in roots if x["name"] == target][0]
    print("\n" + "=" * 70)
    print("根条目 [%s]: mode=0x%08X length=%d cluster(rel)=%d" % (target, e["mode"], e["length"], e["cluster"]))
    chain = c.chain(e["cluster"], 64)
    print("  目录簇链: %s  （%d 簇 = %d 个 512B 槽位）" % (chain, len(chain), len(chain) * c.ppc))
    cnt = struct.unpack_from('<I', c.read_file(e["cluster"], 8), 4)[0]
    print("  '.' 项的 length（= 声明项数）= %d" % cnt)
    ents = c.dirents(e["cluster"], e["length"])
    raw = bytearray()
    need = e["length"] * 512
    for cl in chain:
        for k in range(c.ppc):
            raw += c._p(cl, k) if hasattr(c, "_p") else c.c.read_page(c.data_page(cl, k))
        if len(raw) >= need:
            break
    for x in ents:
        d = bytes(raw[x["index"] * 512:(x["index"] + 1) * 512])
        par = struct.unpack_from('<I', d, 0x14)[0]
        print("    [%2d] %-18s mode=0x%04X len=%-7d cluster=%-6d @0x14=%d"
              % (x["index"], x["name"], x["mode"], x["length"], x["cluster"], par))
    # 空槽检查
    for i in range(len(ents), len(chain) * c.ppc):
        d = bytes(raw[i * 512:(i + 1) * 512]) if (i + 1) * 512 <= len(raw) else b""
        if d:
            m = struct.unpack_from('<I', d, 0)[0]
            print("    [%2d] (空槽) mode=0x%08X" % (i, m))
    # 同名 32 字节文件
    hdr = [x for x in ents if x["name"] == target]
    if hdr:
        h = c.read_file(hdr[0]["cluster"], hdr[0]["length"])
        print("  同名 %d 字节头文件: %s" % (len(h), h.hex(' ')))
    # data0 的完整 dirent（用来克隆）
    d0 = [x for x in ents if x["name"] == "data0"]
    if d0:
        d = bytes(raw[d0[0]["index"] * 512:(d0[0]["index"] + 1) * 512])
        print("  ★ data0 完整 dirent 前 0x60 字节（克隆用）:")
        for o in range(0, 0x60, 16):
            print("       +0x%02X: %s" % (o, d[o:o + 16].hex(' ')))
