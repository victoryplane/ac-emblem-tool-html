# -*- coding: utf-8 -*-
r"""只读核查两件事：
  ① 卡 3 的 SL 两个槽到底是什么（确认"2 个玫瑰"的截图出自卡 3）
  ② LR 目录里的 `static.ico`（28110 B，**一个文件服务 8 个槽**）里有什么 ——
     如果 LR 徽章画面的缩略图其实来自它，那"只改 dataX 不改 static.ico"就永远看不到变化。
"""
from __future__ import annotations

import importlib.util
import os
import sys

PROJ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SURV = r"E:\Armored Core\Armored Core\PS2\AC3_CN\tools\30-存档\61_mc_survey.py"
sys.path.insert(0, os.path.join(PROJ, "tools"))
import acet_format as af                                    # noqa: E402

spec = importlib.util.spec_from_file_location("sv", SURV)
sv = importlib.util.module_from_spec(spec)
spec.loader.exec_module(sv)

MC_DIR = r"C:\Users\M\Documents\PCSX2\memcards"
OUT = os.path.join(PROJ, "out")
REAL = os.path.join(PROJ, "testdata", "real")

KNOWN = {}
for nm, path in (("玫瑰", "BASLUS-20644E02_rawblock.raw"),
                 ("MIRAGE", "BISLPS-25169E00.raw"),
                 ("CREST", "BISLPS-25338E00.raw"),
                 ("恶魔", "BISLPS-25462EMB_data0.raw"),
                 ("红树", "BISLPS-25462EMB_data1.raw")):
    p = os.path.join(REAL, path)
    if os.path.exists(p):
        KNOWN[af.extract_image(af.read_save_file(p), alpha_mode="index0")] = nm


def dirs(card):
    return {e["name"]: e for e in card.dirents(card.rootdir, card.dir_count(card.rootdir))
            if e["name"] not in (".", "..")}


print("=" * 90)
print("① 各卡的 SL 两个槽（确认截图出处）")
print("=" * 90)
for cn in ("Mcd001_embdata2.ps2", "Mcd001_final.ps2", "Mcd001_final2.ps2",
           "Mcd001_final3.ps2", "Mcd001_LRtest.ps2"):
    p = os.path.join(MC_DIR, cn)
    if not os.path.exists(p):
        continue
    card = sv.Card(p)
    r = dirs(card)
    line = []
    for i in (0, 1):
        dn = "BISLPS-25169E%02d" % i
        if dn not in r:
            line.append("%s 无" % dn[-3:]); continue
        s = [x for x in card.dirents(r[dn]["cluster"], r[dn]["length"])
             if x["name"] == dn][0]
        b = card.read_file(s["cluster"], s["length"])
        nm = KNOWN.get(af.extract_image(b, alpha_mode="index0"), "?")
        line.append("%s=%s" % (dn[-3:], nm))
    print("  %-24s %s" % (cn, "  ".join(line)))

print()
print("=" * 90)
print("② LR 的 static.ico 里有什么")
print("=" * 90)
for cn in ("Mcd001_embdata2.ps2", "Mcd001_final3.ps2"):
    p = os.path.join(MC_DIR, cn)
    card = sv.Card(p)
    e = dirs(card)["BISLPS-25462EMB"]
    subs = {s["name"]: s for s in card.dirents(e["cluster"], e["length"])
            if s["name"] not in (".", "..") and s["length"]}
    s = subs["static.ico"]
    ico = card.read_file(s["cluster"], s["length"])
    print("卡 %-24s static.ico %d B (0x%X)  首 0x20: %s"
          % (cn, len(ico), len(ico), ico[:0x20].hex(' ')))
    print("    含 'PS2D' 魔数: %s（偏移 %s）" % (ico.find(b'PS2D') >= 0, ico.find(b'PS2D')))
    print("    0x1240 之后的长度 = %d（0x8000=32768 才够一格 128×128×16bit）"
          % (len(ico) - 0x1240))
    # 找非零区段
    runs, cur = [], None
    for i, v in enumerate(ico):
        if v:
            if cur and i == cur[1] + 1:
                cur[1] = i
            else:
                cur = [i, i]; runs.append(cur)
    big = [r for r in runs if r[1] - r[0] > 63]
    print("    非零大段（>64B）共 %d 段，前几段：%s"
          % (len(big), ["0x%X..0x%X" % (a, b) for a, b in big[:6]]))

    try:
        from PIL import Image
        # 把文件尾部当 16bit BGR555 贴图渲染几处候选，看看有没有像恶魔/树的
        for off in (0x1240, 0x1240 + 0x800, len(ico) - 0x8000 if len(ico) >= 0x8000 else -1):
            if off < 0 or off + 0x8000 > len(ico):
                continue
            im = Image.new("RGB", (128, 128)); px = im.load()
            for i in range(128 * 128):
                v = int.from_bytes(ico[off + i * 2:off + i * 2 + 2], 'little')
                px[i % 128, i // 128] = (((v & 0x1F) << 3), (((v >> 5) & 0x1F) << 3),
                                         (((v >> 10) & 0x1F) << 3))
            q = os.path.join(OUT, "staticico_%s_0x%X.png" % (cn.split('_')[-1][:6], off))
            im.save(q)
            print("    已渲染候选贴图 @0x%X → %s" % (off, os.path.basename(q)))
        # 头部（含 3D 模型）也存一份
        hdr = Image.new("RGB", (128, 128))
        px = hdr.load()
        step = max(1, (len(ico) - 0x1240) // (128 * 128) or 1)
        for i in range(128 * 128):
            o = i * step
            px[i % 128, i // 128] = (ico[o], ico[o], ico[o]) if o < len(ico) else (0, 0, 0)
        q = os.path.join(OUT, "staticico_%s_预览.png" % cn.split('_')[-1][:6])
        hdr.save(q)
        print("    已导出灰度预览 → %s" % os.path.basename(q))
    except Exception as ex:
        print("    (PNG 跳过: %s)" % ex)
    print()
