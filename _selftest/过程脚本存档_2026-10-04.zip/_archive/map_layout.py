# -*- coding: utf-8 -*-
r"""★ 精确布局图：把物理偏移 0x43D0..0x4440 的每个字节归类。
判断 0x4411..0x4433 到底是"调色板的一部分"还是"调色板之外的额外字段"，
以及 0x4435..0x443F 那 11 字节尾巴里 `cb 01` 是什么。
"""
from __future__ import annotations

import os
import sys

PROJ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(PROJ, "tools"))
import acet_format as af                                    # noqa: E402

REAL = os.path.join(PROJ, "testdata", "real")

# ---- 1) 校验字节位置 ----
segs = af.segment_layout(False)
print("非 LR 的 18 段布局（段起点 / 数据长 / 校验字节物理位置）：")
for i, (s, d, c, seed) in enumerate(segs):
    print("  seg%02d 起点 0x%04X 数据 %4d B 校验@0x%04X 种子 0x%02X" % (i, s, d, c, seed))

checkpos = {c for (_, _, c, _) in segs}
print("\n校验字节集合: %s" % sorted("0x%04X" % c for c in checkpos))

# ---- 2) 每个调色板槽的物理位置 ----
io = af.IMAGE_OFFSET
pal_phys = {}
for k in range(256):
    for ch in range(4):
        pal_phys[af.offset_index(io + af.NUM_PIXELS + k * 4 + ch, 0)] = (k, "RGBA"[ch])
last_pal = max(pal_phys)
print("调色板物理范围 0x%04X .. 0x%04X（槽 0 的 R .. 槽 255 的 A）"
      % (min(pal_phys), last_pal))

# ---- 3) 物理偏移分类 ----
def classify(p: int):
    if p < io:
        return "头部"
    if p < af.offset_index(io + af.NUM_PIXELS, 0):
        return "索引区"
    if p in pal_phys:
        k, ch = pal_phys[p]
        return "调色板[%d].%s" % (k, ch)
    if p in checkpos:
        return "★校验字节(seg%d)" % [i for i, s in enumerate(segs) if s[2] == p][0]
    return "?? 板外"

# ---- 4) 真实样本在这些位置的字节 ----
samples = ["BISLPS-25169E00.raw", "BISLPS-25338E00.raw",
           "BASLUS-20644E02_rawblock.raw", "BISLPS-25462EMB_data0.raw"]
data = {}
for nm in samples:
    p = os.path.join(REAL, nm)
    if os.path.exists(p):
        data[nm] = af.read_save_file(p)

rose = data["BASLUS-20644E02_rawblock.raw"]
comp = af.make_blank_save(is_lr=False, with_header=True, header_tail=af.header_tail_from_save(rose))
af.inject_image(comp, af.extract_image(rose, alpha_mode="index0"))
data["compact-rose"] = bytes(comp)

print("\n" + "=" * 108)
print("物理偏移 0x43D8..0x443F 逐字节（含归类）")
print("=" * 108)
head = "偏移   归类                " + "".join("%-4s" % nm.split('.')[0][:3] for nm in data)
print(head)
for p in range(0x43D8, 0x4440):
    row = "0x%04X %-20s" % (p, classify(p))
    for nm in data:
        row += "%-4s" % ("%02X" % data[nm][p] if p < len(data[nm]) else "--")
    print(row)

# ---- 5) 板外字节统计 ----
outside = [p for p in range(0x4000, 0x4440) if classify(p).startswith("??")]
print("\n板外（既不是索引/调色板也不是校验字节）的物理偏移 %d 个: 0x%04X..0x%04X"
      % (len(outside), outside[0], outside[-1]) if outside else "\n没有板外字节")
for nm in data:
    vals = set(data[nm][p] for p in outside)
    print("  %-28s 板外字节取值集合 %s" % (nm, sorted("0x%02X" % v for v in vals)))

# ---- 6) 尾巴 11 字节逐样本 ----
print("\n尾巴 0x%04X..0x%04X：" % (af.FINAL_CHECK_OFF + 1, 0x443F))
for nm in data:
    t = data[nm][af.FINAL_CHECK_OFF + 1:]
    u16 = int.from_bytes(t[:2], 'little')
    u32 = int.from_bytes(t[:4], 'little')
    print("  %-28s %s   u16=%d(0x%04X) u32=%d" % (nm, t.hex(' '), u16, u16, u32))
