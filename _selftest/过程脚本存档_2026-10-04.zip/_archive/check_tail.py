# -*- coding: utf-8 -*-
r"""★ 尾部 11 字节（0x4435..0x443F）到底是什么：可算的校验，还是按作品的常量？

已确认（见 check_checksum_layout.py / map_layout.py）：
  · `0x4434` = 模式 A 的末段校验字节（用上游算法算出来与真实样本相符）
  · `0x4434` 同时也是 `palette[255].alpha` 的物理位置 ⇒ 该格被校验占用（游戏固定写 0x80）
  · `0x4435..0x443F` = 11 字节**真实数据**，所有真实样本都不是零
  · 我们造的"紧凑块"把这 11 字节全写成 0 —— **这是唯一一处我们从没碰过的差异**

本脚本判定 X(=`0x4435`) 是否可由内容算出：
  · 若能算出 ⇒ 是另一种校验，写入器必须补上
  · 若算不出 ⇒ 与 0x14..0x1C 那 9 字节一样是**按作品的常量**，从真实存档里读即可
"""
from __future__ import annotations

import os
import sys

PROJ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(PROJ, "tools"))
import acet_format as af                                    # noqa: E402

REAL = os.path.join(PROJ, "testdata", "real")
FILES = ["BASLUS-20644E02_rawblock.raw", "BISLPS-25169E00.raw", "BISLPS-25169E01.raw",
         "BISLPS-25338E00.raw", "BISLPS-25338E01.raw", "BISLPS-25338E02.raw",
         "BISLPS-25338E03.raw", "BISLPS-25338E04.raw",
         "BISLPS-25462EMB_data0.raw", "BISLPS-25462EMB_data1.raw"]

rows = []
for nm in FILES:
    p = os.path.join(REAL, nm)
    if not os.path.exists(p):
        continue
    b = af.read_save_file(p)
    n = len(b)
    rows.append((nm, b, n))

print("=" * 112)
print("一、基础量")
print("=" * 112)
print("%-30s %-5s %-5s %-5s | %-22s | %s" % ("文件", "bA", "bX", "bX+1", "X+1 起的 10 字节", "sum(0x4400..cA-1)"))
for nm, b, n in rows:
    cA, cX = n - 12, n - 11
    s = sum(b[0x4400:cA]) & 0xFF
    print("%-30s %02X    %02X    %02X    | %-22s | 0x%02X" % (
        nm, b[cA], b[cX], b[cX + 1], b[cX + 1:].hex(' '), s))

print("\n" + "=" * 112)
print("二、候选公式（对每个样本算，看是否命中观测字节）")
print("=" * 112)
CANDS = {
    "A  校验@cA: -(sum(0x4400..cA-1)+sum(cX+1..end)+len52)":
        lambda b, n: (lambda cA, cX: (-(sum(b[0x4400:cA]) + sum(b[cX + 1:n]) + (cA - 0x4400)) & 0xFF, b[cA]))(n - 12, n - 11),
    "C  校验@cX: -(sum(0x4400..cA)+ (cA-0x4400+1))":
        lambda b, n: (lambda cA, cX: (-(sum(b[0x4400:cA + 1]) + (cA - 0x4400 + 1)) & 0xFF, b[cX]))(n - 12, n - 11),
    "C2 校验@cX: -(sum(0x4400..cA)+ (cA-0x4400))":
        lambda b, n: (lambda cA, cX: (-(sum(b[0x4400:cA + 1]) + (cA - 0x4400)) & 0xFF, b[cX]))(n - 12, n - 11),
    "C3 校验@cX: -(sum(0x4400..cA-1)+ (cA-0x4400))  [不含 bA]":
        lambda b, n: (lambda cA, cX: (-(sum(b[0x4400:cA]) + (cA - 0x4400)) & 0xFF, b[cX]))(n - 12, n - 11),
    "D  链式: 校验@0x4436: -(sum(0x4400..cX)+(cX-0x4400+1))":
        lambda b, n: (lambda cA, cX: (-(sum(b[0x4400:cX + 1]) + (cX - 0x4400 + 1)) & 0xFF, b[cX + 1]))(n - 12, n - 11),
    "E  X = -(sum(整个文件数据字节)+len)":
        lambda b, n: (lambda cA, cX: (-(sum(b) - b[cA] - b[cX] + (n - 2)) & 0xFF, b[cX]))(n - 12, n - 11),
    "F  X = -(sum(b)+n)":
        lambda b, n: (lambda cA, cX: (-(sum(b) + n) & 0xFF, b[cX]))(n - 12, n - 11),
    "G  X = sum(b) & 0xFF":
        lambda b, n: (lambda cA, cX: (sum(b) & 0xFF, b[cX]))(n - 12, n - 11),
    "H  X = XOR(all)":
        lambda b, n: (lambda cA, cX: ((lambda x: x)(__import__('functools').reduce(lambda a, c: a ^ c, b, 0)), b[cX]))(n - 12, n - 11),
    "I  X = sum(0x4400..cA-1)+sum(bX+1..)-1 & 0xFF":
        lambda b, n: (lambda cA, cX: ((sum(b[0x4400:cA]) + sum(b[cX + 1:n]) - 1) & 0xFF, b[cX]))(n - 12, n - 11),
}
for label, fn in CANDS.items():
    hits, misses = [], []
    for nm, b, n in rows:
        got, obs = fn(b, n)
        (hits if got == obs else misses).append(nm)
    print("%-58s 命中 %2d/%-2d %s" % (label, len(hits), len(rows),
                                      "✅ 全部命中" if not misses else "✗ %s" % ", ".join(
                                          m.split('-')[0][:12] + "…" for m in misses[:3])))

print("\n" + "=" * 112)
print("三、按作品分组看 X（判断是否与内容无关）")
print("=" * 112)
groups = {"SL 日版 (SLPS-25169)": [], "SL 美版 (SLUS-20644)": [],
          "NX 日版 (SLPS-25338)": [], "LR 日版 (SLPS-25462)": []}
for nm, b, n in rows:
    if "25169" in nm:
        groups["SL 日版 (SLPS-25169)"].append((nm, b, n))
    elif "20644" in nm:
        groups["SL 美版 (SLUS-20644)"].append((nm, b, n))
    elif "25338" in nm:
        groups["NX 日版 (SLPS-25338)"].append((nm, b, n))
    else:
        groups["LR 日版 (SLPS-25462)"].append((nm, b, n))
for g, items in groups.items():
    xs = sorted({b[n - 11] for _, b, n in items})
    print("  %-24s 样本 %d 份  X 取值 %s  %s" % (
        g, len(items), ["0x%02X" % x for x in xs],
        "← 内容不同但 X 相同 ⇒ 与内容无关" if len(items) > 1 and len(xs) == 1 else ""))

print("\n" + "=" * 112)
print("四、结论性判断")
print("=" * 112)
print("""  · 若第二节没有任何公式能全中，而第三节显示"同一作品内不同内容 X 相同"
    ⇒ X 是**按作品的常量**（和 0x14..0x1C 那 9 字节同一性质），
      写入时必须从同作品的真实存档里读出来填上，不能留 0。""")
