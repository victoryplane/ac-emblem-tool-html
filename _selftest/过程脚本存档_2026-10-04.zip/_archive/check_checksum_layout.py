# -*- coding: utf-8 -*-
r"""★ 校验布局的根基核对：真实样本的每一段校验字节，实际值 vs 我们的公式。

背景：调色板物理范围算出来是 0x4034..0x4434，也就是说 0x4434 同时是
"末段校验字节"和"palette[255].alpha"。真实样本在 0x4434 永远是 0x80。
若我们的公式真能解释这个 0x80，那纯属巧合得离谱；更可能是：
  · 0x4434 是数据（palette[255].alpha，游戏固定写 0x80）
  · 真正的末段校验在 0x4435 —— 也就是那 11 字节"尾巴"的第 1 字节
本脚本把两种假说都算出来，看哪个能解释全部 10 份真实样本。
"""
from __future__ import annotations

import os
import sys

PROJ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(PROJ, "tools"))
import acet_format as af                                    # noqa: E402

REAL = os.path.join(PROJ, "testdata", "real")
FILES = ["BASLUS-20644E02_rawblock.raw", "BISLPS-25169E00.raw", "BISLPS-25169E01.raw",
         "BISLPS-25338E00.raw", "BISLPS-25338E01.raw", "BISLPS-25338E02.raw",
         "BISLPS-25338E03.raw", "BISLPS-25338E04.raw",
         "BISLPS-25462EMB_data0.raw", "BISLPS-25462EMB_data1.raw"]

print("=" * 100)
print("一、常规 17 段：实际校验字节 vs 公式 -(sum(数据)+len) & 0xFF")
print("=" * 100)
allok = True
for nm in FILES:
    p = os.path.join(REAL, nm)
    if not os.path.exists(p):
        continue
    b = af.read_save_file(p)
    is_lr = af.is_lr_save(b)
    bad = []
    for idx, (start, dlen, cpos, seed) in enumerate(af.segment_layout(is_lr)):
        if idx == 17:
            continue
        data = b[start:cpos]
        exp = af.compute_checksum(data, dlen, seed)
        got = b[cpos]
        if exp != got:
            bad.append((idx, cpos, got, exp))
    print("%-30s 17 段: %s" % (nm, "全部相符 ✅" if not bad else "❌ %s" % bad))
    allok = allok and not bad

print("\n" + "=" * 100)
print("二、末段：三种假说")
print("=" * 100)
print("  A) 校验@0x4434，数据 0x4400..0x4433(52B) + 尾巴 0x4435..0x443F    ← 我们当前实现")
print("  B) 校验@0x4434，数据 0x4400..0x4433(52B)，不含尾巴")
print("  C) 校验@0x4435，数据 0x4400..0x4434(53B) = 含 palette[255].alpha")
print("  D) 校验@0x4435，数据 0x4400..0x4433(52B)")
print("  E) 校验@0x4435，数据 0x4400..0x4434(53B) + 尾巴 0x4436..0x443F，len=53")
print("-" * 100)
print("%-30s %-6s %-6s | %-5s %-5s | %-5s %-5s | %-5s %-5s | %-5s %-5s | %-5s %-5s"
      % ("文件", "b4434", "b4435", "A得", "A中", "B得", "B中", "C得", "C中", "D得", "D中", "E得", "E中"))
for nm in FILES:
    p = os.path.join(REAL, nm)
    if not os.path.exists(p):
        continue
    b = af.read_save_file(p)
    is_lr = af.is_lr_save(b)
    size = len(b)
    tail = b[size - 11:size]                      # 0x4435..0x443F
    d52 = b[size - 12 - 52:size - 12]             # 0x4400..0x4433
    c53 = b[size - 12 - 52:size - 11]             # 0x4400..0x4434
    b4434 = b[size - 12]
    b4435 = b[size - 11]
    A = af.compute_checksum(d52 + tail, 52, 0)
    B = af.compute_checksum(d52, 52, 0)
    C = af.compute_checksum(c53, 53, 0)
    D = af.compute_checksum(d52, 52, 0)
    E = af.compute_checksum(c53 + b[size - 10:size], 53, 0)
    print("%-30s %02X     %02X     | %02X %-5s | %02X %-5s | %02X %-5s | %02X %-5s | %02X %-5s"
          % (nm, b4434, b4435,
             A, "✅" if A == b4434 else "✗", B, "✅" if B == b4434 else "✗",
             C, "✅" if C == b4435 else "✗", D, "✅" if D == b4435 else "✗",
             E, "✅" if E == b4435 else "✗"))

print("\n" + "=" * 100)
print("三、我们的 verify_checksums() 对真实样本的判定")
print("=" * 100)
for nm in FILES:
    p = os.path.join(REAL, nm)
    if not os.path.exists(p):
        continue
    b = af.read_save_file(p)
    ok, bad = af.verify_checksums(b)
    print("%-30s %s" % (nm, "18/18 ✅" if ok else "❌ %s" % bad))

print("\n" + "=" * 100)
print("四、0x4434 与 0x4435 在真实样本里的取值（10 份）")
print("=" * 100)
v34, v35, v36 = set(), set(), set()
for nm in FILES:
    p = os.path.join(REAL, nm)
    if not os.path.exists(p):
        continue
    b = af.read_save_file(p)
    v34.add(b[len(b) - 12]); v35.add(b[len(b) - 11]); v36.add(b[len(b) - 10])
print("  0x4434 取值集合: %s" % sorted("0x%02X" % v for v in v34))
print("  0x4435 取值集合: %s" % sorted("0x%02X" % v for v in v35))
print("  0x4436 取值集合: %s" % sorted("0x%02X" % v for v in v36))
