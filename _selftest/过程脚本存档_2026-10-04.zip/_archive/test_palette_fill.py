# -*- coding: utf-8 -*-
r"""★ 结构假设验证：紧凑编码 + **把未用调色板项填满**（不再留 0）。

上一轮定案（2026-10-04 实机）：
  · **缩略图由「存档数据」渲染**，与 `ICO` 无关
    （diag 卡：E00 的 ICO 画成棋盘格、缩略图仍正常；E01 只改数据、缩略图变反色）
  · **结构保持的内容改动被接受**（E01 反色 122 个被引用调色板项 → 正常 load）
    ⇒ **没有隐藏的内容校验**
  ⇒ 那么"紧凑玫瑰"被拒就只剩**结构**原因：最可能是 **164 个零值调色板项**。

实测统计：游戏自己的每份存档，**256 个调色板项里一个 0 都没有**
（SL 玫瑰：未用槽 164 个全非零；NX CREST：237 个全非零）。
而 `acet` 的注入**只写用到的项**，其余留 0。

卡 `Mcd001_fill.ps2`：
  E00 = 紧凑玫瑰 + 未用项**循环填成已用色**（alpha 0x80）
  E01 = 紧凑玫瑰 + 未用项**统一填成 `00 00 00 80`**
（两格的像素索引、用到的颜色、头部、校验完全一样，**只差未用项填什么**）
"""
from __future__ import annotations

import importlib.util
import os
import shutil
import sys

MC_DIR = r"C:\Users\M\Documents\PCSX2\memcards"
SRC_CARD = os.path.join(MC_DIR, "Mcd001_embdata2.ps2")
DST_CARD = os.path.join(MC_DIR, "Mcd001_fill.ps2")
PROJ = r"E:\Armored Core\Armored Core\PS2\emblem-tool"
SURV = r"E:\Armored Core\Armored Core\PS2\AC3_CN\tools\30-存档\61_mc_survey.py"
US2JP = r"E:\Armored Core\Armored Core\PS2\AC3_CN\tools\30-存档\65_us2jp.py"
sys.path.insert(0, os.path.join(PROJ, "tools"))
import acet_format as af                      # noqa: E402


def load_mod(name, path):
    s = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(s)
    sys.modules[name] = m
    s.loader.exec_module(m)
    return m


sv = load_mod("sv", SURV)
us2jp = load_mod("us2jp", US2JP)
c0 = sv.Card(SRC_CARD)


def files_of(card, dn):
    r = card.dirents(card.rootdir, card.dir_count(card.rootdir))
    d = [e for e in r if e["name"] == dn][0]
    return {s["name"]: s for s in card.dirents(d["cluster"], d["length"])
            if s["name"] not in (".", "..") and s["length"]}


E00, E01 = "BISLPS-25169E00", "BISLPS-25169E01"
s00 = files_of(c0, E00)[E00]
ref = c0.read_file(s00["cluster"], s00["length"])
tail = af.header_tail_from_save(ref)
rose = af.read_save_file(os.path.join(PROJ, "testdata", "real", "BASLUS-20644E02_rawblock.raw"))
img = af.extract_image(rose, alpha_mode="index0")

base = af.make_blank_save(is_lr=False, with_header=True, header_tail=tail)
af.inject_image(base, img)
base = bytearray(base)


def fill_unused(blk: bytearray, mode: str) -> bytearray:
    b = bytearray(blk)
    io = af.IMAGE_OFFSET
    idx = [b[af.offset_index(io + i, 0)] for i in range(af.NUM_PIXELS)]
    used = sorted({af.unscramble_palette(p) for p in set(idx)})
    unused = [k for k in range(1, 256) if k not in used]
    tgt = [af.offset_index(io + af.NUM_PIXELS + k*4 + ch, 0) for k in unused for ch in range(4)]
    if mode == "cycle":
        src_used = [k for k in used if k != 0]
        for n, k in enumerate(unused):
            s_k = src_used[n % len(src_used)]
            for ch in range(4):
                b[af.offset_index(io + af.NUM_PIXELS + k*4 + ch, 0)] = \
                    b[af.offset_index(io + af.NUM_PIXELS + s_k*4 + ch, 0)]
    elif mode == "black":
        for k in unused:
            o = af.offset_index(io + af.NUM_PIXELS + k*4, 0)
            b[o], b[o+1], b[o+2], b[o+3] = 0x00, 0x00, 0x00, 0x80
    else:
        raise ValueError(mode)
    af.apply_checksums(b)
    # 断言：像素与用到的颜色没变
    idx2 = [b[af.offset_index(io + i, 0)] for i in range(af.NUM_PIXELS)]
    assert idx2 == idx, "填未用项不应改像素"
    nz = sum(1 for k in range(256)
             if any(b[af.offset_index(io + af.NUM_PIXELS + k*4 + ch, 0)] for ch in range(4)))
    print("   mode=%-6s 未用项 %3d 个已填；非零调色板项 = %d / 256" % (mode, len(unused), nz))
    return b


print("构造两个变体（像素/用色/头完全相同，只差未用项）：")
b_cycle = bytes(fill_unused(base, "cycle"))
b_black = bytes(fill_unused(base, "black"))
for nm, b in (("cycle", b_cycle), ("black", b_black)):
    ok, bad = af.verify_checksums(b)
    print("   %s 校验: %s ; 与另一变体差异 %d 字节"
          % (nm, "18/18 ✅" if ok else bad, sum(1 for x, y in zip(b_cycle, b_black) if x != y)))

shutil.copyfile(SRC_CARD, DST_CARD)
c = us2jp.Writable(DST_CARD)
print("\n=== 写入 ===")
for dn, blob, tag in ((E00, b_cycle, "未用项=循环填已用色"), (E01, b_black, "未用项=00 00 00 80")):
    s = files_of(c, dn)[dn]
    assert s["length"] == len(blob)
    ch = c.chain(s["cluster"], 4096)
    for i in range((len(blob) + 1023)//1024):
        c.write_cluster_bytes(ch[i], blob[i*1024:(i+1)*1024])
    print("  %s : %s" % (dn, tag))
c.f.close()

print("\n=== 回读 ===")
c2 = sv.Card(DST_CARD)
for dn, want, tag in ((E00, b_cycle, "cycle"), (E01, b_black, "black")):
    got = c2.read_file(files_of(c2, dn)[dn]["cluster"], len(want))
    nz = 0
    io = af.IMAGE_OFFSET
    for k in range(256):
        if any(got[af.offset_index(io + af.NUM_PIXELS + k*4 + ch, 0)] for ch in range(4)):
            nz += 1
    print("  %s (%s): 与预期相同 %s ; 校验 %s ; 非零调色板项 %d/256"
          % (dn, tag, got == want, af.verify_checksums(got)[0], nz))
try:
    from PIL import Image
    Image.frombytes("RGBA",(128,128), af.extract_image(c2.read_file(files_of(c2,E00)[E00]["cluster"], len(b_cycle)), alpha_mode="index0")).save(
        os.path.join(PROJ,"out","fill_预期外观.png"))
    print("  已导出 out/fill_预期外观.png")
except Exception as e:
    print("  (PNG 跳过: %s)" % e)
print("\n新卡: %s" % DST_CARD)
print("""
⇒ 换卡后看 SL 第 1、2 格：
   两格都正常 load（都显示玫瑰）      ⇒ ★ "未用调色板项不能是 0" 就是原因，问题解决
   第 1 格正常、第 2 格破損          ⇒ 填的内容也重要（那用"循环填已用色"那套）
   两格都破損                        ⇒ 不是零值项的问题，回去查索引稀疏度
""")
