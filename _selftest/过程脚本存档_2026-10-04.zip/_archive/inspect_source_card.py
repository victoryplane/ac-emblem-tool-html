# -*- coding: utf-8 -*-
r"""只读：把源卡上所有徽章槽的实际状态摊开（为下一轮写入实验做准备）。

要点：
  · 每个槽的目录 / 文件 / 长度 / 首簇
  · `icon.sys@0xDF`（槽位号）——NX 那 5 个曾是**全 0**，会让游戏卡死
  · 每份徽章数据的：9 字节作品常量、**尾部 11 字节**、被引用槽数、未用项的 alpha 取值
"""
from __future__ import annotations

import importlib.util
import os
import re
import sys

PROJ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SURV = r"E:\Armored Core\Armored Core\PS2\AC3_CN\tools\30-存档\61_mc_survey.py"
sys.path.insert(0, os.path.join(PROJ, "tools"))
import acet_format as af                                    # noqa: E402

MC_DIR = r"C:\Users\M\Documents\PCSX2\memcards"
CARDS = ["Mcd001_embdata2.ps2", "Mcd001.ps2"]

spec = importlib.util.spec_from_file_location("sv", SURV)
sv = importlib.util.module_from_spec(spec)
spec.loader.exec_module(sv)


def show(path):
    print("\n" + "=" * 108)
    print("卡: %s" % path)
    print("=" * 108)
    card = sv.Card(path)
    roots = card.dirents(card.rootdir, card.dir_count(card.rootdir))
    for e in roots:
        name = e["name"]
        if name in (".", ".."):
            continue
        if not (name.endswith("EMB") or re.search(r"E\d\d$", name)):
            continue
        if not (e["mode"] & 0x8000 and e["length"]):
            continue
        subs = card.dirents(e["cluster"], e["length"])
        files = {s["name"]: s for s in subs if s["name"] not in (".", "..") and s["length"]}
        print("\n[%s]  mode=0x%04X len=%d cluster=%d  文件: %s"
              % (name, e["mode"], e["length"], e["cluster"], list(files)))
        ico = files.get("icon.sys")
        if ico:
            ic = card.read_file(ico["cluster"], ico["length"])
            ttl = ic[0xC0:0x104].split(b'\x00')[0]
            print("     icon.sys %d B  0x06=%d  0xDF(槽号)=%d  标题=%r"
                  % (ico["length"], ic[0x06], ic[0xDF], ttl.decode('cp932', 'replace')))
        data_name = [k for k in files if k not in ("icon.sys",) and not k.upper().endswith(".ICO")]
        for dn in data_name:
            s = files[dn]
            b = card.read_file(s["cluster"], s["length"])
            kind = af.save_kind(b)
            print("     %-16s %6d B  首簇=%-6d %s" % (dn, s["length"], s["cluster"], kind))
            if kind == "emblem-raw":
                io = af.IMAGE_OFFSET
                idx = [b[af.offset_index(io + i, 0)] for i in range(af.NUM_PIXELS)]
                used = sorted({af.unscramble_palette(p) for p in set(idx)})
                pal = [b[af.offset_index(io + af.NUM_PIXELS + k, 0)] for k in range(af.PALETTE_SIZE)]
                alphas = sorted({pal[k*4+3] for k in range(256)})
                unused_alpha = sorted({pal[k*4+3] for k in range(256) if k not in set(used)})
                unused_rgb = sorted({tuple(pal[k*4:k*4+3]) for k in range(256) if k not in set(used)})
                print("       作品常量 0x14..0x1C = %s" % af.header_tail_from_save(b).hex(' '))
                print("       尾部 0x%04X..0x%04X = %s" % (len(b)-11, len(b)-1, b[len(b)-11:].hex(' ')))
                print("       引用槽 %d 个（最大 %d）  调色板 alpha 取值 %s"
                      % (len(used), max(used), ["0x%02X" % a for a in alphas]))
                print("       未用槽 %d 个：alpha 取值 %s  RGB 取值%s"
                      % (256 - len(used), ["0x%02X" % a for a in unused_alpha],
                         "全为 00 00 00" if unused_rgb == [(0,0,0)] else " %d 种（非全零）" % len(unused_rgb)))
            elif kind == "emblem-lr":
                print("       尾部 0x%04X..0x%04X = %s" % (len(b)-11, len(b)-1, b[len(b)-11:].hex(' ')))


for c in CARDS:
    p = os.path.join(MC_DIR, c)
    if os.path.exists(p):
        show(p)
