# -*- coding: utf-8 -*-
r"""NX 卡死排查：修正 `icon.sys` 里的「槽位号」自相矛盾。

发现（2026-10-04）：
  SL 的 `BISLPS-25169E00/E01` 的 `icon.sys@0xDF` = 0x00 / 0x01  ← 与槽号一致
  NX 的 `BISLPS-25338E00..E04` 的 `icon.sys@0xDF` **全是 0x00**  ← 5 个槽都声称自己是槽 0
  且 5 个标题全是 `ＡＣＮＥＸＵＳ　徽章　Ｎｏ．１`

假设：游戏按 `0xDF`（和/或标题里的 `Ｎｏ．Ｘ`）识别槽号；5 个同号 ⇒ 枚举/查表越界 ⇒ 卡死。

本脚本只改**这两个地方**，存档数据一个字节都不动：
  · `icon.sys@0xDF`        → 0,1,2,3,4
  · 标题里的 `Ｎｏ．Ｘ`     → １,２,３,４,５（全角；ＳＪＩＳ 0x8250+n）

源卡只读；产物写到新卡。
"""
from __future__ import annotations

import importlib.util
import os
import shutil
import sys

MC_DIR = r"C:\Users\M\Documents\PCSX2\memcards"
SRC_CARD = os.path.join(MC_DIR, "Mcd001_embdata2.ps2")
DST_CARD = os.path.join(MC_DIR, "Mcd001_nxfix.ps2")
SURV = r"E:\Armored Core\Armored Core\PS2\AC3_CN\tools\30-存档\61_mc_survey.py"
US2JP = r"E:\Armored Core\Armored Core\PS2\AC3_CN\tools\30-存档\65_us2jp.py"


def load_mod(name, path):
    s = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(s)
    sys.modules[name] = m
    s.loader.exec_module(m)
    return m


sv = load_mod("sv", SURV)
us2jp = load_mod("us2jp", US2JP)

SLOT_BYTE = 0xDF                 # icon.sys 里的槽位号
# 注：标题里的 Ｎｏ． 实际字节是 82 6d 82 8f 81 44（ｏ=0x828F、．=0x8144），
#     不是 82 6d 82 6f 81 45。**本脚本不碰标题** ——
#     因为 SL 的实证是：E00/E01 标题完全相同（且是乱码）也能正常加载 ⇒
#     标题不跟槽号走，只有 0xDF 跟。所以这里只改 0xDF。

shutil.copyfile(SRC_CARD, DST_CARD)
c = us2jp.Writable(DST_CARD)
roots = c.dirents(c.rootdir, c.dir_count(c.rootdir))

# 先看 0xDF 到底落在标题字段的哪个位置
d0 = [e for e in roots if e["name"] == "BISLPS-25338E00"][0]
s0 = [s for s in c.dirents(d0["cluster"], d0["length"]) if s["name"] == "icon.sys"][0]
ic0 = c.read_file(s0["cluster"], s0["length"])
print("NX E00 icon.sys: title 字段 0xC0..0x103（68 B）")
print("  字符串（到首个 NUL）: %r" % ic0[0xC0:].split(b'\x00')[0].decode('cp932', 'replace'))
print("  0xC0..0xE4: %s" % ic0[0xC0:0xE4].hex(' '))
print("  ⇒ 0xDF 在 title 字段内的偏移 = 0x%02X（字符串之后、0x00 填充区里的第 %d 个字节）"
      % (SLOT_BYTE - 0xC0, SLOT_BYTE - 0xC0))

print("\n=== 写入清单（★ 只改 icon.sys@0xDF 一个字节，徽章数据一个字节都不动）===")
for i in range(5):
    dn = "BISLPS-25338E%02d" % i
    dd = [e for e in roots if e["name"] == dn]
    if not dd:
        print("  %s 不存在，跳过" % dn); continue
    fs = {s["name"]: s for s in c.dirents(dd[0]["cluster"], dd[0]["length"])
          if s["name"] not in (".", "..") and s["length"]}
    s = fs["icon.sys"]
    ic = bytearray(c.read_file(s["cluster"], s["length"]))
    old_df = ic[SLOT_BYTE]
    ic[SLOT_BYTE] = i
    ncl = (len(ic) + 1023) // 1024
    ch = c.chain(s["cluster"], 8)
    for k in range(ncl):
        c.write_cluster_bytes(ch[k], bytes(ic[k*1024:(k+1)*1024]))
    print("  %s : 0xDF %02X → %02X" % (dn, old_df, i))
c.f.close()

print("\n=== 回读（并与源卡逐字节比对）===")
src = sv.Card(SRC_CARD)
def fs_of(card, dn):
    r = card.dirents(card.rootdir, card.dir_count(card.rootdir))
    dd = [e for e in r if e["name"] == dn][0]
    return {s["name"]: card.read_file(s["cluster"], s["length"])
            for s in card.dirents(dd["cluster"], dd["length"])
            if s["name"] not in (".", "..") and s["length"]}
c2 = sv.Card(DST_CARD)
for i in range(5):
    dn = "BISLPS-25338E%02d" % i
    a, b = fs_of(src, dn), fs_of(c2, dn)
    di = [k for k in range(len(a["icon.sys"])) if a["icon.sys"][k] != b["icon.sys"][k]]
    dd = sum(1 for x, y in zip(a[dn], b[dn]) if x != y)
    print("  %s : 0xDF=%02X  icon.sys 改了 %d 字节 %s  徽章数据差 %d 字节"
          % (dn, b["icon.sys"][SLOT_BYTE], len(di), ["0x%X" % k for k in di], dd))
print("\n新卡: %s" % DST_CARD)
print("⇒ 用它试 NX：如果不再卡死，就说明是「多个槽同 ID」导致的")
