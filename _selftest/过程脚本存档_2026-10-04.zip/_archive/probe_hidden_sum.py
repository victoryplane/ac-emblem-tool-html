# -*- coding: utf-8 -*-
r"""★ 探针：改一个**没被任何像素引用**的调色板字节 —— 若有隐藏校验，必然被拒。

当前困境：把 SL 某个槽的存档数据换成"紧凑调色板"+正确的 9 字节作品常量后，
游戏仍报 `破損ファイル`。已排除：`icon.sys`（两份内容不同的真实存档，icon.sys 只差
标题长度与标题区，**没有内容相关字段**）。

于是只剩两种可能：
  A. 存在**我们还不知道的内容校验**（那它就必然覆盖"未被引用的调色板字节"）
  B. 没有隐藏校验，问题在**调色板/索引的结构**（零值项 / 稀疏度）

**本探针直接判 A**：只翻转 1 个**未被任何像素引用**的调色板项的 R 通道，重算 18 段校验。
  · 若这一格也报 `破損ファイル` ⇒ **存在隐藏校验**（连没被引用的字节都被校验）
  · 若这一格正常 load            ⇒ **没有隐藏校验**，问题在结构上

两张卡一次问清：
  `Mcd001_probe.ps2`
     E00 = 紧凑玫瑰（已知失败的那种写法）  → 复现
     E01 = 原样 + 1 个未被引用调色板字节   → ★ 关键探针
"""
from __future__ import annotations

import importlib.util
import os
import shutil
import sys

MC_DIR = r"C:\Users\M\Documents\PCSX2\memcards"
SRC_CARD = os.path.join(MC_DIR, "Mcd001_embdata2.ps2")
DST_CARD = os.path.join(MC_DIR, "Mcd001_probe.ps2")
PROJ = r"E:\Armored Core\Armored Core\PS2\emblem-tool"
SURV = r"E:\Armored Core\Armored Core\PS2\AC3_CN\tools\30-存档\61_mc_survey.py"
US2JP = r"E:\Armored Core\Armored Core\PS2\AC3_CN\tools\30-存档\65_us2jp.py"
sys.path.insert(0, os.path.join(PROJ, "tools"))
import acet_format as af                      # noqa: E402


def load_mod(name, path):
    s = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(s)
    sys.modules[name] = m
    s.loader.exec_module(m)
    return m


sv = load_mod("sv", SURV)
us2jp = load_mod("us2jp", US2JP)

c0 = sv.Card(SRC_CARD)


def files_of(card, dn):
    r = card.dirents(card.rootdir, card.dir_count(card.rootdir))
    d = [e for e in r if e["name"] == dn][0]
    return {s["name"]: s for s in card.dirents(d["cluster"], d["length"])
            if s["name"] not in (".", "..") and s["length"]}


E00, E01 = "BISLPS-25169E00", "BISLPS-25169E01"
orig00 = c0.read_file(files_of(c0, E00)[E00]["cluster"], files_of(c0, E00)[E00]["length"])
orig01 = c0.read_file(files_of(c0, E01)[E01]["cluster"], files_of(c0, E01)[E01]["length"])
print("E00 / E01 原始数据逐字节相同: %s" % (orig00 == orig01))

# ---------- E00：紧凑玫瑰（复现失败案例） ----------
tail = af.header_tail_from_save(orig00)
rose = af.read_save_file(os.path.join(PROJ, "testdata", "real", "BASLUS-20644E02_rawblock.raw"))
img = af.extract_image(rose, alpha_mode="index0")
blk_rose = af.make_blank_save(is_lr=False, with_header=True, header_tail=tail)
af.inject_image(blk_rose, img)
blk_rose = bytes(blk_rose)

# ---------- E01：原样 + 改 1 个"未被引用"的调色板字节 ----------
idx = [orig01[af.offset_index(af.IMAGE_OFFSET + i, 0)] for i in range(af.NUM_PIXELS)]
used = {af.unscramble_palette(p) for p in set(idx)}
unused = [k for k in range(1, 256) if k not in used]
# 挑一个"本身非零"的未引用项，改它的 R
target = None
for k in unused:
    o = af.offset_index(af.IMAGE_OFFSET + af.NUM_PIXELS + k * 4, 0)
    if orig01[o] or orig01[o+1] or orig01[o+2]:
        target = (k, o); break
k, o = target
blk_probe = bytearray(orig01)
old = blk_probe[o]
blk_probe[o] = (old + 0x11) & 0xFF
af.apply_checksums(blk_probe)
blk_probe = bytes(blk_probe)
print("E01 探针：改调色板槽 %d（未被任何像素引用）的 R: %02x → %02x" % (k, old, blk_probe[o]))
print("   差异字节数（相对原文件）: %d" % sum(1 for a, b in zip(orig01, blk_probe) if a != b))
print("   被引用的调色板槽数 %d；未引用 %d 个（改的是未引用的）" % (len(used), len(unused)))
for nm, b in (("E00 紧凑玫瑰", blk_rose), ("E01 探针", blk_probe)):
    ok, bad = af.verify_checksums(b)
    print("   %s 校验: %s" % (nm, "18/18 ✅" if ok else "❌ %r" % (bad,)))

# ---------- 写入 ----------
shutil.copyfile(SRC_CARD, DST_CARD)
c = us2jp.Writable(DST_CARD)
print("\n=== 写入 ===")
for dn, data, tag in ((E00, blk_rose, "紧凑玫瑰（复现）"), (E01, blk_probe, "★1 字节探针")):
    s = files_of(c, dn)[dn]
    assert s["length"] == len(data)
    ch = c.chain(s["cluster"], 4096)
    for i in range((len(data) + 1023) // 1024):
        c.write_cluster_bytes(ch[i], data[i*1024:(i+1)*1024])
    print("  %s : %s（%d 簇）" % (dn, tag, (len(data)+1023)//1024))
c.f.close()

# ---------- 回读 ----------
print("\n=== 回读 ===")
c2 = sv.Card(DST_CARD)
for dn, want in ((E00, blk_rose), (E01, blk_probe)):
    s = files_of(c2, dn)[dn]
    got = c2.read_file(s["cluster"], s["length"])
    print("  %s : 与预期相同 %s ; 校验 %s" % (dn, got == want, af.verify_checksums(got)[0]))
print("\n新卡: %s" % DST_CARD)
print("⇒ 进 SL 分别 load 这两个槽，回报哪个 `破損ファイル`：")
print("     两格都破  ⇒ ★ 存在隐藏的内容校验（连未被引用的字节都被校验）")
print("     只有 E00 破、E01 正常 ⇒ 没有隐藏校验，问题在调色板/索引的**结构**")
