# -*- coding: utf-8 -*-
r"""真实徽章样本的**调色板 / 索引结构**统计（只读）。

目的：给"PS1 ⇄ PS2 通用徽章导入工具"定接口。
要回答的问题：
  · PS2 那边**调色板是不是必须从 0 连续排**？有没有空洞？
  · 未用到的调色板项里是什么（全 0？残留？）
  · 像素索引用到哪些值、最大值多少、和"颜色数"是什么关系
  · 非 LR 的乱序置换在真实数据上是否**始终自洽**
  · 透明（索引 0）占多少
  · PS1 侧是 64×64 / 16 色 / 4bpp（另一套），两边的"颜色数"量级差多少
"""
import os
import sys
import collections

PROJ = r"E:\Armored Core\Armored Core\PS2\emblem-tool"
sys.path.insert(0, os.path.join(PROJ, "tools"))
import acet_format as af                      # noqa: E402

REAL = os.path.join(PROJ, "testdata", "real")
SAMPLES = [
    ("SL  (公开库)", "BASLUS-20644E02_rawblock.raw"),
    ("SL  MIRAGE",   "BISLPS-25169E00.raw"),
    ("NX  CREST",    "BISLPS-25338E00.raw"),
    ("LR  恶魔脸",   "BISLPS-25462EMB_data0.raw"),
    ("LR  红树",     "BISLPS-25462EMB_data1.raw"),
]


def analyze(path):
    s = af.read_save_file(path)
    is_lr = af.is_lr_save(s)
    base = af.find_offset(s) if len(s) > af.SAVE_SIZE else 0
    io = af.LR_IMAGE_OFFSET if is_lr else af.IMAGE_OFFSET

    def pix(i):
        return s[af.offset_index(io + i, base)]

    def pal(k, ch):
        return s[af.offset_index(io + af.NUM_PIXELS + k * 4 + ch, base)]

    indices = [pix(i) for i in range(af.NUM_PIXELS)]
    palette = [tuple(pal(k, ch) for ch in range(4)) for k in range(256)]

    # 像素索引 → 调色板槽号（非 LR 过一次乱序；对合，所以同一个 LUT）
    slot = (lambda p: p) if is_lr else af.unscramble_palette

    used_px = set(indices)
    used_slots = sorted({slot(p) for p in used_px})
    # 槽位是否从 0 连续
    contig = used_slots == list(range(len(used_slots)))
    gaps = [k for k in range(max(used_slots) + 1) if k not in used_slots]

    # 不透明像素真正用到的 RGB（排除索引 0 = 背景）
    rgb_opaque = {(palette[slot(p)][0], palette[slot(p)][1], palette[slot(p)][2])
                  for p in used_px if p != 0}
    alphas = collections.Counter(palette[k][3] for k in used_slots)
    # 未用到的调色板项是不是全 0
    unused_nonzero = [k for k in range(256) if k not in used_slots and any(palette[k])]
    n0 = indices.count(0)
    hist = collections.Counter(indices)

    return dict(
        size=len(s), lr=is_lr, n_idx=len(used_px), max_idx=max(used_px),
        n_slots=len(used_slots), contig=contig, gaps=gaps,
        n_colors=len(rgb_opaque), n0=n0, alphas=dict(sorted(alphas.items())),
        unused_nonzero=len(unused_nonzero), hist=hist, palette=palette, slot=slot,
        used_slots=used_slots, rgb_opaque=rgb_opaque,
    )


print("=" * 100)
print("表 1 · 总体结构")
print("=" * 100)
hdr = "%-14s %-4s %6s %6s %6s %6s %7s %7s %6s %-22s %s"
print(hdr % ("样本", "布局", "大小", "用索引", "最大", "用槽位", "连续?", "颜色数", "透明px", "alpha 直方图", "未用槽非零"))
rows = []
for tag, fn in SAMPLES:
    r = analyze(os.path.join(REAL, fn))
    rows.append((tag, fn, r))
    print(hdr % (tag, "LR" if r["lr"] else "非LR", r["size"], r["n_idx"], r["max_idx"],
                 r["n_slots"], "是" if r["contig"] else "否(%d空)" % len(r["gaps"]),
                 r["n_colors"], r["n0"],
                 str(r["alphas"]), r["unused_nonzero"]))

print()
print("=" * 100)
print("表 2 · 每个样本用到的最多前 8 种颜色（调色板槽 0..N，RGB + alpha）")
print("=" * 100)
for tag, fn, r in rows:
    pal, hist, slot = r["palette"], r["hist"], r["slot"]
    # 按像素数排序槽位
    bycount = collections.Counter()
    for p, n in hist.items():
        bycount[slot(p)] += n
    print("\n[%s]  用到 %d 个槽，前 8 个：" % (tag, r["n_slots"]))
    for k, n in bycount.most_common(8):
        c = pal[k]
        print("    槽 %3d  %6d px   RGBA=%02x %02x %02x %02x" % (k, n, *c))
    if r["n_slots"] <= 20:
        print("    全部槽位: %s" % ", ".join(
            "%d:(%02x%02x%02x,a%02x)" % (k, *pal[k]) for k in r["used_slots"]))

print()
print("=" * 100)
print("表 3 · 索引分布形态（判断调色板是否被紧凑使用）")
print("=" * 100)
for tag, fn, r in rows:
    h = r["hist"]
    top = h.most_common(3)
    print("%-14s 不同索引 %3d 个；最密 3 个: %-30s 最大索引 %3d；索引0 占 %.1f%%"
          % (tag, r["n_idx"], str(top), r["max_idx"], 100.0 * r["n0"] / af.NUM_PIXELS))

print()
print("=" * 100)
print("表 4 · 与 PS1 侧的量级对比（PS1 = 64×64 / 16 色 / 4bpp / 15 位色）")
print("=" * 100)
print("%-14s %-22s %-22s" % ("样本", "PS2 实测", "PS1 规格"))
for tag, fn, r in rows:
    print("%-14s %-22s %-22s" % (tag,
          "%d 色 / %d 槽" % (r["n_colors"], r["n_slots"]),
          "最多 15 色 / 16 槽"))
print("\nPS2 侧最大色数上限 = 255（+ 透明）；像素 128×128=16384、8bpp")
print("PS1 侧             = 15 色（+ 透明）；像素 64×64=4096、4bpp、调色板 16 位 5:5:5")
print("⇒ 面积比 4:1、色数上限比 17:1 ⇒ 向下转换必须减色 + 缩小")
