# -*- coding: utf-8 -*-
r"""一次性：收尾整理后，把文档里指向已归档产物的路径改成新位置。

为什么需要：`tidy_layout.py` 把过程产物移进了 `out/_archive/` 与 `_selftest/_archive/`，
而报告/文档里到处写着 `out/Mcd001_probe.ps2` 这类老路径 —— 不改就成了死链。

做法：先扫描"文件现在在哪"，得到 `basename → 新相对路径`；再把每个 md 里出现的
`out\<名字>` / `out/<名字>`（以及 `_selftest\...`）替换成新路径。只改路径，不改正文。

    python _selftest\_archive\rewrite_refs.py            # 演算
    python _selftest\_archive\rewrite_refs.py --apply     # 真改
"""
from __future__ import annotations

import argparse
import glob
import os
import re

PROJ = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

SCAN = ["out", "out/evidence", "out/preview", "out/_archive/cards", "out/_archive/preview_old",
        "_selftest", "_selftest/_archive", "testdata", "testdata/real", "tools"]
DOCS = ([os.path.join(PROJ, "README.md")]
        + glob.glob(os.path.join(PROJ, "*.md"))
        + glob.glob(os.path.join(PROJ, "docs", "**", "*.md"), recursive=True)
        + glob.glob(os.path.join(PROJ, "_selftest", "**", "*.md"), recursive=True)
        + glob.glob(os.path.join(PROJ, "tools", "*.md"))
        + glob.glob(os.path.join(PROJ, "testdata", "*.md")))


def build_map():
    """basename → 现在所在的相对路径（只在唯一时才用，避免歧义）。"""
    where = {}
    for d in SCAN:
        full = os.path.join(PROJ, d.replace("/", os.sep))
        if not os.path.isdir(full):
            continue
        for f in os.listdir(full):
            if os.path.isfile(os.path.join(full, f)):
                where.setdefault(f, []).append(d.replace("/", "\\") + "\\" + f)
    return {k: v[0] for k, v in where.items() if len(v) == 1}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--apply", action="store_true")
    a = ap.parse_args()
    m = build_map()
    print("已定位 %d 个产物文件" % len(m))
    total = 0
    for doc in sorted(set(DOCS)):
        if not os.path.exists(doc):
            continue
        txt = open(doc, encoding="utf-8").read()
        orig = txt
        hits = []

        def sub(mt):
            base = mt.group("base")
            if base not in m:
                return mt.group(0)
            sep = "\\" if "\\" in mt.group(0) else "/"     # 保持原文的斜杠风格
            new = m[base].replace("\\", sep)
            if new == mt.group(0):
                return mt.group(0)          # 位置没变
            hits.append("%s → %s" % (mt.group(0), new))
            return new

        # out\<名> / out/<名> 与 _selftest\<名> / _selftest/<名>
        txt = re.sub(r"(?P<dir>(?:out|_selftest))[\\/](?P<base>[^\\/\s`\)\|,，。；]+)", sub, txt)
        if txt != orig:
            n = len(hits)
            total += n
            print("\n%s  (%d 处)" % (os.path.relpath(doc, PROJ), n))
            for h in hits:
                print("   " + h)
            if a.apply:
                open(doc, "w", encoding="utf-8", newline="").write(txt)
    print("\n合计 %d 处%s" % (total, "（已写入）" if a.apply else "（演算，未写入）"))


if __name__ == "__main__":
    raise SystemExit(main())
