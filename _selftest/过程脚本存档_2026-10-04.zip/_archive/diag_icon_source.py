# -*- coding: utf-8 -*-
r"""★★ 判别卡：把"图标从哪来"和"有没有隐藏校验"一次问清。

已知矛盾：
  `Mcd001_sltest2.ps2` 上我把 SL `E01` 的**数据文件**和 **ICO 尾部贴图**都换成了玫瑰，
  但实机缩略图**仍是 MIRAGE**，load **仍 `破損ファイル`**。
  ⇒ "缩略图走 ICO 尾部贴图"这条**也不成立**（否则应该看到玫瑰）。
  ⇒ 必须做一个**视觉上不可能认错**的判别。

卡 `Mcd001_diag.ps2`：

  E00 = **只改 ICO 尾部贴图**（画成红/蓝 8×8 棋盘格），**存档数据一个字节不动**
        · 缩略图若变成棋盘格 ⇒ 图标确实来自 ICO 贴图
        · 缩略图仍是 MIRAGE   ⇒ 图标不来自 ICO 贴图（那 83.7% 的相关性是巧合/另有用途）
        · 且 E00 的数据没动 ⇒ 它应该能正常 load（顺便验证写入机制没把别的搞坏）

  E01 = **只改存档数据**（结构完全保持：索引不动、未引用调色板项不动、头不动），
        只把**被像素引用的那 122 个调色板项的 RGB 取反**，再翻转 1 个**未被引用**项的字节
        · 缩略图若变成"反色 MIRAGE" ⇒ 图标来自存档数据
        · load 若正常 ⇒ **没有隐藏的内容校验**（连未被引用的字节都能改）
        · load 若仍破損 ⇒ ★ 存在隐藏校验（或本改动本身有问题）
"""
from __future__ import annotations

import importlib.util
import os
import shutil
import sys

MC_DIR = r"C:\Users\M\Documents\PCSX2\memcards"
SRC_CARD = os.path.join(MC_DIR, "Mcd001_embdata2.ps2")
DST_CARD = os.path.join(MC_DIR, "Mcd001_diag.ps2")
PROJ = r"E:\Armored Core\Armored Core\PS2\emblem-tool"
SURV = r"E:\Armored Core\Armored Core\PS2\AC3_CN\tools\30-存档\61_mc_survey.py"
US2JP = r"E:\Armored Core\Armored Core\PS2\AC3_CN\tools\30-存档\65_us2jp.py"
sys.path.insert(0, os.path.join(PROJ, "tools"))
import acet_format as af                      # noqa: E402

ICO_NAME = "AC3SLE.ICO"
TEX_OFF = 0x1240
TEX_LEN = 0x8000


def load_mod(name, path):
    s = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(s)
    sys.modules[name] = m
    s.loader.exec_module(m)
    return m


sv = load_mod("sv", SURV)
us2jp = load_mod("us2jp", US2JP)
c0 = sv.Card(SRC_CARD)


def files_of(card, dn):
    r = card.dirents(card.rootdir, card.dir_count(card.rootdir))
    d = [e for e in r if e["name"] == dn][0]
    return {s["name"]: s for s in card.dirents(d["cluster"], d["length"])
            if s["name"] not in (".", "..") and s["length"]}


E00, E01 = "BISLPS-25169E00", "BISLPS-25169E01"


def rd(card, dn, fn):
    s = files_of(card, dn)[fn]
    return card.read_file(s["cluster"], s["length"])


# ---------- E00：只改 ICO 贴图 → 红/蓝棋盘格 ----------
ico00 = bytearray(rd(c0, E00, ICO_NAME))
RED, BLUE = 0x001F, 0x7C00          # BGR555：红 / 蓝
tex = bytearray(TEX_LEN)
for y in range(128):
    for x in range(128):
        v = RED if ((x // 8) + (y // 8)) % 2 == 0 else BLUE
        tex[(y*128+x)*2] = v & 0xFF
        tex[(y*128+x)*2+1] = v >> 8
ico00[TEX_OFF:] = tex
ico00 = bytes(ico00)
print("E00：ICO 尾部贴图 → 红/蓝棋盘格（数据不动）")

# ---------- E01：只改数据 → 被引用的调色板项 RGB 取反 + 翻 1 个未引用字节 ----------
data01 = bytearray(rd(c0, E01, E01))
idx = [data01[af.offset_index(af.IMAGE_OFFSET + i, 0)] for i in range(af.NUM_PIXELS)]
used = sorted({af.unscramble_palette(p) for p in set(idx)})
n_rgb = 0
for k in used:
    if k == 0:
        continue                              # 索引 0 = 背景，保持 (0,0,0)
    for ch in range(3):
        o = af.offset_index(af.IMAGE_OFFSET + af.NUM_PIXELS + k*4 + ch, 0)
        data01[o] = 255 - data01[o]
        n_rgb += 1
unused = [k for k in range(1, 256) if k not in used]
k_un = None
for k in unused:
    o = af.offset_index(af.IMAGE_OFFSET + af.NUM_PIXELS + k*4, 0)
    if data01[o] or data01[o+1] or data01[o+2]:
        k_un = (k, o); break
k_u, o_u = k_un
data01[o_u] = (data01[o_u] + 0x33) & 0xFF
af.apply_checksums(data01)
data01 = bytes(data01)
orig01 = rd(c0, E01, E01)
print("E01：反色了 %d 个被引用调色板项的 RGB（槽 %d 个），并翻转未引用槽 %d 的 R"
      % (n_rgb, len(used), k_u))
print("     相对原文件差异 %d 字节" % sum(1 for a, b in zip(orig01, data01) if a != b))
ok, bad = af.verify_checksums(data01)
print("     校验: %s" % ("18/18 ✅" if ok else "❌ %r" % (bad,)))
af.apply_checksums(bytearray(ico00[:0])) if False else None
print("     （ICO 未动: %s）" % (ico00 == rd(c0, E00, ICO_NAME)))

# ---------- 写入 ----------
shutil.copyfile(SRC_CARD, DST_CARD)
c = us2jp.Writable(DST_CARD)
for dn, fn, blob, tag in ((E00, ICO_NAME, ico00, "ICO 贴图→棋盘格"),
                          (E01, E01, data01, "数据→反色+未引用探针")):
    s = files_of(c, dn)[fn]
    assert s["length"] == len(blob)
    ch = c.chain(s["cluster"], 4096)
    for i in range((len(blob)+1023)//1024):
        c.write_cluster_bytes(ch[i], blob[i*1024:(i+1)*1024])
    print("写入 %s/%s : %s（%d 簇）" % (dn, fn, tag, (len(blob)+1023)//1024))
c.f.close()

# ---------- 回读 ----------
print("\n=== 回读 ===")
c2 = sv.Card(DST_CARD)
print("  E00/ICO 与预期相同: %s" % (rd(c2, E00, ICO_NAME) == ico00))
print("  E01/数据 与预期相同: %s ; 校验 %s" % (rd(c2, E01, E01) == data01, af.verify_checksums(rd(c2, E01, E01))[0]))
print("  E00/数据 未动: %s" % (rd(c2, E00, E00) == rd(c0, E00, E00)))
print("  E01/ICO 未动: %s" % (rd(c2, E01, ICO_NAME) == rd(c0, E01, ICO_NAME)))
try:
    from PIL import Image
    Image.frombytes("RGBA",(128,128), af.extract_image(rd(c2,E01,E01), alpha_mode="index0")).save(
        os.path.join(PROJ,"out","diag_E01_预期外观_数据.png"))
    im = Image.new("RGBA",(128,128)); px=im.load()
    t = rd(c2,E01,ICO_NAME)[TEX_OFF:]
    for i in range(128*128):
        v = int.from_bytes(t[i*2:i*2+2],'little')
        px[i%128,i//128]=(((v&0x1F)<<3),(((v>>5)&0x1F)<<3),(((v>>10)&0x1F)<<3),255)
    im.save(os.path.join(PROJ,"out","diag_E01_预期外观_ICO.png"))
    print("  已导出 out/diag_E01_预期外观_{数据,ICO}.png")
except Exception as e:
    print("  (PNG 跳过: %s)" % e)
print("\n新卡: %s" % DST_CARD)
print("""
⇒ 请【完全关闭并重开 PCSX2】，确认 slot 指向 Mcd001_diag.ps2，然后看缩略图：
   E00 变红蓝棋盘格  ⇒ 缩略图来自 ICO 贴图
   E00 仍是 MIRAGE   ⇒ 缩略图不来自 ICO 贴图
   E01 变"反色 MIRAGE" ⇒ 缩略图来自存档数据
   再分别 load 两格，回报是否 破損（E00 数据没动，应该正常）
""")
