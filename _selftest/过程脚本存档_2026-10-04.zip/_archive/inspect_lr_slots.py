# -*- coding: utf-8 -*-
r"""只读核对：各验证卡的 LR 槽（data0/data1/data2）到底装的是什么图。

用途：用户截图里"LR 第 4 格仍是反色恶魔"，需要先确认**是卡上真的没写进去**，
还是**看的是另一张卡**。这里直接从磁盘上的卡文件读出来认图。
"""
from __future__ import annotations

import importlib.util
import os
import sys

PROJ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SURV = r"E:\Armored Core\Armored Core\PS2\AC3_CN\tools\30-存档\61_mc_survey.py"
sys.path.insert(0, os.path.join(PROJ, "tools"))
import acet_format as af                                    # noqa: E402

MC_DIR = r"C:\Users\M\Documents\PCSX2\memcards"
CARDS = ["Mcd001_embdata2.ps2", "Mcd001_final.ps2", "Mcd001_final2.ps2",
         "Mcd001_final3.ps2", "Mcd001.ps2"]
LR_DIR = "BISLPS-25462EMB"

spec = importlib.util.spec_from_file_location("sv", SURV)
sv = importlib.util.module_from_spec(spec)
spec.loader.exec_module(sv)

REAL = os.path.join(PROJ, "testdata", "real")


def named_images():
    """已知图的指纹 → 名字（用 RGBA 字节做键，避免浮点/编码差异）。"""
    out = {}
    for nm, path in (
        ("玫瑰", os.path.join(REAL, "BASLUS-20644E02_rawblock.raw")),
        ("MIRAGE", os.path.join(REAL, "BISLPS-25169E00.raw")),
        ("CREST", os.path.join(REAL, "BISLPS-25338E00.raw")),
        ("恶魔(data0)", os.path.join(REAL, "BISLPS-25462EMB_data0.raw")),
        ("红树(data1)", os.path.join(REAL, "BISLPS-25462EMB_data1.raw")),
        ("反色恶魔(旧data2)", os.path.join(REAL, "BISLPS-25462EMB_data2.raw")),
    ):
        if os.path.exists(path):
            out[af.extract_image(af.read_save_file(path), alpha_mode="index0")] = nm
    return out


KNOWN = named_images()
print("已知图指纹：%s\n" % list(KNOWN.values()))

for cn in CARDS:
    p = os.path.join(MC_DIR, cn)
    if not os.path.exists(p):
        print("卡 %-26s 不存在" % cn); continue
    card = sv.Card(p)
    roots = {e["name"]: e for e in card.dirents(card.rootdir, card.dir_count(card.rootdir))
             if e["name"] not in (".", "..")}
    print("卡 %-26s" % cn)
    if LR_DIR not in roots:
        print("    （没有 %s）" % LR_DIR); continue
    e = roots[LR_DIR]
    subs = {s["name"]: s for s in card.dirents(e["cluster"], e["length"])
            if s["name"] not in (".", "..") and s["length"]}
    print("    LR 目录项数(len)=%d  文件: %s" % (e["length"], sorted(subs)))
    for fn in ("data0", "data1", "data2"):
        if fn not in subs:
            print("      %-6s 不存在" % fn); continue
        s = subs[fn]
        b = card.read_file(s["cluster"], s["length"])
        lr = af.is_lr_save(b)
        img = af.extract_image(b, alpha_mode="index0") if lr else None
        name = KNOWN.get(img, "?（不认识的图）") if img else "非 %d 字节" % af.LR_SAVE_SIZE
        print("      %-6s %6d B  首簇=%-6d 块头=%s  → %s"
              % (fn, s["length"], s["cluster"], b[:4].hex(' '), name))
    print()
