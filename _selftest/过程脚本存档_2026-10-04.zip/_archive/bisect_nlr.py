# -*- coding: utf-8 -*-
r"""★ 决定性实验：把 5 个"改动程度不同"的版本放进 NX 的 5 个重复槽，一次实测二分定位。

背景：SL 上"紧凑重编码"被游戏判 `破損ファイル`；补了 0x14..0x1C 的作品常量后**仍然破損**。
现在不知道是"任何内容改动都会破"（⇒ 有我们没发现的隐藏校验），
还是"某种特定改动方式破"（⇒ 调色板/索引排布有要求）。

NX 的 `BISLPS-25338E00..E04` 是**5 份逐字节相同的副本**，正好当 5 个实验位：

  E00  不动（参照：确认 NX 这一屏本来就正常）
  E01  **逐字节原样重写**（对照：验"我的写入机制"本身有没有问题）
  E02  只把 0x14..0x1C 那 9 字节清零（复验"作品常量确实必要"）
  E03  **只改 1 个被引用的调色板项**（R+1）（探"是否存在隐藏的内容校验"）
  E04  **紧凑重编码**（当前失败的那种写法）

读法：
  E01 破 ⇒ 写入机制有问题（换页/ECC/簇）
  E01 好、E03 破 ⇒ **存在隐藏的内容校验**（只改 1 个颜色就破）
  E03 好、E04 破 ⇒ **调色板/索引排布有要求**（不是任意排布都行）
  全好 ⇒ 说明 SL 那边是别的原因
"""
from __future__ import annotations

import importlib.util
import os
import shutil
import sys

MC_DIR = r"C:\Users\M\Documents\PCSX2\memcards"
SRC_CARD = os.path.join(MC_DIR, "Mcd001_embdata2.ps2")
DST_CARD = os.path.join(MC_DIR, "Mcd001_bisect.ps2")
PROJ = r"E:\Armored Core\Armored Core\PS2\emblem-tool"
SURV = r"E:\Armored Core\Armored Core\PS2\AC3_CN\tools\30-存档\61_mc_survey.py"
US2JP = r"E:\Armored Core\Armored Core\PS2\AC3_CN\tools\30-存档\65_us2jp.py"
sys.path.insert(0, os.path.join(PROJ, "tools"))
import acet_format as af                      # noqa: E402

GAME = "BISLPS-25338"          # NX 日版
SLOTS = ["%sE%02d" % (GAME, i) for i in range(5)]


def load_mod(name, path):
    s = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(s)
    sys.modules[name] = m
    s.loader.exec_module(m)
    return m


sv = load_mod("sv", SURV)
us2jp = load_mod("us2jp", US2JP)

# ---------- 取参照块（NX E00） ----------
c0 = sv.Card(SRC_CARD)
roots = c0.dirents(c0.rootdir, c0.dir_count(c0.rootdir))
blk, chain_of = {}, {}
for nm in SLOTS:
    d = [e for e in roots if e["name"] == nm][0]
    subs = c0.dirents(d["cluster"], d["length"])
    f = [s for s in subs if s["name"] == nm][0]
    blk[nm] = c0.read_file(f["cluster"], f["length"])
    chain_of[nm] = c0.chain(f["cluster"], 4096)
ref = blk[SLOTS[0]]
assert all(blk[n] == ref for n in SLOTS), "5 个槽不全是同一份副本，这个实验不成立"
print("参照块: NX E00  %d B  头=%s" % (len(ref), ref[:0x24].hex(' ')))
tail = af.header_tail_from_save(ref)
print("作品常量 0x14..0x1C = %s\n" % tail.hex(' '))


def with_checksums(b):
    b = bytearray(b)
    af.apply_checksums(b)
    return bytes(b)


# ---------- 造 5 个变体 ----------
variants = {}
variants[SLOTS[0]] = ("不动（参照）", None)
variants[SLOTS[1]] = ("逐字节原样重写", bytes(ref))

b2 = bytearray(ref)
b2[af.HEADER_TAIL_OFF:af.HEADER_TAIL_OFF + af.HEADER_TAIL_LEN] = b"\x00" * af.HEADER_TAIL_LEN
variants[SLOTS[2]] = ("只清零 0x14..0x1C 作品常量", with_checksums(b2))

# 只改 1 个"被像素引用"的调色板项的 R
idx = [ref[af.offset_index(af.IMAGE_OFFSET + i, 0)] for i in range(af.NUM_PIXELS)]
used = sorted({p for p in idx if p})
b3 = bytearray(ref)
k = used[len(used) // 2]                      # 取中间那个
o = af.offset_index(af.IMAGE_OFFSET + af.NUM_PIXELS + k * 4, 0)
old = b3[o]
b3[o] = (old + 1) & 0xFF
variants[SLOTS[3]] = ("只改 1 个被引用调色板项（槽 %d 的 R: %02x→%02x）" % (k, old, b3[o]),
                      with_checksums(b3))

# 紧凑重编码（先反色，肉眼最好分辨）
img = af.extract_image(ref, alpha_mode="index0")
img_inv = bytes(255 - x if i % 4 != 3 else x for i, x in enumerate(img))
b4 = af.make_blank_save(is_lr=False, with_header=True, header_tail=tail)
af.inject_image(b4, img_inv)
n_col = len({(img_inv[i], img_inv[i+1], img_inv[i+2]) for i in range(0, len(img_inv), 4) if img_inv[i+3] == 0xFF})
variants[SLOTS[4]] = ("紧凑重编码（反色，%d 色）" % n_col, bytes(b4))

# ---------- 写入 ----------
shutil.copyfile(SRC_CARD, DST_CARD)
c = us2jp.Writable(DST_CARD)
print("=== 写入清单 ===")
for nm in SLOTS:
    desc, data = variants[nm]
    if data is None:
        print("  %s : %s（跳过）" % (nm, desc)); continue
    ch = chain_of[nm]
    ncl = (len(data) + 1023) // 1024
    assert len(ch) >= ncl and len(data) == len(ref)
    for i in range(ncl):
        c.write_cluster_bytes(ch[i], data[i*1024:(i+1)*1024])
    ok, bad = af.verify_checksums(data)
    print("  %s : %-42s 校验 %s" % (nm, desc, "18/18 ✅" if ok else "❌ %r" % (bad,)))
c.f.close()

# ---------- 回读 ----------
print("\n=== 回读 ===")
c2 = sv.Card(DST_CARD)
r2 = c2.dirents(c2.rootdir, c2.dir_count(c2.rootdir))
for nm in SLOTS:
    d = [e for e in r2 if e["name"] == nm][0]
    subs = c2.dirents(d["cluster"], d["length"])
    f = [s for s in subs if s["name"] == nm][0]
    got = c2.read_file(f["cluster"], f["length"])
    desc, want = variants[nm]
    same = (want is None) or (got == want)
    print("  %s : 与预期相同 %s  校验 %s" % (nm, same, af.verify_checksums(got)[0]))
print("\n新卡: %s" % DST_CARD)
print("⇒ 进 NX 看这 5 格，按上表回报哪几格是「破損ファイル」")
