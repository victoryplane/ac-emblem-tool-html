# -*- coding: utf-8 -*-
r"""★★ 完整写入验证：**同时改存档数据 + ICO 里的 16 位贴图**。

本轮的关键发现（2026-10-04）：
  记忆卡画面显示的是 **`AC3SLE.ICO` / `ACNEXUSE.ICO` 尾部那 0x8000 字节**，
  而那是**保存当时的 16 位（BGR555）徽章快照**，**不是**存档数据文件。
  ⇒ 只改数据文件，卡片上仍显示旧图（这就是"写了玫瑰却看见 2 个 MIRAGE"的原因）。

ICO 布局（实测，SL/NX 都是）：
  `[0x1240 字节 头部+3D 模型] + [0x8000 字节 128×128 16bit BGR555 贴图]`
  且 `0x1240 + 0x8000 == 文件长度`（37440 = 0x9240）—— 贴图正好是**文件尾巴**。

本脚本把玫瑰**两处都写**：
  1. `BISLPS-25169E01/BISLPS-25169E01`（17472 B）：紧凑调色板 + 索引过乱序 + 正确的作品常量
  2. `BISLPS-25169E01/AC3SLE.ICO` 的最后 0x8000 字节：由该徽章渲染出的 BGR555 贴图
     （索引 0 → 0x0000；其余 = `r>>3 | (g>>3)<<5 | (b>>3)<<10`）
"""
from __future__ import annotations

import importlib.util
import os
import shutil
import sys

MC_DIR = r"C:\Users\M\Documents\PCSX2\memcards"
SRC_CARD = os.path.join(MC_DIR, "Mcd001_embdata2.ps2")
DST_CARD = os.path.join(MC_DIR, "Mcd001_sltest2.ps2")
PROJ = r"E:\Armored Core\Armored Core\PS2\emblem-tool"
SURV = r"E:\Armored Core\Armored Core\PS2\AC3_CN\tools\30-存档\61_mc_survey.py"
US2JP = r"E:\Armored Core\Armored Core\PS2\AC3_CN\tools\30-存档\65_us2jp.py"
sys.path.insert(0, os.path.join(PROJ, "tools"))
import acet_format as af                      # noqa: E402

TARGET = "BISLPS-25169E01"
ICO_NAME = "AC3SLE.ICO"
TEX_OFF = 0x1240          # 贴图在 ICO 内的偏移 = len(ico) - 0x8000
TEX_LEN = 0x8000          # 128*128*2


def load_mod(name, path):
    s = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(s)
    sys.modules[name] = m
    s.loader.exec_module(m)
    return m


sv = load_mod("sv", SURV)
us2jp = load_mod("us2jp", US2JP)


def bgr555(r, g, b):
    return (r >> 3) | ((g >> 3) << 5) | ((b >> 3) << 10)


def render_texture(blk: bytes) -> bytes:
    """把徽章块渲染成 0x8000 字节的 16 位贴图（索引 0 → 0x0000）。"""
    io = af.IMAGE_OFFSET
    out = bytearray(TEX_LEN)
    for i in range(af.NUM_PIXELS):
        p = blk[af.offset_index(io + i, 0)]
        if p == 0:
            continue                                   # 背景 = 0x0000
        q = af.unscramble_palette(p)
        base = af.offset_index(io + af.NUM_PIXELS + q * 4, 0)
        r, g, b = blk[base], blk[base + 1], blk[base + 2]
        v = bgr555(r, g, b)
        out[i*2] = v & 0xFF
        out[i*2 + 1] = v >> 8
    return bytes(out)


# ---------- 取作品常量 ----------
c0 = sv.Card(SRC_CARD)
roots = c0.dirents(c0.rootdir, c0.dir_count(c0.rootdir))
def files_of(card, dn):
    d = [e for e in card.dirents(card.rootdir, card.dir_count(card.rootdir)) if e["name"] == dn][0]
    return {s["name"]: s for s in card.dirents(d["cluster"], d["length"])
            if s["name"] not in (".", "..") and s["length"]}

fs = files_of(c0, "BISLPS-25169E00")
ref = c0.read_file(fs["BISLPS-25169E00"]["cluster"], fs["BISLPS-25169E00"]["length"])
tail = af.header_tail_from_save(ref)
print("作品常量 = %s" % tail.hex(' '))

# ---------- 造新数据块（玫瑰，紧凑调色板） ----------
rose = af.read_save_file(os.path.join(PROJ, "testdata", "real", "BASLUS-20644E02_rawblock.raw"))
img = af.extract_image(rose, alpha_mode="index0")
new_blk = af.make_blank_save(is_lr=False, with_header=True, header_tail=tail)
af.inject_image(new_blk, img)
new_blk = bytes(new_blk)
ok, bad = af.verify_checksums(new_blk)
n_col = len({(img[i], img[i+1], img[i+2]) for i in range(0, len(img), 4) if img[i+3] == 0xFF})
print("新数据块: %d B, %d 色, 校验 %s" % (len(new_blk), n_col, "18/18 ✅" if ok else bad))
new_tex = render_texture(new_blk)
print("新贴图  : %d B（非零像素 %d）" % (len(new_tex), sum(1 for i in range(0, TEX_LEN, 2)
      if new_tex[i] or new_tex[i+1])))

# ---------- 写入 ----------
shutil.copyfile(SRC_CARD, DST_CARD)
c = us2jp.Writable(DST_CARD)
fs = files_of(c, TARGET)
# 1) 数据文件（等长覆盖）
s = fs[TARGET]
assert s["length"] == len(new_blk)
ch = c.chain(s["cluster"], 4096)
for i in range((len(new_blk) + 1023) // 1024):
    c.write_cluster_bytes(ch[i], new_blk[i*1024:(i+1)*1024])
print("\n① 数据文件已写: %s (%d B, %d 簇)" % (TARGET, s["length"], (len(new_blk)+1023)//1024))
# 2) ICO 尾部贴图
s = fs[ICO_NAME]
ico = bytearray(c.read_file(s["cluster"], s["length"]))
assert len(ico) == TEX_OFF + TEX_LEN, "ICO 长度不是 0x1240+0x8000：%d" % len(ico)
old = bytes(ico[TEX_OFF:])
ico[TEX_OFF:] = new_tex
ch = c.chain(s["cluster"], 4096)
for i in range((len(ico) + 1023) // 1024):
    c.write_cluster_bytes(ch[i], bytes(ico[i*1024:(i+1)*1024]))
print("② ICO 贴图已写: %s @0x%X（%d 簇）" % (ICO_NAME, TEX_OFF, (len(ico)+1023)//1024))
c.f.close()

# ---------- 回读 ----------
print("\n=== 回读 ===")
c2 = sv.Card(DST_CARD)
fs2 = files_of(c2, TARGET)
got_blk = c2.read_file(fs2[TARGET]["cluster"], fs2[TARGET]["length"])
got_ico = c2.read_file(fs2[ICO_NAME]["cluster"], fs2[ICO_NAME]["length"])
print("  数据块与预期相同: %s ; 校验 %s" % (got_blk == new_blk, af.verify_checksums(got_blk)[0]))
print("  ICO 贴图与预期相同: %s" % (got_ico[TEX_OFF:] == new_tex))
print("  ICO 前 0x1240 未动: %s" % (got_ico[:TEX_OFF] == c0.read_file(
      files_of(c0, TARGET)[ICO_NAME]["cluster"], files_of(c0, TARGET)[ICO_NAME]["length"])[:TEX_OFF]))
try:
    from PIL import Image
    Image.frombytes("RGBA", (128, 128), af.extract_image(got_blk, alpha_mode="index0")).save(
        os.path.join(PROJ, "out", "sltest2_预期外观_数据.png"))
    im = Image.new("RGBA", (128, 128)); px = im.load()
    for i in range(128*128):
        v = int.from_bytes(got_ico[TEX_OFF+i*2:TEX_OFF+i*2+2], 'little')
        px[i % 128, i // 128] = (((v & 0x1F) << 3), (((v >> 5) & 0x1F) << 3), (((v >> 10) & 0x1F) << 3), 255)
    im.save(os.path.join(PROJ, "out", "sltest2_预期外观_ICO贴图.png"))
    print("  已导出预期外观两张 PNG → out/sltest2_预期外观_*.png")
except Exception as e:
    print("  (PNG 导出跳过: %s)" % e)
print("\n新卡: %s" % DST_CARD)
print("⇒ 进 SL：记忆卡画面第 2 格应变成**玫瑰**，且能正常 load")
