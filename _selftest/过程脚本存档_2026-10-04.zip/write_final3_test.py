# -*- coding: utf-8 -*-
r"""★ 第三张验证卡 `Mcd001_final3.ps2` —— 修正 LR 块头 + 隔离测试作品常量。

`Mcd001_final2.ps2` 卡死了。本目录自查出一个**自己的 bug**：

  ★ `make_blank_save()` 里写的是 `if with_header and not is_lr:` —— **LR 分支根本不写头**。
    真实 LR 块的头 4 字节是 `00 44 00 00`（= 0x4400 = 索引 0x4000 + 调色板 0x400，
    即逻辑载荷长度），我们"从零造"的块却是 `00 00 00 00`。
    卡 2 是**历史上第一次**写"从零造的 LR 块"（卡 1 完全没碰 LR），所以这个 bug
    一直没机会暴露。已修（新增 `LR_EMBLEM_HEADER`），并加了回归断言：
    **从零造的块头必须与真实存档逐字节一致**（`_selftest/validate_writer.py` §四）。

但卡 2 同时改了 NX 的 9 字节作品常量，所以"到底哪个改动导致卡死"仍需分辨。
本卡按**画面隔离 + 每画面只留一个嫌疑格**设计：

  LR（★ 最先测）    data0 / data1 不动（对照）；data2 = **带正确块头的从零造玫瑰** ← 疑点 1
  NX（第二步）      E00 = 玫瑰 + 常量【清零】 ← 疑点 2；E01/E02/E03/E04 全是对照
  SL（最后测）      E00 = 玫瑰 + 【NX 的常量】← 疑点 3；E01 = 玫瑰 + SL 真常量（对照）

⇒ 任何一个画面卡死，都不会妨碍另外两个画面的结果。**按 LR → NX → SL 的顺序测。**
"""
from __future__ import annotations

import hashlib
import importlib.util
import os
import shutil
import sys

MC_DIR = r"C:\Users\M\Documents\PCSX2\memcards"
SRC_CARD = os.path.join(MC_DIR, "Mcd001_embdata2.ps2")
DST_CARD = os.path.join(MC_DIR, "Mcd001_final3.ps2")
PROJ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SURV = r"E:\Armored Core\Armored Core\PS2\AC3_CN\tools\30-存档\61_mc_survey.py"
US2JP = r"E:\Armored Core\Armored Core\PS2\AC3_CN\tools\30-存档\65_us2jp.py"
sys.path.insert(0, os.path.join(PROJ, "tools"))
import acet_format as af                                    # noqa: E402

REAL = os.path.join(PROJ, "testdata", "real")
OUT = os.path.join(PROJ, "out")
LR_DIR = "BISLPS-25462EMB"


def load_mod(name, path):
    s = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(s)
    sys.modules[name] = m
    s.loader.exec_module(m)
    return m


sv = load_mod("sv", SURV)
us2jp = load_mod("us2jp", US2JP)
c0 = sv.Card(SRC_CARD)


def dirs(card):
    return {e["name"]: e for e in card.dirents(card.rootdir, card.dir_count(card.rootdir))
            if e["name"] not in (".", "..")}


def files_of(card, dn):
    d = dirs(card)[dn]
    return {s["name"]: s for s in card.dirents(d["cluster"], d["length"])
            if s["name"] not in (".", "..") and s["length"]}


def blob(card, dn, fn):
    s = files_of(card, dn)[fn]
    return card.read_file(s["cluster"], s["length"])


def load_img(path):
    return af.extract_image(af.read_save_file(path), alpha_mode="index0")


IMG_ROSE = load_img(os.path.join(REAL, "BASLUS-20644E02_rawblock.raw"))
IMG_MIRAGE = load_img(os.path.join(REAL, "BISLPS-25169E00.raw"))
IMG_CREST = load_img(os.path.join(REAL, "BISLPS-25338E00.raw"))
TAIL_NX = af.header_tail_from_save(blob(c0, "BISLPS-25338E00", "BISLPS-25338E00"))
TAIL_SL = af.header_tail_from_save(blob(c0, "BISLPS-25169E00", "BISLPS-25169E00"))
print("NX 常量 = %s" % TAIL_NX.hex(' '))
print("SL 常量 = %s" % TAIL_SL.hex(' '))
print("LR 块头 = %s" % af.LR_EMBLEM_HEADER.hex(' '))

# ---------- 构造 ----------
build = {}          # (目录, 文件名) -> 块
tags = {}


def plan(dn, fn, tag, img, tail9, is_lr=False):
    b = bytes(af.encode_emblem(img, is_lr=is_lr, header_tail=tail9))
    build[(dn, fn)] = b
    tags[(dn, fn)] = tag
    return b


print("\n=== 构造 ===")
# LR：疑点 1
lr_new = plan(LR_DIR, "data2", "★ LR 从零造玫瑰（正确块头）", IMG_ROSE, None, is_lr=True)
# NX：疑点 2 + 对照
plan("BISLPS-25338E00", "BISLPS-25338E00", "★ 玫瑰 + 常量【清零】", IMG_ROSE, bytes(9))
plan("BISLPS-25338E01", "BISLPS-25338E01", "玫瑰 + NX 真常量（对照）", IMG_ROSE, TAIL_NX)
plan("BISLPS-25338E02", "BISLPS-25338E02", "MIRAGE + NX 真常量（对照）", IMG_MIRAGE, TAIL_NX)
plan("BISLPS-25338E03", "BISLPS-25338E03", "CREST + NX 真常量（对照）", IMG_CREST, TAIL_NX)
# SL：疑点 3 + 对照
plan("BISLPS-25169E00", "BISLPS-25169E00", "★ 玫瑰 + 【NX 的常量】", IMG_ROSE, TAIL_NX)
plan("BISLPS-25169E01", "BISLPS-25169E01", "玫瑰 + SL 真常量（对照）", IMG_ROSE, TAIL_SL)

for (dn, fn), b in sorted(build.items()):
    is_lr = af.is_lr_save(b)
    okC, badC = af.verify_checksums(b)
    okA, _ = af.verify_checksums_upstream(b)
    hdr = bytes(b[:4]).hex(' ') if is_lr else b[0x14:0x1D].hex(' ')
    print("  %-28s %-30s %s=%s  校验 真实%s 上游%s"
          % (dn + "/" + fn, tags[(dn, fn)], "块头" if is_lr else "常量", hdr,
             "✅" if okC else "❌%r" % (badC,), "✅" if okA else "❌"))

# ---------- LR 块 vs 真实 LR 块：差异只应落在索引/调色板 ----------
real_lr = blob(c0, LR_DIR, "data0")
img_lr_real = af.extract_image(real_lr, alpha_mode="index0")
ref_lr = bytes(af.encode_emblem(img_lr_real, is_lr=True))
diff = [i for i in range(af.LR_SAVE_SIZE) if ref_lr[i] != real_lr[i]]
hdr_diff = [i for i in diff if i < 4]
print("\n  LR「用真实 data0 的图从零造」vs 真实 data0：差异 %d 字节，其中头 4 字节里 %d 个 %s"
      % (len(diff), len(hdr_diff), "✅" if not hdr_diff else "❌ %s" % hdr_diff))
assert not hdr_diff, "LR 块头仍与真实存档不一致"

# ---------- 写入 ----------
src_sha = hashlib.sha256(open(SRC_CARD, "rb").read()).hexdigest().upper()
shutil.copyfile(SRC_CARD, DST_CARD)
c = us2jp.Writable(DST_CARD)
touched = []

print("\n=== 写入 ===")
for (dn, fn), b in sorted(build.items()):
    s = files_of(c, dn)[fn]
    assert s["length"] == len(b), "%s/%s 长度 %d != %d" % (dn, fn, s["length"], len(b))
    ch = c.chain(s["cluster"], 4096)
    ncl = (len(b) + 1023) // 1024
    assert len(ch) >= ncl
    for i in range(ncl):
        c.write_cluster_bytes(ch[i], b[i * 1024:(i + 1) * 1024])
    touched.append((dn, s["cluster"], ncl))
    print("  %-28s %-30s %d 簇" % (dn + "/" + fn, tags[(dn, fn)], ncl))

print("\n=== 修 NX 槽位号 icon.sys@0xDF（原本全是 0 ⇒ 会卡死）===")
for i in range(5):
    dn = "BISLPS-25338E%02d" % i
    s = files_of(c, dn)["icon.sys"]
    ch = c.chain(s["cluster"], 8)
    ic = bytearray(c.read_file(s["cluster"], 1024))      # 整簇读写，保留空隙字节
    old = ic[0xDF]
    ic[0xDF] = i
    c.write_cluster_bytes(ch[0], bytes(ic))
    touched.append((dn + "/icon.sys", s["cluster"], 1))
    print("  %-16s 0xDF %02X → %02X" % (dn, old, i))
c.f.close()

# ---------- 回读 ----------
print("\n=== 回读 ===")
c2 = sv.Card(DST_CARD)
allok = True
for (dn, fn), want in sorted(build.items()):
    got = blob(c2, dn, fn)
    same = got == want
    okC, _ = af.verify_checksums(got)
    print("  %-28s 与预期相同 %-5s 校验 %-5s" % (dn + "/" + fn, same, "✅" if okC else "❌"))
    allok = allok and same and okC
untouched = [("BISLPS-25338E04", "BISLPS-25338E04"), (LR_DIR, "data0"), (LR_DIR, "data1")]
for dn, fn in untouched:
    same = blob(c2, dn, fn) == blob(c0, dn, fn)
    print("  %-28s 未改动 %-5s" % (dn + "/" + fn, same))
    allok = allok and same

# ---------- 逐页 diff ----------
a = open(SRC_CARD, "rb").read()
b = open(DST_CARD, "rb").read()
S = sv.mc.STRIDE
diff = [n for n in range(len(a) // S) if a[n * S:n * S + 512] != b[n * S:n * S + 512]]
exp = set()
for dn, first, ncl in touched:
    for cl in c2.chain(first, 4096)[:ncl]:
        exp.add(c2.data_page(cl, 0)); exp.add(c2.data_page(cl, 1))
print("\n全盘差异 %d 页 / %d；预期之外多改的页: %s"
      % (len(diff), len(a) // S, sorted(set(diff) - exp) or "无 ✅"))
print("源卡 SHA256 写前 = 写后: %s"
      % (src_sha == hashlib.sha256(open(SRC_CARD, "rb").read()).hexdigest().upper()))
shutil.copyfile(DST_CARD, os.path.join(OUT, os.path.basename(DST_CARD)))

try:
    from PIL import Image
    for (dn, fn), blk in build.items():
        Image.frombytes("RGBA", (128, 128),
                        af.extract_image(blk, alpha_mode="index0")).save(
            os.path.join(OUT, "final3_%s_%s.png" % (dn, fn)))
    print("已导出预期外观 → out/final3_*.png")
except Exception as e:
    print("(PNG 跳过: %s)" % e)

print("""
================================================================================
新卡：%s
★ 请按【LR → NX → SL】的顺序测 —— 嫌疑格都排在各自画面的最后一步。

【1】LR 日版（先测这个）：徽章画面
      格 1 原恶魔（没动）／格 2 原红树（没动）      ← 对照，必须正常
      格 3 = ★【从零造的玫瑰】（块头已修）          ← 原来是"反色恶魔"，现在应变成玫瑰
      格 3 正常 ⇒ ★ LR 块头就是卡死的原因，LR 从零造打通

【2】NX 日版：徽章画面，5 格逐格 load
      槽 1 (E00) 玫瑰 + 常量【清零】                ← ★ 疑点：它若破損/卡死 ⇒ 该字段被校验
      槽 2 (E01) 玫瑰 + NX 真常量                   ← 对照，必须正常
      槽 3 (E02) MIRAGE                             ← 对照，必须正常
      槽 4 (E03) CREST                              ← 对照，必须正常
      槽 5 (E04) 原 CREST（没动）                    ← 对照，必须正常

【3】SL 日版（最后测）：徽章画面
      槽 1 (E00) 玫瑰 + 【NX 的常量】                ← ★ 疑点：跨作品的值
      槽 2 (E01) 玫瑰 + SL 真常量                    ← 对照，必须正常

★ 判读：
  LR 格 3 正常、NX/SL 全正常      ⇒ 卡死的唯一原因是 LR 块头；作品常量不被校验
  LR 格 3 正常、NX 槽 1 破損/卡死  ⇒ LR 块头是卡死原因；且那 9 字节**被校验**
  LR 格 3 仍卡死                  ⇒ LR 从零造还有别的坑（请回报具体现象）
  SL 槽 1 破損、槽 2 正常          ⇒ 那 9 字节必须匹配本作品
================================================================================
""" % DST_CARD)
raise SystemExit(0 if allok else 1)
